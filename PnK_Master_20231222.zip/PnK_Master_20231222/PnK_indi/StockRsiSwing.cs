﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Text;
using System.Windows.Forms;
using AxGIExpertControl64Lib;

using System.Runtime.Serialization.Formatters.Binary;
namespace PnK_indi
{
    public partial class StockRsiSwing : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SubState> SubStates = new Dictionary<string, SubState>();
        private Dictionary<string, LogState> LogStates = new Dictionary<string, LogState>();

        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_PrevBalanceControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_MarketCapControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;

        /// <summary>
        ///  tuple 변수로 상태 bool과 시간을 저장
        /// </summary>
        private (bool Status, DateTime Time) RankCalculated;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;
        private bool HasPendingRequest = false;

        private bool CalcMarketCapCutOff_flag = false;
        private bool Indicator_signal_set_flag = false;

        private new bool Enabled;

        public Thread SetPriceSetBef { get; private set; }
        public Thread PriceThread { get; private set; }
        public double MarketCapCutOff { get; private set; }

        // 형식에 맞게 파일 이름을 생성합니다.
        string filePath = "C:/Users/234046/Desktop/Logs/StockRsiSwing/" + DateTime.Now.ToString("yyyy-MM-dd") + "_output.log";

        List<DateTime> holidays = new List<DateTime>
        {
            new DateTime(2023, 9, 9),  // 추석
            new DateTime(2023, 9, 28),
            new DateTime(2023, 9, 29),
            new DateTime(2023, 10, 2),
            new DateTime(2023, 10, 3), // 개천절
            new DateTime(2023, 10, 9), // 한글날
            new DateTime(2023, 12, 25) // 크리스마스
            // 원하는 공휴일을 추가하세요
        };

        private bool working_flag = true;

        public StockRsiSwing(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();
        }

        private void Save_logstates()
        {
            // Person 클래스 직렬화하여 C:\Users\234046\Desktop\States\StockRsiSwing 경로에 저장 (관리자 권한 필요)
            string filePath_states = @"C:\Users\234046\Desktop\States\StockRsiSwing\LogStates.dat";
            using (FileStream fileStream = new FileStream(filePath_states, FileMode.Create))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, LogStates);
            }
            Console.WriteLine("딕셔너리 LogStates Class Update Complete");
        }


        /// <summary>
        /// 현재 시간을 참조하여 필요한 지표들을 계산하는 함수이다.
        /// 장시작 몇분전, 장시작직후, 장종료 몇분전등
        /// </summary>
        private void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
            }

            RankCalculated = (false, MarketOpeningTime.AddMinutes(-20));
            OpeningPriceOrdered = (false, MarketOpeningTime.AddSeconds(-60));
            MarketOpened = (false, MarketOpeningTime);
            RsiCalculated = (false, MarketClosingTime.AddMinutes(-15));
            PreClosingOrdered = (false, MarketClosingTime.AddMinutes(-60));
            ClosingPriceOrdered = (false, MarketClosingTime.AddSeconds(-30));
            OnClose = (false, MarketClosingTime.AddMinutes(10));
        }

        /// <summary>
        /// 선언한 인디객체에 이벤트 함수를 연결 
        /// </summary>
        private void InitializeIndiControls()
        {
            Indi_PrevBalanceControl.CreateControl();
            Indi_PrevBalanceControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_PrevBalanceControl_ReceiveData);

            Indi_MarketCapControl.CreateControl();
            Indi_MarketCapControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_MarketCapControl_ReceiveData);

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);
        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }

        private void Indi_PrevBalanceControl_ReceiveData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
        }

        public void Enable() { this.Enabled = true; }

        public bool IsEnabled() => this.Enabled;

        public void Disable() { this.Enabled = false; }

        private void StockRsiReversion_Load(object sender, EventArgs e)
        {
        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("RunButton_Click");
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;
            InitSubStates();
            Enable();
            CalcMarketCapCutOff();


            SetPriceSetBef = new Thread(() => SetPriceSetBefore());
            SetPriceSetBef.Start();
            Console.WriteLine("spread set start done");


            //Enable();

            ManageTimer.Set(10 * 1000);
            ManageTimer.Start(OnTimer);
        }


        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsDouble(OverSoldBox.Text),
                C.AsInt(RSIPeriodBox.Text),
                C.AsDouble(VolPctBox.Text) / 100,
                C.AsInt(MaPeriodBox.Text),
                C.AsInt(RankUpToBox.Text),
                C.AsDouble(TakeProfitVolBox.Text) / 100,
                C.AsDouble(LossCutRateBox.Text) / 100,
                C.AsLong(MaxNotionalAmountBox.Text) * 100_000_000,
                C.AsLong(C.AsDouble(MaxAmountPerOrderBox.Text) * 100_000_000),
                C.AsLong(C.AsDouble(OrderAmountBox.Text) * 10000)
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }


        private void InitSubStates()
        {
            Console.WriteLine("InitSubStates");
            foreach (var state in Main.States.Values)
            {   


                // 주식 외 제외
                if (state.SecurityGroupId != SecurityGroupId.ST) { continue; }
                // 우선주 제외
                if (!state.ShortCode.EndsWith("0")) { continue; }
                // 락 종목 제외
                if (state.PriceAdjustment != PriceAdjustment.Normal
                    && state.PriceAdjustment != PriceAdjustment.ExDividend
                    && state.PriceAdjustment != PriceAdjustment.ExMidDividend) { continue; }
                // 스팩 제외
                if (state.Name.Contains("스팩")) { continue; }
                // 계열사 종목 제외
                if (state.Name.Contains("신한") || state.Name.Contains("제주은행")) { continue; }

                SubStates[state.ShortCode] = new SubState(state, _StrategyParams);



            }

            // 시세요청
            foreach (var subState in SubStates.Values)
            {
                var state = subState.State;

                if (state.MarketType == MarketType.Kospi)
                {
                    if (state.SecurityGroupId == SecurityGroupId.EF || state.SecurityGroupId == SecurityGroupId.EN)
                    {
                        Main.RequestA303S(state.StandardCode);
                        Main.RequestB703S(state.StandardCode);
                    }
                    else
                    {
                        Main.RequestA301S(state.StandardCode);
                        Main.RequestB601S(state.StandardCode);
                    }
                }
                else if (state.MarketType == MarketType.Kosdaq)
                {
                    Main.RequestA301Q(state.StandardCode);
                    Main.RequestB601Q(state.StandardCode);
                }
            }
        }

        private void CalcMarketCapCutOff()
        {
            Indi_MarketCapControl.SetQueryName("TR_RB001");
            Indi_MarketCapControl.SetSingleData(0, "0");

            var ret = Indi_MarketCapControl.RequestData();

            if (ret <= 0)
            {
                Console.WriteLine("Request Error: [TR_RB001]");
            }
        }
        /// <summary>
        /// Indi_MarketCapControl.RequestData() 가 호출되면 이벤트로 받는 함수
        ///  전종목의 시총순위를 정렬한후 시가총액 cutoff 계산 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Indi_MarketCapControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            Dictionary<string, long> MarketCaps = new Dictionary<string, long>();

            var nCnt = Indi_MarketCapControl.GetMultiRowCount();

            for (short i = 0; i < nCnt; i++)
            {
                var shortCode = Indi_MarketCapControl.GetMultiData(i, 1).ToString().Trim();
                var securityGroupId = Indi_MarketCapControl.GetMultiData(i, 19).ToString();

                if (securityGroupId != "ST" || !shortCode.EndsWith("0"))
                    continue;

                var outstandingShares = C.AsLong(Indi_MarketCapControl.GetMultiData(i, 18));
                var close = C.AsLong(Indi_MarketCapControl.GetMultiData(i, 26));

                MarketCaps[shortCode] = outstandingShares * close;
            }

            var OrderedMarketCaps = MarketCaps.OrderByDescending(x => x.Value);
            var cutoffShortCode = OrderedMarketCaps.ElementAt(_StrategyParams.RankUpTo).Key;
            var cutoffMarketCap = OrderedMarketCaps.ElementAt(_StrategyParams.RankUpTo).Value;

            this.MarketCapCutOff = cutoffMarketCap;
            Console.WriteLine($"시가총액 상위 {_StrategyParams.RankUpTo}개 기준점: {Math.Round(this.MarketCapCutOff / 10000 / 10000 / 10000, 2)}조");
            SetUniverseStocks();
        }
        /// <summary>
        /// 시총 cutoff안에 들지 못하는 종목은 SubStates에서 제거하는 함수
        /// </summary>
        private void SetUniverseStocks()
        {
            string filePath_states = @"C:\Users\234046\Desktop\States\StockRsiSwing\LogStates.dat";
            if (File.Exists(filePath_states))
            {
                Console.WriteLine("LogStates 데이터가 존재 합니다");
                using (FileStream fileStream = new FileStream(filePath_states, FileMode.Open))
                {
                    if (fileStream.Length > 0) // 데이터가 있는지 확인
                    {
                        BinaryFormatter binaryFormatter = new BinaryFormatter();
                        LogStates = (Dictionary<string, LogState>)binaryFormatter.Deserialize(fileStream);
                    }
                }
            }

            // Calc Market Cap Ranks
            foreach (var subState in SubStates.Values)
            {
                var shortCode = subState.State.ShortCode;
                subState.Rank = SubStates.Values.Where(x => x.PreviousDayMarketCap > subState.PreviousDayMarketCap).Count() + 1;
            }

            foreach (var subState in SubStates.Values.ToList())
            {
                var shortCode = subState.State.ShortCode;
                var Name = subState.State.Name;

                //시가총액 하위종목은 제거함 ,포지션이 있는 종목은 제거하지 않음
                if ( (subState.State.NormalBalance == 0 ) & (subState.PreviousDayMarketCap <= this.MarketCapCutOff))
                {
                    SubStates.Remove(shortCode);
                    continue;
                }else if(subState.State.NormalBalance > 0)
                {   

                }
                
            }

            foreach (var subState in SubStates.Values.OrderBy(x => x.Rank).ToList())
            {
                Console.WriteLine($"# {subState.Rank,3} {subState.State.ShortCode} {subState.State.Name}");
            }

            //if (!GetBalanceStatus()) { return; }

            RankCalculated.Status = true;
            HasPendingRequest = false;
            CalcMarketCapCutOff_flag = true;
        }



        private void SetPriceSetBefore()
        {
            Console.WriteLine("SetPriceSetBefore");
            while (true)
            {
                if (this.CalcMarketCapCutOff_flag)
                    break;
            }

            foreach (var subState in SubStates.Values.OrderBy(x => x.Rank).ToList())
            {
                var shortCode = subState.State.ShortCode;
                string yesterday = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");

                Indi_StockChartControl.SetQueryName("TR_SCHART");
                Indi_StockChartControl.SetSingleData(0, shortCode);
                Indi_StockChartControl.SetSingleData(1, "D");
                Indi_StockChartControl.SetSingleData(2, "1");
                Indi_StockChartControl.SetSingleData(3, "00000000");
                Indi_StockChartControl.SetSingleData(4, yesterday);
                Indi_StockChartControl.SetSingleData(5, "500");
                Indi_StockChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_StockChart)
                        break;
                }

                this.IsMessageReceived_StockChart = false;

                var nCount = Indi_StockChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }

                if (subState.PriceSet.Count() > 0) { subState.PriceSet.Clear(); }

                double adj = 1.0d;
                for (short i = 0; i < nCount; i++)
                {
                    var _datetime = Indi_StockChartControl.GetMultiData(i, 0).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}";

                    var close = C.AsDouble(Indi_StockChartControl.GetMultiData(i, 5)) * adj;
                    var high = C.AsDouble(Indi_StockChartControl.GetMultiData(i, 3)) * adj;
                    var low = C.AsDouble(Indi_StockChartControl.GetMultiData(i, 4)) * adj;

                    subState.PriceSet.Add(close);
                    subState.PriceHighSet.Add(high);
                    subState.PriceLowSet.Add(low);

                    adj = adj * C.AsDouble(Indi_StockChartControl.GetMultiData(i, 6));

                }
                Console.WriteLine($"# {subState.Rank,3} Set PriceSetUpdate , shortCode : {shortCode} Name:{SubStates[shortCode].State.Name} ");

            }
            SetIndicatorSetBefore();
        }

        private void SetIndicatorSetBefore()
        {
            int remain_slot = 10;

            foreach (var subState in SubStates.Values)
            {
                if (subState.State.NormalBalance!=0)
                {   
                    remain_slot = remain_slot - 1;
                    Console.WriteLine($"Already exist! {Name}");
                    Console.WriteLine("");
                }
            }
            Console.WriteLine($"remain_slot:{remain_slot}");
            Console.WriteLine("");

            foreach (var subState in SubStates.Values.OrderBy(x => x.Rank).ToList())
            {
                var shortCode = subState.State.ShortCode;
                var Name = subState.State.Name;



                // 장시작후 5분이 지나면, 진입하지 않음


                int period = 3;
                var temp_pricehigh = SubStates[shortCode].PriceHighSet.Take(period).ToArray();
                var temp_pricelow = SubStates[shortCode].PriceLowSet.Take(period).ToArray();
                
                double atr = temp_pricehigh.Zip(temp_pricelow, (x, y) => x - y).Sum();
                double vol_pct = atr/ SubStates[shortCode].PriceSet[0] / period;

                //직전봉까지를 활용한 RSI값 계산
                SubStates[shortCode].CalculateRSI();
                SubStates[shortCode].vol_pct_value = vol_pct;
                SubStates[shortCode].ma_price = SubStates[shortCode].PriceSet.Take(SubStates[shortCode].Params.MAPeriod).Average();

                if (SubStates[shortCode].RSI.Count == 0) 
                {
                    Console.WriteLine($"{Name} , RSI값 개수가 부족합니다");
                    continue;
                }

                //포지션이 존재하는 티커는 진입 시그널 계산하지 않음
                if (subState.State.NormalBalance>0)
                {
                    subState.exit_monitoring_flag = true;

                    if (LogStates.ContainsKey(shortCode))
                    {
                        subState.LastBuyDate = LogStates[shortCode].LastBuyDate;
                        SubStates[shortCode].vol_pct_value = LogStates[subState.State.ShortCode].vol_pct_value;
                        Console.WriteLine($"{Name}: 포지션이 존재함, Log 데이터도 존재 ");
                    }
                    else
                    {
                        subState.LastBuyDate = DateTime.Now;

                        LogStates[subState.State.ShortCode] = new LogState();
                        LogStates[subState.State.ShortCode].LastBuyDate = DateTime.Today;
                        LogStates[subState.State.ShortCode].vol_pct_value = vol_pct;
                        Save_logstates();
                        Console.WriteLine($"{Name}: 포지션이 존재함, Log 데이터가 존재하지 않음 ");
                    }

                    Console.WriteLine($"# Already_Buy {subState.Rank,3}위 ,{subState.State.NormalBalance}개, {subState.State.ShortCode}, {subState.State.Name}, LastBuyDate:{LogStates[subState.State.ShortCode].LastBuyDate}");
                    Console.WriteLine($"");
                    continue;
                }



                if ((SubStates[shortCode].ma_price< SubStates[shortCode].PriceSet[0]) &
                     (SubStates[shortCode].vol_pct_value> SubStates[shortCode].Params.VolPct) &
                     (SubStates[shortCode].RSI[0]< SubStates[shortCode].Params.OverSold)  &
                     (remain_slot>=1)
                    )
                {
                    SubStates[shortCode].today_entry_flag = true;
                    remain_slot = remain_slot - 1;
                    Console.WriteLine("");
                    Console.WriteLine($"entry!! {Name} remain_slot:{remain_slot}");
                    Console.WriteLine("");
                }
                Console.WriteLine($"entryflag:{SubStates[shortCode].today_entry_flag}, {Name} , RSI:{Math.Round(SubStates[shortCode].RSI[0], 2)}, vol_pct : {Math.Round(100 * SubStates[shortCode].vol_pct_value, 2)}% ,ma_price:{SubStates[shortCode].ma_price}, close_price:{SubStates[shortCode].PriceSet[0]}");
                
                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine($"entryflag:{SubStates[shortCode].today_entry_flag}, {Name} , RSI:{Math.Round(SubStates[shortCode].RSI[0], 2)}, vol_pct : {Math.Round(100 * SubStates[shortCode].vol_pct_value, 2)}% ,ma_price:{SubStates[shortCode].ma_price}, close_price:{SubStates[shortCode].PriceSet[0]}");
                    writer.WriteLine("");
                }

            }
            this.Indicator_signal_set_flag = true;
        }



        private void OnTimer(object sender, EventArgs e)
        {
            if (this.working_flag)
            {
                // 장개시후 시가주문 장시작후 5분이내로
                if ((DateTime.Now < MarketOpeningTime.AddMinutes(5)) & (DateTime.Now > MarketOpeningTime) & (this.Indicator_signal_set_flag))

                {
                    entry_order_flow();

                }
                if (DateTime.Now > MarketOpeningTime & (this.Indicator_signal_set_flag))
                {
                    exit_check();
                    exit_order_flow();
                }
            }
        }

        private void entry_order_flow()
        {

            // 매수주문
            foreach (var subState in SubStates.Values.ToList())
            {

                string shortcode = subState.State.ShortCode;
                string Name = subState.State.Name;


                if (!subState.today_entry_flag) { continue; }
                else if (subState.exit_monitoring_flag) { continue; }

                Console.WriteLine($"Name:{Name} entry order flow ");
                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) {
                    Console.WriteLine("Current_Price가 null입니다");
                    Console.WriteLine("");
                    continue; }
                else if (subState.State.Quote == null) { continue; }

                // 기 주문종목 제외
                else if (subState.State.LiveOrders.Any()) {
                    Console.WriteLine("LiveOrders가 존재합니다");
                    Console.WriteLine("");
                    continue; }
                else if (Main.Prohibited.Contains(shortcode)) {
                    Console.WriteLine("Prohibited 티커 입니다.");
                    Console.WriteLine("");
                    continue; }
                else if (C.AsLong(subState.State.Quote[3].AskPrice) == 0) { continue; }


                long Real_NowQuantity = (long)Math.Abs(subState.State.NormalBalance);

                bool target_quantity_complete = (subState.TargetOrderQuantity <= Real_NowQuantity) & (Real_NowQuantity!=0);

                // 첫 주문
                if (!subState.first_entry_order_done & Real_NowQuantity==0)
                {
                    //목표 주문 금액 및 개수

                    double order_amount = Math.Min(10000 * 10000 ,subState.Params.OrderAmount);

                    subState.TargetOrderQuantity = (long)Math.Round((double)(order_amount / subState.State.CurrentPrice));


                    long available_order_quantity = Math.Min((long)(C.AsLong(subState.State.Quote[0].AskQuantity) + C.AsLong(subState.State.Quote[1].AskQuantity)), subState.TargetOrderQuantity) ;
                    

                    //주문은 적어도 1개이상
                    available_order_quantity = Math.Max(available_order_quantity, 1);

                    var orderPrice = C.AsLong(subState.State.Quote[3].AskPrice);
    

                    if (available_order_quantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                    if (liveOrders.Count() > 0)
                    {   
                        subState.State.CancelAllOrders();
                    }

                    if (TradeOffButton.Checked) { continue; }

                    subState.State.NewOrder(AskBidType.Bid, orderPrice, available_order_quantity, OrderType.Limit, OrderCondition.Normal);


                    Console.WriteLine($"First Entry Order long {Name}, TargetOrderQuantity:{subState.TargetOrderQuantity}");
                    Console.WriteLine($"Send NewOrder entry long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice / 10000}만원 ");
                    Console.WriteLine("");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {

                        writer.WriteLine($"First Entry Order long {Name} , TargetOrderQuantity:{subState.TargetOrderQuantity}");
                        writer.WriteLine($"Send NewOrder entry long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice /10000}만원 ");

                        writer.WriteLine("");
                    }

                    subState.first_entry_order_done = true;
                    subState.LastBuyDate = DateTime.Today;

                    LogStates[subState.State.ShortCode] = new LogState();
                    LogStates[subState.State.ShortCode].LastBuyDate = DateTime.Today;
                    LogStates[subState.State.ShortCode].vol_pct_value = subState.vol_pct_value;
                    Save_logstates();
                    Console.WriteLine($"First Entry Order:! {subState.State.Name}");
                }
                else if( ! target_quantity_complete)
                {   //직전 개수와 차이가 있을때만 재주문
                    if (Real_NowQuantity!= subState.NowQuantity)
                    {
                        subState.NowQuantity = Real_NowQuantity;


                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            subState.State.CancelAllOrders();
                        }

                        long reentry_order_quantity = subState.TargetOrderQuantity - subState.NowQuantity;

                        Console.WriteLine($"Reentry remain Quantity : {reentry_order_quantity}");

                        if (reentry_order_quantity <= 0) { continue; }

                        long available_order_quantity = Math.Min( (long) (C.AsLong(subState.State.Quote[0].AskQuantity) + C.AsLong(subState.State.Quote[1].AskQuantity)), reentry_order_quantity);
                        
                        //주문은 적어도 1개이상
                        available_order_quantity = Math.Max(available_order_quantity , 1);
                        

                        var orderPrice = C.AsLong(subState.State.Quote[3].AskPrice);

                        if (TradeOffButton.Checked) { continue; }

                        subState.State.NewOrder(AskBidType.Bid, orderPrice, available_order_quantity, OrderType.Limit, OrderCondition.Normal);

                        Console.WriteLine($"Reentry Entry Order long {Name} , NowQuantity : {Real_NowQuantity}");
                        Console.WriteLine($"Send reentry Order entry long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice / 10000}만원 ");

                        Console.WriteLine("");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"Reentry Entry Order long {Name}, NowQuantity : {Real_NowQuantity}");
                            writer.WriteLine($"Send reentry Order entry long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice / 10000}만원 ");

                            writer.WriteLine("");
                        }
                    }
                }
                else
                {
 
                    subState.exit_monitoring_flag = true;

                    // 진입 주문 함수에 들어오지 못하게 하는 flag
                    subState.today_entry_flag = false;

                    subState.first_entry_order_done = false;

                    subState.today_entry_flag = false;
                            
                    //exit에선 현재 잔고를 기반으로 target order quanity가 정해지므로 초기화함
                    subState.TargetOrderQuantity = 0;

                    Console.WriteLine($"today_entry_done {Name}");
                    Console.WriteLine("");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"today_entry_done {Name}");
                        writer.WriteLine("");
                    }
                }
            }
            Console.WriteLine("");

        }

        private void exit_check()
        {
            int cnt = 0;
            foreach (var subState in SubStates.Values.ToList())
            {
                string shortcode = subState.State.ShortCode;
                string Name = subState.State.Name;

                // exit monitoring이 true인 종목만 관찰
                if (!subState.exit_monitoring_flag) { continue; }

                if (cnt == 0)
                {
                    Console.WriteLine($"exit check monitor, {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                }
                cnt++;

                // 가격 들어오지 않은 종목 제외

                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) {
                    Console.WriteLine($"{Name}:Current_Price가 null입니다");
                    Console.WriteLine("");
                    continue; }
                else if (subState.State.NormalBalance == 0| subState.State.AverageBuyPrice == 0) { continue; }
                else if (subState.today_exit_flag) { continue; }
                else if (Main.Prohibited.Contains(shortcode)) {
                    Console.WriteLine($"{Name}:Prohibited 티커 입니다.");
                    Console.WriteLine("");
                    continue; }


                int businessDayCount = 0;
                DateTime LastBuyDate_after = subState.LastBuyDate;
                if (LastBuyDate_after < DateTime.Today)
                {
                    while (LastBuyDate_after < DateTime.Today)
                    {
                        // 주말 (토요일, 일요일) 및 공휴일은 제외
                        if (LastBuyDate_after.DayOfWeek != DayOfWeek.Saturday &&
                            LastBuyDate_after.DayOfWeek != DayOfWeek.Sunday &&
                            !holidays.Contains(LastBuyDate_after))
                        {
                            businessDayCount++;
                        }

                        LastBuyDate_after = LastBuyDate_after.AddDays(1); // 다음 날짜로 이동
                        //Console.WriteLine($"{Name}:{LastBuyDate_after} , {businessDayCount}");


                    }
                }

                double expect_exit_return = ((double)subState.State.BestQuote.Bid - (double)subState.State.AverageBuyPrice) / (double)subState.State.AverageBuyPrice - 0.002;
                Console.WriteLine($"{Name}:,avgbuyprice : {subState.State.AverageBuyPrice}, expect_exit_price : {subState.State.BestQuote.Bid} , expect_exit_return : {Math.Round(100*expect_exit_return,2)}%, target_return : {Math.Round(100 * subState.vol_pct_value * 0.5, 2)}%");
                Console.WriteLine($"{Name}: LastBuyDate:{subState.LastBuyDate}, businessDayCount:{businessDayCount}");
                Console.WriteLine("");


                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {
                    writer.WriteLine($"Name:{Name} exit check monitor, {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                    writer.WriteLine($"{Name}:,avgbuyprice : {subState.State.AverageBuyPrice}, expect_exit_price : {subState.State.BestQuote.Bid} , expect_exit_return : {Math.Round(100 * expect_exit_return, 2)}%, target_return : {Math.Round(100 * subState.vol_pct_value * 0.5, 2)}%");
                    writer.WriteLine($"{Name}: LastBuyDate:{subState.LastBuyDate}, businessDayCount:{businessDayCount}");
                    writer.WriteLine("");
                }

                if (businessDayCount >= 1)
                {

                    subState.today_exit_flag = (subState.vol_pct_value * 0.5) < expect_exit_return;

                }
                if (businessDayCount >= 3)
                {

                    if (DateTime.Now > PreClosingOrdered.Time)
                    {
                        subState.today_exit_flag = true;
                    }
                }

                if (subState.today_exit_flag)
                {
                    Console.WriteLine($"{Name},today_exit_flag :True, businessDayCount:{businessDayCount},expect_exit_return:{Math.Round(100 * expect_exit_return,2)}%");
                }

            }

        }
        private void exit_order_flow()
        {
            // 매도주문
            foreach (var subState in SubStates.Values.ToList())
            {
                string shortcode = subState.State.ShortCode;
                string Name = subState.State.Name;

                if (!subState.today_exit_flag) { continue; }

                else if (subState.State.Quote == null) { continue; }
                // 가격 들어오지 않은 종목 제외
                else if (subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) {
                    Console.WriteLine($"{Name}, BestQuote가 0 입니다");
                    continue; }

                // 기 주문종목 제외
                else if (subState.State.LiveOrders.Any()) { continue; }
                else if (Main.Prohibited.Contains(shortcode)) { continue; }
                else if (Main.Prohibited.Contains(shortcode)) { continue; }
                else if (C.AsLong(subState.State.Quote[3].BidPrice)==0 ) { continue; }


                long Real_NowQuantity = (long)Math.Abs(subState.State.NormalBalance);

                bool target_quantity_complete = Real_NowQuantity == 0;

                // 첫 주문
                if (!subState.first_exit_order_done & Real_NowQuantity != 0)
                {
                    //목표 주문 금액 및 개수
      
                    subState.NowQuantity = Real_NowQuantity;

                    long available_order_quantity = (long)Math.Min( (C.AsLong(subState.State.Quote[0].BidQuantity) + C.AsLong(subState.State.Quote[1].BidQuantity)), Real_NowQuantity);

                    var orderPrice = C.AsLong(subState.State.Quote[3].BidPrice);


                    if (available_order_quantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        subState.State.CancelAllOrders();
                    }

                    if (TradeOffButton.Checked) { continue; }

                    Console.WriteLine($"First Exit Order long {Name}");
                    Console.WriteLine($"Send exit Order long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice / 10000}만원 ");
                    Console.WriteLine("");


                    subState.State.NewOrder(AskBidType.Ask, orderPrice, available_order_quantity, OrderType.Limit, OrderCondition.Normal);

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {

                        writer.WriteLine($"First Exit Order long {Name}");
                        writer.WriteLine($"Send exit Order long: {shortcode} available_order_quantity:{available_order_quantity} orderPrice: {orderPrice} orderAmount:{available_order_quantity * orderPrice / 10000}만원 ");

                        writer.WriteLine("");
                    }

                    subState.first_exit_order_done = true;
                   
                }
                else if (!target_quantity_complete)
                {   //직전 개수와 차이가 있을때만 재주문
                    if (Real_NowQuantity != subState.NowQuantity)
                    {
                        subState.NowQuantity = Real_NowQuantity;

                        long reentry_order_quantity = (long)Math.Min( (C.AsLong(subState.State.Quote[0].BidQuantity) + C.AsLong(subState.State.Quote[1].BidQuantity)), Real_NowQuantity);

                        var orderPrice = C.AsLong(subState.State.Quote[3].BidPrice);

                        if (TradeOffButton.Checked) { continue; }

                        Console.WriteLine($"Re Exit Order long {Name}");
                        Console.WriteLine($"Send exit Order long: {shortcode} available_order_quantity:{reentry_order_quantity} orderPrice: {orderPrice} orderAmount:{reentry_order_quantity * orderPrice / 10000}만원 ");
                        Console.WriteLine("");

                        subState.State.NewOrder(AskBidType.Ask, orderPrice, reentry_order_quantity, OrderType.Limit, OrderCondition.Normal);

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"Re Exit Order long {Name}");
                            writer.WriteLine($"Send exit Order long: {shortcode} available_order_quantity:{reentry_order_quantity} orderPrice: {orderPrice} orderAmount:{reentry_order_quantity * orderPrice / 10000}만원 ");
                            writer.WriteLine("");
                        }

                    }
                }
                else if (target_quantity_complete)
                {

                    subState.today_entry_flag = false;
                    subState.first_entry_order_done = false;

                    subState.today_exit_flag = false;
                    subState.first_exit_order_done = false;

                    subState.exit_monitoring_flag = false;

                    subState.TargetOrderQuantity = 0;
                    subState.NowQuantity = 0;
                    SubStates.Remove(shortcode);

                }

            }
        }



        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution)
            {
                if (SubStates.TryGetValue(state.ShortCode, out SubState subState))
                {
                    //subState.UpdatePrice();
                }
            }
        }

        public void OnConfirm(StockState state)
        {
        }
        public void OnExecution(StockState state)
        {
        }

        private void SignalButton_Click(object sender, EventArgs e)
        {
        }

        private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
        private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

        private class SubState
        {
            public StockState State;
            public StrategyParams Params;
            public TypeConverter C = new TypeConverter();

            public long PreviousDayMarketCap;
            public int Rank;

            public double ma_price;
            public double vol_pct_value;

            public bool HasToBuy;
            public bool HasToSell;
            public bool HadToSell;
            public bool Done;

            public bool Enabled;
            public bool today_entry_flag=false;
            public bool first_entry_order_done = false;

            public bool today_exit_flag = false;
            public bool first_exit_order_done = false;

            public bool exit_monitoring_flag = false;

            public long TargetOrderQuantity=0;
            public long NowQuantity = 0;


            public List<double> PriceSet = new List<double>();
            public List<double> PriceHighSet = new List<double>();
            public List<double> PriceLowSet = new List<double>();

            public List<double> uSet = new List<double>();
            public List<double> dSet = new List<double>();
            public List<double> auSet = new List<double>();
            public List<double> adSet = new List<double>();

            public List<double> RSI = new List<double>();

            public DateTime LastBuyDate { get; internal set; } = new DateTime();

            public void Enable() { this.Enabled = true; }
            public bool IsAble() => this.Enabled;
            public void Disable() { this.Enabled = false; }


            public SubState(StockState state, StrategyParams strategyParams)
            {
                this.State = state;
                this.Params = strategyParams;
                this.PreviousDayMarketCap = State.PreviousDayPrice * State.OutstandingShares;

                var bookValue = State.NormalBalance * State.AverageBuyPrice;

            }


            public void CalculateRSI()
            {
                var priceCount = PriceSet.Count();

                for (int i = 0; i < priceCount - 1; i++)
                {
                    var delta = PriceSet.ElementAt(i) - PriceSet.ElementAt(i + 1);

                    var u = (delta + Math.Abs(delta)) / 2;
                    var d = Math.Abs((delta - Math.Abs(delta)) / 2);

                    uSet.Insert(0, u);
                    dSet.Insert(0, d);
                }

                for (int i = 0; i < uSet.Count(); i++)
                {
                    if (i < Params.RSIPeriod)
                    {
                        RSI.Insert(0, 100.0);
                    }
                    else if (i == Params.RSIPeriod)
                    {
                        var au = uSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        var ad = dSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI.Insert(0, rsi);
                    }
                    else
                    {
                        var u = uSet.ToList()[i];
                        var d = dSet.ToList()[i];

                        var au = (u + auSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;
                        var ad = (d + adSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;

                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI.Insert(0, rsi);
                    }
                }
                this.Enable();
            }
        }

        [Serializable]
        class LogState
        { 
            public DateTime LastBuyDate;
            public double vol_pct_value;

        }

        internal class StrategyParams
        {
            public double OverSold { get; private set; }
            public int RSIPeriod { get; private set; }
            public double VolPct { get; private set; }
            public int MAPeriod { get; private set; }
            public int RankUpTo { get; private set; }
            public double TakeProfitVol { get; private set; }
            public double LossCutRate { get; private set; }
            public long MaxNotionalAmount { get; private set; }
            public long MaxAmountPerOrder { get; private set; }
            public long OrderAmount { get; private set; }

            public void StartegyParams()
            {
            }

            public bool Update(double overSold,
                               int rsiPeriod,
                               double volpct,
                               int maPeriod,
                               int rankUpTo,
                               double targetRate,
                               double losscutRate,
                               long maxNotionalAmount,
                               long maxAmountPerOrder,
                               long orderamount)
            {


                this.OverSold = overSold;
                this.RSIPeriod = rsiPeriod;
                this.VolPct = volpct;
                this.MAPeriod = maPeriod;
                this.RankUpTo = rankUpTo;
                this.TakeProfitVol = targetRate;
                this.LossCutRate = losscutRate;
                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxAmountPerOrder = maxAmountPerOrder;
                this.OrderAmount = orderamount;

                return true;
            }
        }

        private void PauseButton_Click(object sender, EventArgs e)
        {
            this.working_flag = false;
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            this.working_flag = true;
        }
    }
}
