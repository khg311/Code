﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using AxGIExpertControl64Lib;
//using TicTacTec.TA.Library;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PnK_indi
{
    public partial class IndexFuturePairIntraBreak : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SpreadSubState> SpreadSubStates = new Dictionary<string, SpreadSubState>();
        private Dictionary<string, FuturesSubState> FuturesSubStates = new Dictionary<string, FuturesSubState>();

        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KospiChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KosdaqChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_IndexfuturesChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();


        private List<string> PairUniverseList = new List<string>() { };


        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;


        /// <summary>
        ///  tuple 변수로 상태 bool과 시간을 저장
        /// </summary>
        private (bool Status, DateTime Time) Calculate_Rsi_signal_tuple;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) CloseSameHogaTime;
        private (bool Status, DateTime Time) EntryOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;

        private bool IsMessageReceived_IndexfuturesChart = false;

        private bool SetSpreadPriceSetBef_Flag = false;
        private bool SetSpreadStart_Flag = false;

        private new bool Enabled;

        public Thread SetPriceSetBef { get; private set; }
        public Thread Calculate_Rsi_Thread { get; private set; }

        public double sfutures_multiple = 10;


        private bool working_flag = true;

        public DateTime short_entry_const;
        public string start_time;


        // 형식에 맞게 파일 이름을 생성합니다.
        string filePath = "C:/Users/234046/Desktop/Logs/IndexFuturePairIntraBreak/" + DateTime.Now.ToString("yyyy-MM-dd") + "_output.log";

        public IndexFuturePairIntraBreak(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();
        }


        private void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 45, 0);

                start_time = "0846";
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 45, 0);

                start_time = "0946";
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 45, 0);

                start_time = "0946";
            }

            Calculate_Rsi_signal_tuple = (false, MarketOpeningTime.AddMinutes(5));

            //OpeningPriceOrdered = (false, MarketOpeningTime.AddSeconds(-60));
            MarketOpened = (false, MarketOpeningTime);

            CloseSameHogaTime = (false, MarketClosingTime.AddMinutes(-10));
            ClosingPriceOrdered = (false, MarketClosingTime.AddMinutes(-11));

            OnClose = (false, MarketClosingTime.AddMinutes(10));

            short_entry_const = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
        }

        /// <summary>
        /// 선언한 인디객체에 이벤트 함수를 연결 
        /// </summary>
        private void InitializeIndiControls()
        {

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);


            indi_KospiChartCtrl.CreateControl();
            indi_KospiChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKospiChartData);

            indi_KosdaqChartCtrl.CreateControl();
            indi_KosdaqChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKosdaqChartData);

            indi_IndexfuturesChartControl.CreateControl();
            indi_IndexfuturesChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_IndexfuturesChartControl_ReceiveData);

        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }

        private void Indi_IndexfuturesChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_IndexfuturesChart = true;
        }

        private void Indi_ReceiveKospiChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear == null)
                return;

            var shortCode = kospiNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KospiChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KospiChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 5));

                //HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            //isReadyForKospiFutures = true;
        }

        private void Indi_ReceiveKosdaqChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear == null)
                return;

            var shortCode = kosdaqNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KosdaqChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KosdaqChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 5));

                //HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            //isReadyForKosdaqFutures = true;
        }


        public bool IsEnabled() => this.Enabled;

        public void OnConfirm(DerivState state)
        {
        }

        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution)
            {   //SubStates 의 State에 StockState state가 어떻게 업데이트되는지 이해가 잘안감

            }
        }

        public void UpdateQuotes(RealTimeDataType dataType, DerivState futuresState)
        {
            //if(dataType == RealTimeDataType.Execution)
            // {
            //     Console.WriteLine("futuresState");
            // }

        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("RunButton_Click");
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;

            InitFuturesStates();
            InitSpreadStates();

            //SetPriceSetBef = new Thread(() => SetPriceSetBefore());
            //SetPriceSetBef.Start();
            //Console.WriteLine("spread set start done");
            Enable();
            Console.WriteLine("ManageTimer before");
            ManageTimer.Set(2 * 1000);
            ManageTimer.Start(OnTimer);
        }


        private void InitFuturesStates()
        {


            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear != null)
            {
                Main.RequestG701F(kospiNear.ShortCode);
                Main.RequestB601F(kospiNear.ShortCode);


                var futuresShortCode = kospiNear.ShortCode;
                
                FuturesSubStates[futuresShortCode] = new FuturesSubState(kospiNear, kospiNear.StandardCode, kospiNear.ShortCode, kospiNear.Name);
                FuturesSubStates[futuresShortCode].Easyname = "KOSPI";

            }

            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear != null)
            {
                Main.RequestG702F(kosdaqNear.ShortCode);
                Main.RequestB602F(kosdaqNear.ShortCode);

                var futuresShortCode = kosdaqNear.ShortCode;

                FuturesSubStates[futuresShortCode] = new FuturesSubState(kosdaqNear, kosdaqNear.StandardCode, kosdaqNear.ShortCode, kosdaqNear.Name);
                FuturesSubStates[futuresShortCode].Easyname = "KOSDAQ";
            }

            PairUniverseList.Add($"{kosdaqNear.ShortCode}_{kospiNear.ShortCode}");
            
        }
        /// <summary>
        /// spread state 객체 생성
        /// </summary>
        private void InitSpreadStates()
        {
            string filePath_states = $@"C:\Users\234046\Desktop\States\IndexFuturePairIntraBreak\SpreadSubStates_{DateTime.Now.ToString("yyyy-MM-dd")}.dat";
            if (File.Exists(filePath_states))
            {
                Console.WriteLine("SpreadSubState 데이터가 존재 합니다");
                using (FileStream fileStream = new FileStream(filePath_states, FileMode.Open))
                {
                    if (fileStream.Length > 0) // 데이터가 있는지 확인
                    {
                        BinaryFormatter binaryFormatter = new BinaryFormatter();
                        SpreadSubStates = (Dictionary<string, SpreadSubState>)binaryFormatter.Deserialize(fileStream);

                        foreach (string pair in PairUniverseList)
                        {
                            if (SpreadSubStates.ContainsKey(pair))
                            {
                                SpreadSubStates[pair].Params = _StrategyParams;

                            }
                            else
                            {
                                SpreadSubStates[pair] = new SpreadSubState(_StrategyParams);

                                string[] pairs = pair.Split('_');
                                SpreadSubStates[pair].Pair1ShortCode = pairs[0];
                                SpreadSubStates[pair].Pair2ShortCode = pairs[1];
                            }


                        }

                    }
                    else
                    {
                        Console.WriteLine("SpreadSubState 데이터가 존재 하지만, 데이터가 비어있습니다");

                    }
                }
            }
            else
            {
                Console.WriteLine("SpreadSubState 데이터가 존재 하지 않습니다");
                foreach (string pair in PairUniverseList)
                {
                    SpreadSubStates[pair] = new SpreadSubState(_StrategyParams);

                    string[] pairs = pair.Split('_');
                    SpreadSubStates[pair].Pair1ShortCode = pairs[0];
                    SpreadSubStates[pair].Pair2ShortCode = pairs[1];


                }
            }

        }




        /// <summary>
        /// 장시작전 전일 까지의 종가데이터를 불러와 객체에 저장하는 함수
        /// </summary>
        private void SetPriceSetBefore()
        {

            foreach (var fderivState in FuturesSubStates.Values)
            {

                var shortcode = fderivState.DerivState.ShortCode;
                indi_IndexfuturesChartControl.SetQueryName("TR_FNCHART");
                indi_IndexfuturesChartControl.SetSingleData(0, shortcode.Substring(0, 5));
                indi_IndexfuturesChartControl.SetSingleData(1, "1");
                indi_IndexfuturesChartControl.SetSingleData(2, "1");
                indi_IndexfuturesChartControl.SetSingleData(3, "00000000");
                indi_IndexfuturesChartControl.SetSingleData(4, "99999999");
                indi_IndexfuturesChartControl.SetSingleData(5, "1200");

                indi_IndexfuturesChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_IndexfuturesChart)
                        break;
                }

                this.IsMessageReceived_IndexfuturesChart = false;
                var nCount = indi_IndexfuturesChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }
                if (fderivState.PriceSet.Count() > 0) { fderivState.PriceSet.Clear(); }

                string today = DateTime.Now.ToString("yyyyMMdd");
                string standard_datetime = null;

                for (short i = 0; i < nCount; i++)
                {

                    var _datetime = indi_IndexfuturesChartControl.GetMultiData(i, 0).ToString().Trim();
                    var _time = indi_IndexfuturesChartControl.GetMultiData(i, 1).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}_{_time}";
                    var close = C.AsDouble(indi_IndexfuturesChartControl.GetMultiData(i, 5));

                    if (today != _datetime & standard_datetime==null)
                    {
                        standard_datetime = _datetime;

                    }

                    if (standard_datetime != null & standard_datetime==_datetime)
                    {

                        fderivState.PriceSet.Add(close);
                        fderivState.DatetimeSet.Add(strDate);
                    }

                    if (today == _datetime & _time == start_time)
                    {
                        fderivState.today_open = close ; 

                    }
                }
                Console.WriteLine($"{shortcode}, {fderivState.Easyname}, {fderivState.DerivState.Name}");
                Console.WriteLine($"barrier 기준 날짜 {standard_datetime} , {fderivState.DatetimeSet.Last()}-{fderivState.DatetimeSet[0]}");
                Console.WriteLine($"barrier 기준 가격 {fderivState.PriceSet.Last()}");
                Console.WriteLine($"today_open 가격 {fderivState.today_open}");

                double open_price_past = fderivState.PriceSet.Last();

                fderivState.NormReturnSet = fderivState.PriceSet.Select(x => x / open_price_past - 1).ToList();
                Console.WriteLine("");


            }

            this.SetSpreadSetBefore();


        }

        private void SetSpreadSetBefore()
        {
            foreach (string pair_key in SpreadSubStates.Keys)
            {
                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;

                List<double> pair1_NormReturnSet = FuturesSubStates[pair1_shortcode].NormReturnSet;
                List<double> pair2_NormReturnSet = FuturesSubStates[pair2_shortcode].NormReturnSet;

                SpreadSubStates[pair_key].cointvalue = 0.6;

                SpreadSubStates[pair_key].normSpreadSet = pair1_NormReturnSet.Zip(pair2_NormReturnSet, (x, y) => x-y).ToList();

                SpreadSubStates[pair_key].pre_spread_vol = SpreadSubStates[pair_key].normSpreadSet.Max()- SpreadSubStates[pair_key].normSpreadSet.Min();
                SpreadSubStates[pair_key].minute1_pre = DateTime.Now;
                SpreadSubStates[pair_key].spread_past1_min = SpreadSubStates[pair_key].normSpreadSet[0];

                var DerivState_pair1 = FuturesSubStates[pair1_shortcode].DerivState;
                var DerivState_pair2 = FuturesSubStates[pair2_shortcode].DerivState;

                string pair1_name = FuturesSubStates[pair1_shortcode].DerivState.Name;
                string pair2_name = FuturesSubStates[pair1_shortcode].DerivState.Name;

                if (DerivState_pair1.NormalBalance != 0 & DerivState_pair2.NormalBalance != 0)
                {
                    Console.WriteLine($"{pair_key} :존재함,{pair1_name},{DerivState_pair1.NormalBalance}계약,{pair2_name} {DerivState_pair2.NormalBalance}계약, ");

                    SpreadSubStates[pair_key].entry_signal_now = false;

                    SpreadSubStates[pair_key].first_entry_order_done = false;

                    SpreadSubStates[pair_key].exit_monitoring = true;

                    SpreadSubStates[pair_key].exit_signal_now = false;

                    //만약 포지션은 있는데 entry side 가 null이면 입력함
                    if (object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null))
                    {
                        if (DerivState_pair1.NormalBalance > 0 & DerivState_pair2.NormalBalance < 0)
                        {
                            SpreadSubStates[pair_key].entry_side = "long";
                        }
                        else if (DerivState_pair1.NormalBalance < 0 & DerivState_pair2.NormalBalance > 0)
                        {
                            SpreadSubStates[pair_key].entry_side = "short";
                        }
                    }
                    if (object.ReferenceEquals(SpreadSubStates[pair_key].EntryTime, null))
                    {
                        SpreadSubStates[pair_key].EntryTime = DateTime.Now;
                    }

                    Console.WriteLine($"entry_side:{SpreadSubStates[pair_key].entry_side},entry_signal_now:{SpreadSubStates[pair_key].entry_signal_now},first_entry_order_done:{SpreadSubStates[pair_key].first_entry_order_done}");
                    Console.WriteLine($",exit_monitoring:{SpreadSubStates[pair_key].exit_monitoring},exit_signal_now:{SpreadSubStates[pair_key].exit_signal_now}");
                    Console.WriteLine($"");
                }
            }

            this.SetSpreadPriceSetBef_Flag = true;
        }
        private void OnTimer(object sender, EventArgs e)
        {
            if(!this.SetSpreadPriceSetBef_Flag & (DateTime.Now-this.MarketOpeningTime).Minutes >=1 & !this.SetSpreadStart_Flag)
            {   
                SetPriceSetBef = new Thread(() => SetPriceSetBefore());
                SetPriceSetBef.Start();
                Console.WriteLine("SetPriceSetBef start ");
                this.SetSpreadStart_Flag = true;
            }


            //직전 날까지의 로그스프레드,RSI 업데이트 완료
            if (CloseSameHogaTime.Time > DateTime.Now)
            {
                if (working_flag)
                {
                    if (this.SetSpreadPriceSetBef_Flag)
                    {

                        Calculate_signal();


                        signal_entry_check_and_order();

                        signal_exit_check_and_order();
                    }


                }
            }
        }

        private void Calculate_signal()
        {

            int cnt = 0;
            foreach (string pair_key in SpreadSubStates.Keys)
            {

                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;

                var DerivState_pair1 = FuturesSubStates[pair1_shortcode].DerivState;
                var DerivState_pair2 = FuturesSubStates[pair2_shortcode].DerivState;


                SpreadSubStates[pair_key].Pair1NowPrice = DerivState_pair1.CurrentPrice;
                SpreadSubStates[pair_key].Pair2NowPrice = DerivState_pair2.CurrentPrice;

                string pair1_name = DerivState_pair1.Name;
                string pair2_name = DerivState_pair2.Name;

                long pair1_order_quantity = 9;
                long pair2_order_quantity = 1;

                long target_amount = (long)(SpreadSubStates[pair_key].Params.OrderAmount * 10000*10000);

                bool minute_update_flag = false;


                // 코스피 선물 기준으로 개수를 맞춤
                SpreadSubStates[pair_key].Pair2TargetOrderQuantity = (long)(target_amount / (FuturesSubStates[pair2_shortcode].PriceSet[0] * FuturesSubStates[pair2_shortcode].DerivState.Multiplier) );
                SpreadSubStates[pair_key].Pair1TargetOrderQuantity = SpreadSubStates[pair_key].Pair2TargetOrderQuantity * 9;

                Console.WriteLine($"Spread_Check : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
         
                Console.WriteLine($"{pair_key}, {pair1_name}_{pair2_name}");

                if (DerivState_pair1.Quote == null | DerivState_pair2.Quote == null)
                {
                    Console.WriteLine("Calculate_signal : Quote 데이터가 null 입니다");
                    Console.WriteLine("");
                    continue;
                }
                else if (DerivState_pair1.CurrentPrice == 0 | DerivState_pair2.CurrentPrice == 0)
                {
                    Console.WriteLine("DerivState의 CurrentPrice가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                double pari1_norm_return = DerivState_pair1.CurrentPrice / FuturesSubStates[pair1_shortcode].today_open - 1;
                double pari2_norm_return = DerivState_pair2.CurrentPrice / FuturesSubStates[pair2_shortcode].today_open - 1;
                double spread_now = pari1_norm_return - pari2_norm_return;
                double spread_past1_min = SpreadSubStates[pair_key].spread_past1_min;
                double pre_spread_vol = SpreadSubStates[pair_key].pre_spread_vol;


                if (DateTime.Now.Minute != SpreadSubStates[pair_key].minute1_pre.Minute)
                {
                    Console.WriteLine($"minutes_update! : {DateTime.Now}");
                    SpreadSubStates[pair_key].minute1_pre = DateTime.Now;
                    minute_update_flag = true;
                }

                //entry 모니터링
                if (object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null) & !SpreadSubStates[pair_key].exit_monitoring)
                {


                    long entry_pair1_quantity = 0;
                    long entry_pair2_quantity = 0;


                    //Spread long 진입 이면 pair1 long, pair2 short
                    if (spread_now > 0)
                    {
                        SpreadSubStates[pair_key].Pair1NowEntryPrice = (double)C.AsDouble(DerivState_pair1.Quote[0].AskPrice);
                        SpreadSubStates[pair_key].Pair2NowEntryPrice = (double)C.AsDouble(DerivState_pair2.Quote[0].BidPrice);

                        Console.WriteLine($"Spread Long!, pair1 long, pair2 short monitoring");

                    }// Spread short 진입 이면 pair1 long, pair2 short
                    else if (spread_now < 0)
                    {
                        SpreadSubStates[pair_key].Pair1NowEntryPrice = (double)C.AsDouble(DerivState_pair1.Quote[0].BidPrice);
                        SpreadSubStates[pair_key].Pair2NowEntryPrice = (double)C.AsDouble(DerivState_pair2.Quote[0].AskPrice);

                        Console.WriteLine($"Spread Short!, pair1 short, pair2 long monitoring");
                    }

                    Console.WriteLine("");

                    double pair1_entryprice_now = SpreadSubStates[pair_key].Pair1NowEntryPrice;
                    double pair2_entryprice_now = SpreadSubStates[pair_key].Pair2NowEntryPrice;

                    double target_barrier = pre_spread_vol * 0.5;
                    //spraed long진입 체크


                    if ((spread_now > target_barrier) & (minute_update_flag) & (!SpreadSubStates[pair_key].already_break_long_by_const))
                    {
                        if (pari1_norm_return < 0.005)
                        {
                            SpreadSubStates[pair_key].already_break_long_by_const = true;
                            Save_spreadsubstates();
                        }
                    }

                    if ((spread_now < -target_barrier) & (minute_update_flag) & (!SpreadSubStates[pair_key].already_break_short_by_const))
                    {
                        if (pari2_norm_return>0)
                        {
                            SpreadSubStates[pair_key].already_break_short_by_const = true;
                            Save_spreadsubstates();
                        }
                    }


                    bool long_entry_flag =  ( spread_now > target_barrier) & (minute_update_flag) & (!SpreadSubStates[pair_key].already_exit) & (!SpreadSubStates[pair_key].already_break_long_by_const);

                    //spread short 진입 체크
                    bool short_entry_flag = (spread_now < -target_barrier) & (minute_update_flag) & (!SpreadSubStates[pair_key].already_exit) & (!SpreadSubStates[pair_key].already_break_short_by_const);


                    double remain_pct_entry = (spread_now > 0) ? (target_barrier - spread_now) : (target_barrier + spread_now);

                    //spread long 진입 pair1 long, pair2 short
                    Console.WriteLine("");
                    Console.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowEntryPrice},pair1_open: {FuturesSubStates[pair1_shortcode].today_open},pair1_return:{Math.Round(100 * pari1_norm_return, 2)}%");
                    Console.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowEntryPrice},pair2_open: {FuturesSubStates[pair2_shortcode].today_open},pair2_return:{Math.Round(100 * pari2_norm_return, 2)}%");
                    Console.WriteLine($"pair1_order_q:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity},pair2_order_q:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}");
                    Console.WriteLine($"spread_now:{Math.Round(100*spread_now,2)}%,spread_past1_min:{Math.Round(100 * spread_past1_min,2)}%,pre_spread_vol:{Math.Round(100 * pre_spread_vol,2)}%");
                    Console.WriteLine($"target_barrier:{Math.Round(100 * target_barrier,2)}%");
                    Console.WriteLine($"spread_to_entry:{Math.Round(100 * remain_pct_entry, 2)}%");
                    Console.WriteLine($"minute_update_flag:{minute_update_flag},already_break_long_by_const:{SpreadSubStates[pair_key].already_break_long_by_const} , already_break_short_by_const:{SpreadSubStates[pair_key].already_break_short_by_const} , already_exit:{SpreadSubStates[pair_key].already_exit}");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowEntryPrice},pair1_open: {FuturesSubStates[pair1_shortcode].today_open},pair1_return:{Math.Round(100 * pari1_norm_return, 2)}%");
                        writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowEntryPrice},pair2_open: {FuturesSubStates[pair2_shortcode].today_open},pair2_return:{Math.Round(100 * pari2_norm_return, 2)}%");
                        writer.WriteLine($"pair1_order_q:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity},pair2_order_q:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}");
                        writer.WriteLine($"spread_now:{Math.Round(100 * spread_now, 2)}%,spread_past1_min:{Math.Round(100 * spread_past1_min, 2)}%,pre_spread_vol:{Math.Round(100 * pre_spread_vol, 2)}%");
                        writer.WriteLine($"target_barrier:{Math.Round(100 * target_barrier, 2)}%");
                        writer.WriteLine($"spread_to_entry:{Math.Round(100 * remain_pct_entry, 2)}%");
                        writer.WriteLine($"already_break_long_by_const:{SpreadSubStates[pair_key].already_break_long_by_const} , already_break_short_by_const:{SpreadSubStates[pair_key].already_break_short_by_const} , already_exit:{SpreadSubStates[pair_key].already_exit}");
                        writer.WriteLine($"minute_update_flag:{minute_update_flag},already_break_long_by_const:{SpreadSubStates[pair_key].already_break_long_by_const} , already_break_short_by_const:{SpreadSubStates[pair_key].already_break_short_by_const} , already_exit:{SpreadSubStates[pair_key].already_exit}");

                        writer.WriteLine("");
                    }

                    Console.WriteLine("");

                    if (MarketClosingTime.AddMinutes(-45) < DateTime.Now)
                    {
                        Console.WriteLine("entry시간이 아닙니다");
                        Console.WriteLine("");
                        long_entry_flag= false;
                        short_entry_flag = false;
                    }

                    if (TradeOffButton.Checked)
                    {
                        Console.WriteLine("TradeOffButton.Checked");
                        Console.WriteLine("");
                        long_entry_flag = false;
                        short_entry_flag = false;
                    }
                    else if (EntryOffButton.Checked)
                    {
                        Console.WriteLine("EntryOffButton.Checked");
                        Console.WriteLine("");
                        long_entry_flag = false;
                        short_entry_flag = false;
                    }

                    Console.WriteLine("");

                    if (long_entry_flag)
                    {

                        SpreadSubStates[pair_key].entry_signal_now = true;
                        SpreadSubStates[pair_key].entry_side = "long";

                        Console.WriteLine($"Entry long signal {pair_key},target_amount : {target_amount}");
                        Console.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 long ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 short ");
                        Save_spreadsubstates();

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"Entry long signal {pair_key},target_amount : {target_amount}");
                            writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 long ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 short ");
                            writer.WriteLine("");
                        }
                    }
                    else if (short_entry_flag )
                    {

                        SpreadSubStates[pair_key].entry_signal_now = true;
                        SpreadSubStates[pair_key].entry_side = "short";

                        Console.WriteLine($"Entry short signal {pair_key},target_amount : {target_amount}");
                        Console.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 short ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 long ");
                        Save_spreadsubstates();

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"Entry short signal {pair_key},target_amount : {target_amount}");
                            writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 short ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 long ");
                            writer.WriteLine("");
                        }
                    }

                    if (minute_update_flag)
                    {
                        SpreadSubStates[pair_key].spread_past1_min = spread_now;
                    }
                }

                //exit 모니터링
                if (!object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null) & SpreadSubStates[pair_key].exit_monitoring)
                {
                    double total_amount = DerivState_pair1.Multiplier * DerivState_pair1.AveragePrice * Math.Abs(DerivState_pair1.NormalBalance) + DerivState_pair2.Multiplier * DerivState_pair2.AveragePrice * Math.Abs(DerivState_pair2.NormalBalance);

                    double pair1_ratio = DerivState_pair1.Multiplier * DerivState_pair1.AveragePrice * Math.Abs(DerivState_pair1.NormalBalance) / total_amount;
                    double pair2_ratio = DerivState_pair2.Multiplier * DerivState_pair2.AveragePrice * Math.Abs(DerivState_pair2.NormalBalance) / total_amount;

                    double pair1_return_percent = 0;
                    double pair2_return_percent = 0;

                    if ((DerivState_pair1.NormalBalance != 0 & DerivState_pair1.AveragePrice == 0) | (DerivState_pair2.NormalBalance != 0 & DerivState_pair2.AveragePrice == 0))
                    {
                        Console.WriteLine("AveragePrice가 0 입니다");
                        Console.WriteLine("");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine("AveragePrice가 0 입니다");
                            writer.WriteLine("");
                        }
                        continue;
                    }

                    if (DerivState_pair1.NormalBalance == 0 & DerivState_pair2.NormalBalance == 0)
                    {
                        Console.WriteLine("pair1.NormalBalance=0 & pair2.NormalBalance=0");
                        SpreadSubStates[pair_key].exit_signal_now = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;


                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine("pair1.NormalBalance=0 & pair2.NormalBalance=0");
                            writer.WriteLine("");
                        }
                        continue;
                    }
                    else if (DerivState_pair1.NormalBalance == 0 | DerivState_pair2.NormalBalance == 0)
                    {   // 한쪽만 체결되거나, 한쪽이 전부다 exit한 상황 : Force Exit 필요!
                        Console.WriteLine($"pair1.NormalBalance:{DerivState_pair1.NormalBalance} & pair2.NormalBalance:{DerivState_pair2.NormalBalance}");
                        Console.WriteLine("pair1, pair2 unbalance!!");
                        SpreadSubStates[pair_key].exit_signal_now = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;


                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"pair1.NormalBalance:{DerivState_pair1.NormalBalance} & pair2.NormalBalance:{DerivState_pair2.NormalBalance}");
                            writer.WriteLine("pair1, pair2 unbalance!!");
                            writer.WriteLine("");
                        }

                        continue;
                    }

                    //Spread long 진입 이면 ,short exit, pair1 short, pair2 long
                    if (DerivState_pair1.NormalBalance > 0 & DerivState_pair2.NormalBalance < 0 & SpreadSubStates[pair_key].entry_side == "long")
                    {
                        SpreadSubStates[pair_key].Pair1NowExitPrice = (double)C.AsDouble(DerivState_pair1.Quote[0].BidPrice);
                        SpreadSubStates[pair_key].Pair2NowExitPrice = (double)C.AsDouble(DerivState_pair2.Quote[0].AskPrice);
                        //spread long기준
                        pair1_return_percent = (SpreadSubStates[pair_key].Pair1NowExitPrice - DerivState_pair1.AveragePrice) / DerivState_pair1.AveragePrice;
                        pair2_return_percent = (DerivState_pair2.AveragePrice - SpreadSubStates[pair_key].Pair2NowExitPrice) / DerivState_pair2.AveragePrice;

                    }// Spread short 진입 이면 ,long exit , pair1 long, pair2 short
                    else if (DerivState_pair1.NormalBalance < 0 & DerivState_pair2.NormalBalance > 0 & SpreadSubStates[pair_key].entry_side == "short")
                    {
                        SpreadSubStates[pair_key].Pair1NowExitPrice = (double)C.AsDouble(DerivState_pair1.Quote[0].AskPrice);
                        SpreadSubStates[pair_key].Pair2NowExitPrice = (double)C.AsDouble(DerivState_pair2.Quote[0].BidPrice);

                        //spread short 기준
                        pair1_return_percent = (DerivState_pair1.AveragePrice - SpreadSubStates[pair_key].Pair1NowExitPrice) / DerivState_pair1.AveragePrice;
                        pair2_return_percent = (SpreadSubStates[pair_key].Pair2NowExitPrice - DerivState_pair2.AveragePrice) / DerivState_pair2.AveragePrice;

                    }

                    double expected_return = (pair1_return_percent * pair1_ratio + pair2_return_percent * pair2_ratio);

                    long Time_after_entry = (DateTime.Now - SpreadSubStates[pair_key].EntryTime).Hours * 60 + (DateTime.Now - SpreadSubStates[pair_key].EntryTime).Minutes;

                    //spraed long 청산 체크
                    bool Profit_flag = expected_return > SpreadSubStates[pair_key].Params.TargetRate ;
                    bool Losscut_flag = expected_return < SpreadSubStates[pair_key].Params.LossCutRate & minute_update_flag;
                    bool Timecut_flag = DateTime.Now > ClosingPriceOrdered.Time ;
                    bool Time_after_bool = Time_after_entry > 60;

                    double pair1_price_stock = SpreadSubStates[pair_key].Pair1NowPrice;
                    double pair2_price_stock = SpreadSubStates[pair_key].Pair2NowPrice;

                    Console.WriteLine($"pair1_exit_price:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair2_exit_price:{SpreadSubStates[pair_key].Pair2NowExitPrice}");
                    Console.WriteLine($"expected_return:{Math.Round(100 * expected_return, 2)}% ,Time_after_entry:{Time_after_entry}분 ,pair1_ratio:{Math.Round(pair1_ratio, 2)},pair2_ratio:{Math.Round(pair2_ratio, 2)}");
                    Console.WriteLine($"Profit_flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.TargetRate , 2)}%,Loss_Flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.LossCutRate, 2)}%");
                    Console.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair1_avg_price:{DerivState_pair1.AveragePrice},pair1_return_percent:{Math.Round(100 * pair1_return_percent, 2)}%");
                    Console.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowExitPrice},pair2_avg_price:{DerivState_pair2.AveragePrice},pair2_return_percent:{Math.Round(100 * pair2_return_percent, 2)}%");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"pair1_exit_price:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair2_exit_price:{SpreadSubStates[pair_key].Pair2NowExitPrice}");
                        writer.WriteLine($"expected_return:{Math.Round(100 * expected_return, 2)}%,,Time_after_entry:{Time_after_entry}분 , pair1_ratio:{Math.Round(pair1_ratio, 2)},pair2_ratio:{Math.Round(pair2_ratio, 2)}");
                        writer.WriteLine($"Profit_flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.TargetRate , 2)}%,Loss_Flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.LossCutRate, 2)}%");
                        writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair1_avg_price:{DerivState_pair1.AveragePrice},pair1_return_percent:{Math.Round(100 * pair1_return_percent, 2)}%");
                        writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowExitPrice},pair2_avg_price:{DerivState_pair2.AveragePrice},pair2_return_percent:{Math.Round(100 * pair2_return_percent, 2)}%");
                      
                        writer.WriteLine("");
                    }

                    if (TradeOffButton.Checked) { continue; }

                    Console.WriteLine("");

                    if (Profit_flag | ( Losscut_flag & Time_after_bool) | Timecut_flag )
                    {
                        SpreadSubStates[pair_key].exit_signal_now = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;

                        if (Profit_flag)
                        {
                            Console.WriteLine($"Exit Profit Take!! {pair_key}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Profit Take!! {pair_key}");
                                writer.WriteLine("");
                            }
                        }
                        else if (Losscut_flag)
                        {
                            Console.WriteLine($"Entry  Loss cut!! {pair_key}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Loss cut!! {pair_key}");
                                writer.WriteLine("");
                            }
                        }else if(Timecut_flag)
                        {
                            Console.WriteLine($"Time cut!! {pair_key}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Time cut!! {pair_key}");
                                writer.WriteLine("");
                            }
                        }

                        Save_spreadsubstates();

                    }

                }

            }
            Console.WriteLine("");

            //Console.WriteLine("");
        }

        private void signal_entry_check_and_order()
        {
            foreach (string pair_key in SpreadSubStates.Keys)
            {

                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;

                var DerivState_pair1 = FuturesSubStates[pair1_shortcode].DerivState;
                var DerivState_pair2 = FuturesSubStates[pair2_shortcode].DerivState;

                long pair1_order_quantity_standard = 9;
                long pair2_order_quantity_standard = 1;

                if (EntryOffButton.Checked) { continue; }


                //미체결된 주문 여부 확인

                if (DerivState_pair1.LiveOrders.Count != 0 | DerivState_pair2.LiveOrders.Count != 0)
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시

                    // 미체결 비율 체크하는 로직 필요
                    if(DerivState_pair1.LiveOrders.Count != 0)
                    {
                        DerivState_pair1.CancelOrders(DerivState_pair1.LiveOrders[0].AskBidType);
                    }

                    if (DerivState_pair2.LiveOrders.Count != 0)
                    {
                        DerivState_pair2.CancelOrders(DerivState_pair2.LiveOrders[0].AskBidType);
                    }
                    
                }

                //
                long Pair1TargetOrderQuantity = SpreadSubStates[pair_key].Pair1TargetOrderQuantity;
                long Pair2TargetOrderQuantity = SpreadSubStates[pair_key].Pair2TargetOrderQuantity;

                //event loop 직전 Quantity
                long NowQuantity_pair1 = FuturesSubStates[pair1_shortcode].NowQuantity;
                long NowQuantity_pair2 = FuturesSubStates[pair2_shortcode].NowQuantity;

                // 현재 Quantity
                long Real_NowQuantity_pair1 = (long)Math.Abs(DerivState_pair1.NormalBalance);
                long Real_NowQuantity_pair2 = (long)Math.Abs(DerivState_pair2.NormalBalance);


                bool target_quantity_complete = (Real_NowQuantity_pair1 == SpreadSubStates[pair_key].Pair1TargetOrderQuantity) & (Real_NowQuantity_pair2 == SpreadSubStates[pair_key].Pair2TargetOrderQuantity);

                if (!SpreadSubStates[pair_key].entry_signal_now)
                {   //entry_today_signal이 존재할시만 주문
                    continue;
                }
                else if (DerivState_pair1.Quote == null | DerivState_pair2.Quote == null)
                {
                    Console.WriteLine("signal_entry_check : Quote 데이터가 null 입니다");
                    continue;
                }


                Console.WriteLine($"Entry Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");

                //entry long
                double pair1AskPrice = C.AsDouble(DerivState_pair1.Quote[0].AskPrice);
                double pair2BidPrice = C.AsDouble(DerivState_pair2.Quote[0].BidPrice);


                //entry short
                double pair1BidPrice = C.AsDouble(DerivState_pair1.Quote[0].BidPrice);
                double pair2AskPrice = C.AsDouble(DerivState_pair2.Quote[0].AskPrice);



                double spread_now = 0;


                if (pair1AskPrice == 0 | pair1BidPrice == 0 | pair1BidPrice == 0 | pair2BidPrice == 0 )
                {
                    Console.WriteLine("pair1,2 Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                //오늘 처음 entry order , 첫번째 주문을 내지 않은 조건에서 실행됌.
                if (!SpreadSubStates[pair_key].first_entry_order_done)
                {
                    SpreadSubStates[pair_key].EntryTime = DateTime.Now;
                    // spread long 진입 pair1 long, pair2 short
                    if (SpreadSubStates[pair_key].entry_side == "long")
                    {

                        long pair1_order_quantity = Math.Min(Pair1TargetOrderQuantity,  pair1_order_quantity_standard);
                        long pair2_order_quantity = Math.Min(Pair2TargetOrderQuantity, pair2_order_quantity_standard);


                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1AskPrice > 1000000000 | pair2BidPrice > 1000000000) { continue; }
                        else if (pair1_order_quantity > 20 | pair2_order_quantity > 20)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }

                        Console.WriteLine($"First Entry Order long {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode}  pair1AskPrice: {pair1AskPrice} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} pair2BidPrice: {pair2BidPrice} pair2_order_quantity:{pair2_order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order long {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode}  pair1AskPrice: {pair1AskPrice} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} pair2BidPrice: {pair2BidPrice} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState_pair1.NewOrder(AskBidType.Bid, pair1AskPrice, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Ask, pair2BidPrice, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;
                        

                    }// spread short 진입 pair1 short, pair2 long
                    else if (SpreadSubStates[pair_key].entry_side == "short")
                    {
                        long pair1_order_quantity = Math.Min(Pair1TargetOrderQuantity, pair1_order_quantity_standard);
                        long pair2_order_quantity = Math.Min(Pair2TargetOrderQuantity, pair2_order_quantity_standard);

                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1AskPrice > 1000000000 | pair1AskPrice > 1000000000) { continue; }
                        else if (pair1_order_quantity > 20 | pair2_order_quantity > 20)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"First Entry Order short {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} pair1BidPrice: {pair1BidPrice} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode}  pair2AskPrice: {pair2AskPrice} pair2_order_quantity:{pair2_order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order short {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} pair1BidPrice: {pair1BidPrice} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode}  pair2AskPrice: {pair2AskPrice} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }


                        //AskBidType.Bid: long , AskBidType.Ask: short
                        DerivState_pair1.NewOrder(AskBidType.Ask, pair1BidPrice, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Bid, pair2AskPrice, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;


                    }

                    //주문을 냈으므로 True로 변환 , 다음 loop에선 들어가지 않음
                    SpreadSubStates[pair_key].first_entry_order_done = true;
                    Save_spreadsubstates();
                    Console.WriteLine("");
                }
                else // order entry이후 order check, 미체결 및  재진입 여부 판단 
                {

                    if (!target_quantity_complete) //미체결이 없을시 & target_quantity에서 현재 quantity 를 뺀금액만큼 추가주문
                    {

                        //time event 직전 Quantity와 차이가 있을때 체결이 되었다 가정
                        if (NowQuantity_pair1 != Real_NowQuantity_pair1 | NowQuantity_pair2 != Real_NowQuantity_pair2)
                        {
                            Console.WriteLine($"Pair1TargetOrderQuantity:{Pair1TargetOrderQuantity} , Real_NowQuantity_pair1 {Real_NowQuantity_pair1}");
                            Console.WriteLine($"Pair2TargetOrderQuantity:{Pair2TargetOrderQuantity} , Real_NowQuantity_pair2 {Real_NowQuantity_pair2}");

                            // 현재 balance로 amount 업데이트
                            FuturesSubStates[pair1_shortcode].NowQuantity = Real_NowQuantity_pair1;
                            FuturesSubStates[pair2_shortcode].NowQuantity = Real_NowQuantity_pair2;

                            //재주문을 내야하는 quantity를 계산함
                            long reentry_order_quantity_pair1 = SpreadSubStates[pair_key].Pair1TargetOrderQuantity - Real_NowQuantity_pair1;
                            long reentry_order_quantity_pair2 = SpreadSubStates[pair_key].Pair2TargetOrderQuantity - Real_NowQuantity_pair2;

                            if (SpreadSubStates[pair_key].entry_side == "long")
                            {

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, pair1_order_quantity_standard);
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, pair2_order_quantity_standard);


                                Console.WriteLine($"Entry reentry Order long {pair_key}");


                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Bid, pair1AskPrice, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;


                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair2.NewOrder(AskBidType.Ask, pair2BidPrice, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;


                                }
                            }
                            else if (SpreadSubStates[pair_key].entry_side == "short")
                            {

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, pair1_order_quantity_standard);
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, pair2_order_quantity_standard);


                                Console.WriteLine($"Entry reentry Order short {pair_key}");


                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Ask, pair1BidPrice, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;



                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair2.NewOrder(AskBidType.Bid, pair2AskPrice, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;

                                }
                            }
                            Save_spreadsubstates();
                            Console.WriteLine("");
                        }


                    }
                    else
                    {
                        //Console.WriteLine("이미 target_amount를 채웠습니다");
                        SpreadSubStates[pair_key].exit_monitoring = true;

                        // 진입 주문 함수에 들어오지 못하게 하는 flag
                        SpreadSubStates[pair_key].entry_signal_now = false;

                        //exit에선 현재 잔고를 기반으로 target order quanity가 정해지므로 초기화함
                        SpreadSubStates[pair_key].Pair1TargetOrderQuantity = 0;
                        SpreadSubStates[pair_key].Pair2TargetOrderQuantity = 0;

                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = 0;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = 0;
                        Save_spreadsubstates();

                        Console.WriteLine($"target_quantity_order_complete {pair_key}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"target_quantity_order_complete {pair_key}");
                            writer.WriteLine("");
                        }
                    }



                }

            }

        }


        private void signal_exit_check_and_order()
        {
            foreach (string pair_key in SpreadSubStates.Keys)
            {

                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;

                var DerivState_pair1 = FuturesSubStates[pair1_shortcode].DerivState;
                var DerivState_pair2 = FuturesSubStates[pair2_shortcode].DerivState;

                long pair1_order_quantity_standard = 9;
                long pair2_order_quantity_standard = 1;

                if (TradeOffButton.Checked) { continue; }


                //미체결된 주문 여부 확인

                //미체결된 주문 여부 확인

                if (DerivState_pair1.LiveOrders.Count != 0 | DerivState_pair2.LiveOrders.Count != 0)
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시

                    // 미체결 비율 체크하는 로직 필요
                    if (DerivState_pair1.LiveOrders.Count != 0)
                    {
                        DerivState_pair1.CancelOrders(DerivState_pair1.LiveOrders[0].AskBidType);
                    }

                    if (DerivState_pair2.LiveOrders.Count != 0)
                    {
                        DerivState_pair2.CancelOrders(DerivState_pair2.LiveOrders[0].AskBidType);
                    }

                }

                //
                //long Pair1TargetOrderQuantity = SpreadSubStates[pair_key].Pair1TargetOrderQuantity;
                //long Pair2TargetOrderQuantity = SpreadSubStates[pair_key].Pair2TargetOrderQuantity;

                //event loop 직전 Quantity
                long NowQuantity_pair1 = FuturesSubStates[pair1_shortcode].NowQuantity;
                long NowQuantity_pair2 = FuturesSubStates[pair2_shortcode].NowQuantity;

                // 현재 Quantity
                long Real_NowQuantity_pair1 = (long)Math.Abs(DerivState_pair1.NormalBalance);
                long Real_NowQuantity_pair2 = (long)Math.Abs(DerivState_pair2.NormalBalance);


                bool target_quantity_complete = (Real_NowQuantity_pair1 == 0) & (Real_NowQuantity_pair2 == 0);

                if (!SpreadSubStates[pair_key].exit_signal_now)
                {   //entry_today_signal이 존재할시만 주문
                    continue;
                }
                else if (DerivState_pair1.Quote == null | DerivState_pair2.Quote == null)
                {
                    Console.WriteLine("signal_entry_check : Quote 데이터가 null 입니다");
                    continue;
                }
                else if (!SpreadSubStates[pair_key].Enabled)
                {
                    Console.WriteLine("거래금지 종목이 포함된 페어입니다.");
                    Console.WriteLine("");
                    continue;
                }

                Console.WriteLine($"Entry Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");

                //entry long
                double pair1AskPrice = C.AsDouble(DerivState_pair1.Quote[0].AskPrice);
                double pair2BidPrice = C.AsDouble(DerivState_pair2.Quote[0].BidPrice);


                //entry short
                double pair1BidPrice = C.AsDouble(DerivState_pair1.Quote[0].BidPrice);
                double pair2AskPrice = C.AsDouble(DerivState_pair2.Quote[0].AskPrice);



                double spread_now = 0;


                if (pair1AskPrice == 0 | pair1BidPrice == 0 | pair1BidPrice == 0 | pair2BidPrice == 0)
                {
                    Console.WriteLine("pair1,2 Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                //오늘 처음 entry order , 첫번째 주문을 내지 않은 조건에서 실행됌.
                if (!SpreadSubStates[pair_key].first_exit_order_done)
                {

                    // spread long 진입 pair1 long, pair2 short
                    if (SpreadSubStates[pair_key].entry_side == "short")
                    {

                        long pair1_order_quantity = Math.Min(Real_NowQuantity_pair1, pair1_order_quantity_standard);
                        long pair2_order_quantity = Math.Min(Real_NowQuantity_pair2, pair2_order_quantity_standard);


                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1AskPrice > 1000000000 | pair2BidPrice > 1000000000) { continue; }
                        else if (pair1_order_quantity > 20 | pair2_order_quantity > 20)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }

                        Console.WriteLine($"First Entry Order long {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode}  pair1AskPrice: {pair1AskPrice} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} pair2BidPrice: {pair2BidPrice} pair2_order_quantity:{pair2_order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order long {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode}  pair1AskPrice: {pair1AskPrice} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} pair2BidPrice: {pair2BidPrice} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState_pair1.NewOrder(AskBidType.Bid, pair1AskPrice, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Ask, pair2BidPrice, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;


                    }// spread short 진입 pair1 short, pair2 long
                    else if (SpreadSubStates[pair_key].entry_side == "long")
                    {
                        long pair1_order_quantity = Math.Min(Real_NowQuantity_pair1, pair1_order_quantity_standard);
                        long pair2_order_quantity = Math.Min(Real_NowQuantity_pair2, pair2_order_quantity_standard);

                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1AskPrice > 1000000000 | pair1AskPrice > 1000000000) { continue; }
                        else if (pair1_order_quantity > 20 | pair2_order_quantity > 20)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"First Entry Order short {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} pair1BidPrice: {pair1BidPrice} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode}  pair2AskPrice: {pair2AskPrice} pair2_order_quantity:{pair2_order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order short {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} pair1BidPrice: {pair1BidPrice} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode}  pair2AskPrice: {pair2AskPrice} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }


                        //AskBidType.Bid: long , AskBidType.Ask: short
                        DerivState_pair1.NewOrder(AskBidType.Ask, pair1BidPrice, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Bid, pair2AskPrice, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;


                    }

                    //주문을 냈으므로 True로 변환 , 다음 loop에선 들어가지 않음
                    SpreadSubStates[pair_key].first_exit_order_done = true;

                    // 현재 balance로 amount 업데이트
                    FuturesSubStates[pair1_shortcode].NowQuantity = Real_NowQuantity_pair1;
                    FuturesSubStates[pair2_shortcode].NowQuantity = Real_NowQuantity_pair2;
                    Save_spreadsubstates();
                    Console.WriteLine("");
                }
                else // order entry이후 order check, 미체결 및  재진입 여부 판단 
                {

                    if (!target_quantity_complete) //미체결이 없을시 & target_quantity에서 현재 quantity 를 뺀금액만큼 추가주문
                    {

                        //time event 직전 Quantity와 차이가 있을때 체결이 되었다 가정
                        if (NowQuantity_pair1 != Real_NowQuantity_pair1 | NowQuantity_pair2 != Real_NowQuantity_pair2)
                        {
                            Console.WriteLine($"Real_NowQuantity_pair1 {Real_NowQuantity_pair1}");
                            Console.WriteLine($"Real_NowQuantity_pair2 {Real_NowQuantity_pair2}");

                            // 현재 balance로 amount 업데이트
                            FuturesSubStates[pair1_shortcode].NowQuantity = Real_NowQuantity_pair1;
                            FuturesSubStates[pair2_shortcode].NowQuantity = Real_NowQuantity_pair2;

                            //재주문을 내야하는 quantity를 계산함
                            long reentry_order_quantity_pair1 = Real_NowQuantity_pair1;
                            long reentry_order_quantity_pair2 = Real_NowQuantity_pair2;

                            if (SpreadSubStates[pair_key].entry_side == "short")
                            {

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, pair1_order_quantity_standard);
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, pair2_order_quantity_standard);


                                Console.WriteLine($"Entry reentry Order long {pair_key}");


                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Bid, pair1AskPrice, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;


                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair2.NewOrder(AskBidType.Ask, pair2BidPrice, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;


                                }
                            }
                            else if (SpreadSubStates[pair_key].entry_side == "long")
                            {

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, pair1_order_quantity_standard);
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, pair2_order_quantity_standard);


                                Console.WriteLine($"Entry reentry Order short {pair_key}");


                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1AskPrice: {pair1AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Ask, pair1BidPrice, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;



                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 20 | reentry_order_quantity_pair2 > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2BidPrice: {pair2BidPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair2.NewOrder(AskBidType.Bid, pair2AskPrice, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;

                                }
                            }
                            Save_spreadsubstates();
                            Console.WriteLine("");
                        }


                    }
                    else
                    {
                        Console.WriteLine($"All Complete Exit {pair_key}");
                        //변수 초기화
                        SpreadSubStates[pair_key].entry_signal_now = false;
                        SpreadSubStates[pair_key].exit_signal_now = false;

                        SpreadSubStates[pair_key].first_entry_order_done = false;
                        SpreadSubStates[pair_key].first_exit_order_done = false;

                        SpreadSubStates[pair_key].exit_monitoring = false;

                        SpreadSubStates[pair_key].entry_side = null;

                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = 0;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = 0;
                        SpreadSubStates[pair_key].already_exit = true;
                        Save_spreadsubstates();
                    }



                }

            }

        }


        private void Save_spreadsubstates()
        {
            // Person 클래스 직렬화하여 C:\Users\234046\Desktop\release\StockFuturesPairRsi 경로에 저장 (관리자 권한 필요)

            string filePath_states = $@"C:\Users\234046\Desktop\States\IndexFuturePairIntraBreak\SpreadSubStates_{DateTime.Now.ToString("yyyy-MM-dd")}.dat";

            using (FileStream fileStream = new FileStream(filePath_states, FileMode.Create))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, SpreadSubStates);
            }
            Console.WriteLine("딕셔너리 Spread Sub State Class Update Complete");
        }

        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsDouble(TargetRateBox.Text) / 100,
                C.AsDouble(LossCutRateBox.Text) / 100,
                C.AsLong(MaxNotionalAmountBox.Text) * 100_000_000,
                C.AsLong(C.AsDouble(MaxAmountPerOrderBox.Text) * 100_000_000),
                C.AsLong(C.AsDouble(OrderAmountBox.Text) )
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }


        public void Enable() { this.Enabled = true; }

        private class FuturesSubState
        {
            public string StandardCode { get; private set; }
            public string ShortCode { get; private set; }
            public string Name { get; private set; }
            public DerivState DerivState { get; private set; }

            public string Easyname;

            public long NowQuantity = 0;
            public long remainQuantity;

            public double today_open;

            public List<double> PriceSet = new List<double>();
            public List<string> DatetimeSet = new List<string>();
            public List<double> NormReturnSet = new List<double>();

            public FuturesSubState(DerivState deriveState, string standardCode, string shortCode, string name)
            {
                this.DerivState = deriveState;
                this.StandardCode = standardCode;
                this.ShortCode = shortCode;
                this.Name = name;
            }
        }

        [Serializable]
        class SpreadSubState
        {

            public StrategyParams Params;

            public List<double> Pair1PriceSet = new List<double>();
            public List<double> Pair2PriceSet = new List<double>();
            public List<double> normSpreadSet = new List<double>();


            public string Pair1ShortCode;
            public string Pair2ShortCode;

            public string Pair1FuturesShortCode;
            public string Pair2FuturesShortCode;

            public double Pair1NowPrice;
            public double Pair2NowPrice;

            public double Pair1NowEntryPrice;
            public double Pair2NowEntryPrice;

            public double Pair1NowExitPrice;
            public double Pair2NowExitPrice;

            public long Pair1TargetOrderQuantity;
            public long Pair2TargetOrderQuantity;

            public long Pair1RecentOrderQuantity;
            public long Pair2RecentOrderQuantity;

            public double cointvalue;
            public double TakeProfitAdj;
            public double LossCutAdj;

            public double pre_spread_vol;
            public double spread_past1_min;
            public DateTime minute1_pre;
            public DateTime EntryTime;


            public bool HasPendingRequest = false;
            public string entry_side = null;

            // entry exit signal 발생 flag
            public bool entry_signal_now = false;
            public bool exit_signal_now = false;

            //entry exit signal 이후 첫주문이 나갔는지 여부
            public bool first_entry_order_done = false;
            public bool first_exit_order_done = false;

            //exit 모니터링 여부 flag
            public bool exit_monitoring = false;

            public bool Enabled = true;
            public bool already_exit = false;

            public bool already_break_long_by_const = false;
            public bool already_break_short_by_const = false;

            public SpreadSubState(StrategyParams strategyParams)
            {
                this.Params = strategyParams;
            }

        }



        [Serializable]
        internal class StrategyParams
        {

            public double TargetRate { get; private set; }
            public double LossCutRate { get; private set; }
            public long MaxNotionalAmount { get; private set; }
            public long MaxAmountPerOrder { get; private set; }
            public long OrderAmount { get; private set; }
            public void StartegyParams()
            {
            }
            private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
            private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

            public bool Update(
                               double targetRate,
                               double losscutRate,
                               long maxNotionalAmount,
                               long maxAmountPerOrder,
                               long OrderAmount)
            {
                if (!DoubleGreaterThan(targetRate, 0.0))
                    return false;

                if (!DoubleLessThan(losscutRate, 0.0))
                    return false;

                if (DoubleGreaterThan(losscutRate, targetRate))
                    return false;

                if (maxAmountPerOrder <= 0)
                    return false;


                this.TargetRate = targetRate;
                this.LossCutRate = losscutRate;

                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxAmountPerOrder = maxAmountPerOrder;
                this.OrderAmount = OrderAmount;


                return true;
            }
        }


        private void PauseButton_Click(object sender, EventArgs e)
        {
            working_flag = false;
        }

        private void ResumeButton_Click(object sender, EventArgs e)
        {
            working_flag = true;
        }

    }
}