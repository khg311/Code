﻿using System.Runtime.InteropServices;

namespace PnK_indi
{
    public struct QUOTE_HEADER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // DATA구분 : A3

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] InformationType;              // 정보구분, 01:주식 / 02:ELW

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] MarketType;                   // 시장구분, 1:유가증권 / 2:코스닥
    }

    // 체결 - 코스피, 코스닥, ETF, ETN, ELW
    public struct IFMSRPD0004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] PriceChangeType;          // 전일대비구분, 0:초기값 / 1:상한 / 2:상승 / 3:보합 / 4:하한 / 5:하락

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] WonChange;                    // 전일대비가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] TradingPrice;                 // 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] TradingVolume;                // 거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] OpenPrice;                    // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] HighPrice;                    // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] LowPrice;                     // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] CumulativeTradingVolume;      // 누적거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
        public char[] CumulativeTradingAmount;      // 누적거래대금

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] AskBidType;                   // 최종매도매수구분코드, 0:해당없음 1:매도 / 2:매수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] LpHoldingVolume;              // LP보유수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] Ask1Price;                    // 매도1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] Bid1Price;                    // 매수1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    //  호가 - 코스피, 코스닥
    public struct IFMSRPD0002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public Quote[] Quote;                       // 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TotalAskQuantity;                 // 10단계호가매도총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TotalBidQuantity;                 // 10단계호가매수총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] ExpectedTradingPrice;             // 예상체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] ExpectedTradingVolume;            // 예상체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct Quote
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] AskPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] BidPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] AskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] BidQuantity;
    }

    public struct IFMSRPD0007
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public ETPQuote[] Quote;                       // 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TotalAskQuantity;                 // 10단계호가매도총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TotalBidQuantity;                 // 10단계호가매수총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] ExpectedTradingPrice;             // 예상체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] ExpectedTradingVolume;            // 예상체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct ETPQuote
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] AskPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] BidPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] AskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] BidQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] LPAskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] LPBidQuantity;
    }

    public struct IFMSRPD0034
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public DerivQuote[] Quote;                   // 5단계 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalAskQuantity;             // 매도호가총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalBidQuantity;             // 매수호가총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalAskEffectiveContracts;   // 매도호가유효건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalBidEffectiveContracts;   // 매수호가유효건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ExpectedTradingPrice;         // 예상체결가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct IFMSRPD0035
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public DerivQuote[] Quote;                   // 5단계 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalAskQuantity;             // 매도호가총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalBidQuantity;             // 매수호가총잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalAskEffectiveContracts;   // 매도호가유효건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalBidEffectiveContracts;   // 매수호가유효건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ExpectedTradingPrice;         // 예상체결가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct IFMSRPD0037
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TradingPrice;                  // 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TradingVolume;                  // 거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] NearTradingPrice;                  // 근월물 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] FarTradingPrice;                  // 원월물 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] OpenPrice;                  // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] HighPrice;                  // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] LowPrice;                  // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] PreviousPrice;                  // 직전가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] CumulativeTradingVolume;                  // 누적거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
        public char[] CumulativeTradingAmount;                  // 누적거래대금

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] AskBidType;                  // 매도매수구분코드   " ": 단일가체결, 1:매도, 2:매수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] DynamicUpperPrice;                  // 동적상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] DynamicLowerPrice;                  // 동적하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public DerivQuote[] Quote;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalAskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalBidQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalAskSize;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalBidSize;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct IFMSRPD0038
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] DataType;                     // 데이터구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] InformationType;              // 정보구분값

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] InformationSerialNumber;       // 정보분배일련번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] BoardId;                      // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] SessionId;                      // 세션ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] StandardCode;                 // 종목코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] SecurityIndex;                 // 정보분배종목인덱스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] TradingTime;                  // 매매처리시각 (ms 단위)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TradingPrice;                  // 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TradingVolume;                  // 거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] NearTradingPrice;                  // 근월물 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] FarTradingPrice;                  // 원월물 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] OpenPrice;                  // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] HighPrice;                  // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] LowPrice;                  // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] PreviousPrice;                  // 직전가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] CumulativeTradingVolume;                  // 누적거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
        public char[] CumulativeTradingAmount;                  // 누적거래대금

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] AskBidType;                  // 매도매수구분코드   " ": 단일가체결, 1:매도, 2:매수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] DynamicUpperPrice;                  // 동적상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] DynamicLowerPrice;                  // 동적하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public DerivQuote[] Quote;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalAskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] TotalBidQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalAskSize;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] TotalBidSize;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] EndOfText;
    }

    public struct DerivQuote
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] AskPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] BidPrice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] AskQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] BidQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] AskSize;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] BidSize;
    }
}
