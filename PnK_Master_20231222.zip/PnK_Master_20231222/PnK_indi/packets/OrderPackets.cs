﻿using System.Runtime.InteropServices;

namespace PnK_indi
{
    struct DERIV_ORDER_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIV_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 272)]
        public DERIV_KRX_ORDER krxOrder;
    }

    struct DERIV_EXECUTION_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIV_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 232)]
        public DERIV_EXECUTION execution;
    }

    struct DERIV_CONFIRM_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIV_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 354)]
        public DERIV_CONFIRM confirm;
    }

    struct DERIV_REJECT_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIV_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 352)]
        public DERIV_REJECT reject;
    }

    #region Derivative Order Packet Header
    struct DERIV_HEADER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tr_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ack_gubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] seq_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] emp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_l_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] com_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] res_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] org_ord_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mysvr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_kind;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_offset;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] resord_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] unfair_chk_yn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] nego_ord_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 13)]
        public char[] filler;
    }
    #endregion

    #region Derivative KRX order
    struct DERIV_KRX_ORDER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (매칭그룹번호)
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]           // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]            // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIVORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (알고리즘전략구분코드)
        public char[] algo_stgy_tp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 (거래자ID)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (호가그룹번호)
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (자전거래방지코드)
        public char[] smp_cd;
    }
    #endregion

    #region Derivative Order Hoiwon
    struct DERIVORDER_HOIWON
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fep_org;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] market_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] channel_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] system_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] filler1;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] filler2;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] client_idx;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] auto_order;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
        public char[] filler3;
    }
    #endregion

    #region Derivative Execution message
    struct DERIV_EXECUTION
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] che_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] che_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] che_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] session_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] che_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] che_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] pyakprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] nyakprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]            // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIVORDER_HOIWON hoiwon;
    }
    #endregion

    #region Derivative Confirm message
    struct DERIV_CONFIRM
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]               // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIVORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jubsu_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] jungcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] auto_canl_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] rejcode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (알고리즘전략구분코드)
        public char[] algo_stgy_tp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 (거래자ID)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (호가그룹번호)
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (자전거래방지코드)
        public char[] smp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 58)]
        public char[] filler;
    }
    #endregion

    #region Derivative Reject message
    struct DERIV_REJECT
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]               // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public DERIVORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jubsu_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] jungcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] auto_canl_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] rejcode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (알고리즘전략구분코드)
        public char[] algo_stgy_tp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 (거래자ID)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (호가그룹번호)
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (자전거래방지코드)
        public char[] smp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 58)]
        public char[] filler;
    }
    #endregion





    struct STOCK_ORDER_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 75)]
        public STOCK_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 272)]
        public STOCK_KRX_ORDER krxOrder;
    }

    struct STOCK_EXECUTION_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 75)]
        public STOCK_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 232)]
        public STOCK_EXECUTION execution;
    }

    struct STOCK_CONFIRM_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 75)]
        public STOCK_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 355)]
        public STOCK_CONFIRM confirm;
    }

    struct STOCK_REJECT_PACKET
    {
        [MarshalAs(UnmanagedType.Struct, SizeConst = 75)]
        public STOCK_HEADER header;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 353)]
        public STOCK_REJECT reject;
    }


    #region Stock Order Packet Header
    struct STOCK_HEADER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tr_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ack_gubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] seq_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] emp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_l_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] com_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] res_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mysvr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] secu_grpid;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] loan_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] tord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_tord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] shtsl_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] shtsl_flg;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] org_ord_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] filler;
    }
    #endregion

    #region Stock KRX order
    struct STOCK_KRX_ORDER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]            // 차세대 신규 추가 : 매칭그룹번호
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]            // 차세대 변경 (S: GTS 추가)
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]           // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]           // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public STOCKORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 : 알고리즘전략구분코드 (1:신규, '':정정취소)
        public char[] algo_stgy_tp_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 : 거래자ID (90025 TR에서 전송받은 정보 사용)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 : 호가그룹번호
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 : 자전거래방지코드 (0:해당없음, 1:기존호가취소, 2:신규호가취소, 3:양방향호가취소)
        public char[] smp_cd;
    }
    #endregion

    #region Stock Order Hoiwon
    struct STOCKORDER_HOIWON
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fep_org;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] market_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] channel_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] system_flag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] filler1;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] emp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] filler2;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] loan_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] filler3;
    }
    #endregion

    #region Stock Execution message
    struct STOCK_EXECUTION
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] che_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] che_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] che_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] session_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] che_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] che_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] pyakprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] nyakprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public STOCKORDER_HOIWON hoiwon;
    }
    #endregion

    #region Stock Confirm message
    struct STOCK_CONFIRM
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] me_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]               // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public STOCKORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jubsu_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] jungcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] auto_canl_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] rejcode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (알고리즘전략구분코드)
        public char[] algo_stgy_tp_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 (거래자ID)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (호가그룹번호)
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (자전거래방지코드)
        public char[] smp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 58)]
        public char[] filler;
    }
    #endregion

    #region Stock Reject message
    struct STOCK_REJECT
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] hseq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] trans_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] board_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] memberno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bpno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mmgubun;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hogagb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] cnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]               // 차세대 신규 추가 (최소체결수량)
        public char[] min_trdvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 변경 (11 -> 1)
        public char[] market_ord_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stock_state_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stock_trade_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] medo_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] singb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] witak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] witakcomp_num;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] sub_stock_gyejwa;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_type_code;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] gyejwa_margin_cod;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] kukga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tocode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] foreign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meache_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] term_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mac_addr;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_date;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_time;

        [MarshalAs(UnmanagedType.Struct, SizeConst = 60)]
        public STOCKORDER_HOIWON hoiwon;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jubsu_time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] jungcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] auto_canl_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] rejcode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (알고리즘전략구분코드)
        public char[] algo_stgy_tp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]                // 차세대 신규 추가 (거래자ID)
        public char[] trdr_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]                // 차세대 신규 추가 (호가그룹번호)
        public char[] ord_grp_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]                // 차세대 신규 추가 (자전거래방지코드)
        public char[] smp_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 58)]
        public char[] filler;
    }
    #endregion
}
