﻿using System.Runtime.InteropServices;

namespace PnK_indi
{
    #region TR 헤더
    struct TR_HEADER
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trcode;                   // TR 번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] trgb;                     // TR 구분, 1: Single / 2: Multi / 3: Error

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] key;                      // 화면구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] attr;                     // 1: Start / 2: Data, 3: End

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ip;                       // IP 주소

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] userid;                   // 사용자 ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] dist;                     // 멀티 서비스

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] svr;                      // 서버 지정, blank: Local / 1: SVR1 / 2: SVR2

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] userarea;                 // 유저 영역
    }
    #endregion

    #region Q20001 : KOSPI200 선물/옵션 10단계 호가
    struct IN_Q20001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q20001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] price;                        // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] preprice;                     // 전일종가                       

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] uplmtprice;                   // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] dnlmtprice;                   // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offerho;                      // 매도1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidho;                        // 매수1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;                     // 매도1잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;                       // 매수1잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] P_offer;                      // 매도2호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] P_bid;                        // 매수2호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_offerrem;                   // 매도2잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_bidrem;                     // 매수2잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S_offer;                      // 매도3호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S_bid;                        // 매수3호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_offerrem;                   // 매도3잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_bidrem;                     // 매수3잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S4_offer;                     // 매도4호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S4_bid;                       // 매수4호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_offerrem;                  // 매도4잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_bidrem;                    // 매수4잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S5_offer;                     // 매도5호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] S5_bid;                       // 매수5호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_offerrem;                  // 매도5잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_bidrem;                    // 매수5잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] T_offerrem;                   // 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] T_bidrem;                     // 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offersu;                      // 매도1건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] joffersu;                     // 매도2건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjoffersu;                    // 매도3건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4offersu;                    // 매도4건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5offersu;                    // 매도5건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] toffersu;                     // 총매도호가건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidsu;                        // 매수1건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jbidsu;                       // 매수2건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjbidsu;                      // 매수3건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4bidsu;                      // 매수4건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5bidsu;                      // 매수5건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] tbidsu;                       // 총매수호가건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] fuvolume;                     // 누적체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jun_open_prc;                 // 전일시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jun_high_prc;                 // 전일고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jun_low_prc;                  // 전일저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ycga;                         // 예상체결가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] stnd_cd;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] rt_yn;                        // 동적가격제한여부

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] rt_hilmt;                     // 동적상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] rt_lolmt;                     // 동적하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] exer_prc;                     // 행사가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] price_lmt_final;              // 가격제한 최종단계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] final_hilmt_price;            // 최종단계 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] final_lolmt_price;            // 최종단계 하한가
    }
    #endregion

    #region Q20002 : KOSPI200 선물/옵션 현재가
    struct IN_Q20002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q20002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] uplmtprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] dnlmtprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] preprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] recprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuopen;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuhigh;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fulow;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] fusign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuchange;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuvolume;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] his_vola;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuspvolall;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] openyak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] opvalue;
    }
    #endregion

    #region Q20003 : 월물별 KOSPI200 옵션조회
    struct IN_Q20003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] month;
    }

    struct OUT_Q20003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q20003_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] pre_close;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] volume;
    }
    #endregion

    #region Q20004 : KOSPI200 선물/옵션 시간대별 체결
    struct IN_Q20004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;
    }

    struct OUT_Q20004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q20004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] movvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] movsign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_price;
    }
    #endregion

    #region Q22001 : 주식 선물/옵션 10단계 호가
    struct IN_Q22001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;
    }

    struct OUT_Q22001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] preprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] uplmtprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] dnlmtprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] P_offer;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] P_bid;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] joffersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jbidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjoffersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjbidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S4_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S4_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S5_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S5_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S6_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S6_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S6_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S6_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j6offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j6bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S7_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S7_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S7_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S7_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j7offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j7bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S8_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S8_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S8_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S8_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j8offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j8bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S9_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S9_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S9_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S9_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j9offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j9bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S10_offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] S10_bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S10_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S10_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j10offersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j10bidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] T_offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] T_bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] toffersu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] tbidsu;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuopen;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuhigh;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fulow;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] fuvolume;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ycga;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] openyak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] preopenyak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] base_isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] base_mkt_c;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] base_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] base_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] sp_tick;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] stnd_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 21)]
        public char[] tr_unt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] rt_yn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rt_hilmt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rtlolmt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] exer_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] price_lmt_final;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] final_hilmt_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] final_lolmt_price;
    }
    #endregion

    #region Q22002 : 주식 선물/옵션 미니 현재가
    struct IN_Q22002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q22002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] uplmtprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] dnlmtprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] preprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] recprice;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuopen;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuhigh;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fulow;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] fusign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuchange;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] fuvolume;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] his_vola;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] fuspvolall;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] openyak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] opvalue;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] sp_tick;
    }
    #endregion

    #region Q22003 : 주식 선물/옵션 시간대별 체결내역
    struct IN_Q22003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;
    }

    struct OUT_Q22003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q22003_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] movvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] movsign;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;
    }
    #endregion

    #region Q22004 : 주식옵션 월물별 조회
    struct IN_Q22004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] month;
    }

    struct OUT_Q22004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q22004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] exer_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] volume;
    }
    #endregion

    #region Q26001 : 코스닥선물 5단계호가
    struct IN_Q26001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q26001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] price;                        // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] preprice;                     // 전일종가                       

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] uplmtprice;                   // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] dnlmtprice;                   // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] offerho;                      // 매도1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] bidho;                        // 매수1호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;                     // 매도1잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;                       // 매수1잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] P_offer;                      // 매도2호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] P_bid;                        // 매수2호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_offerrem;                   // 매도2잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] P_bidrem;                     // 매수2잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S_offer;                      // 매도3호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S_bid;                        // 매수3호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_offerrem;                   // 매도3잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S_bidrem;                     // 매수3잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S4_offer;                     // 매도4호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S4_bid;                       // 매수4호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_offerrem;                  // 매도4잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S4_bidrem;                    // 매수4잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S5_offer;                     // 매도5호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] S5_bid;                       // 매수5호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_offerrem;                  // 매도5잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] S5_bidrem;                    // 매수5잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] T_offerrem;                   // 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] T_bidrem;                     // 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offersu;                      // 매도1건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] joffersu;                     // 매도2건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjoffersu;                    // 매도3건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4offersu;                    // 매도4건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5offersu;                    // 매도5건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] toffersu;                     // 총매도호가건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidsu;                        // 매수1건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jbidsu;                       // 매수2건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] jjbidsu;                      // 매수3건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j4bidsu;                      // 매수4건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] j5bidsu;                      // 매수5건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] tbidsu;                       // 총매수호가건수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] fuvolume;                     // 누적체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] jun_open_prc;                 // 전일시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] jun_high_prc;                 // 전일고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] jun_low_prc;                  // 전일저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ycga;                         // 예상체결가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] stnd_cd;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] rt_yn;                        // 동적가격제한여부

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] rt_hilmt;                     // 동적상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] rt_lolmt;                     // 동적하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] exer_prc;                     // 행사가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] price_lmt_final;              // 가격제한 최종단계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] final_hilmt_price;            // 최종단계 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] final_lolmt_price;            // 최종단계 하한가
    }
    #endregion

    #region Q26002 : 코스닥선물 미니 현재가
    struct IN_Q26002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q26002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] uplmtprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] dnlmtprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] preprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] recprice;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuopen;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuhigh;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fulow;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] fusign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuchange;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuvolume;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] his_vola;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fuspvolall;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] openyak;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] opvalue;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_cls;
    }
    #endregion

    #region Q26003 : 월물별 코스닥옵션 조회
    struct IN_Q26003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] month;
    }

    struct OUT_Q26003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] rcnt;
    }

    struct OUT_Q26003_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] pre_close;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] offerho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] bidho;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] offerrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] bidrem;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] volume;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] exer_prc;
    }
    #endregion

    #region Q26004 : 코스닥선물 변동거래량
    struct IN_Q26004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q26004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q26004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] time;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] movvol;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] movsign;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_price;
    }
    #endregion

    #region Q30001 : KOSPI200 선물/옵션 체결내역
    struct IN_Q30003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] che_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;
    }

    struct OUT_Q30003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tot_conc_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] tot_conc_qty;
    }

    struct OUT_Q30003_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] ord_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] conc_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] rem_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] cert;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] crctn_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] cnlt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] rpt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_ty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] rjct_rsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] conc_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] prvsday_clng_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stnd_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] trade_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] algo_strgy_tp_code;           // 알고리즘 TP 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trdr_id;                      // 거래자코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] ord_grp_no;                   // 호가그룹ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] smp_cd;                       // 자전거래방지코드
    }
    #endregion

    #region Q30004 : 주문번호에 대한 KOSPI200 선물/옵션 체결내역
    struct IN_Q30004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;
    }

    struct OUT_Q30004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q30004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] conc_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;
    }
    #endregion

    #region Q30011 : KOSPI200 선물/옵션 종목코드별 체결내역
    struct IN_Q30011
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] che_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;
    }

    struct OUT_Q30011
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;
    }

    struct OUT_Q30011_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] ord_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] conc_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] rem_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] cert;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] crctn_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] cnlt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] rpt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_ty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] rjct_rsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] conc_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] prvsday_clng_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stnd_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] trade_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;
    }
    #endregion

    #region Q32001 : 주식 선물/옵션 체결내역
    struct IN_Q32001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] che_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;
    }

    struct OUT_Q32001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tot_conc_amt;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] tot_conc_qty;
    }

    struct OUT_Q32001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rem_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] cert;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] crctn_qty;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] cnlt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rpt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_ty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] rjct_rsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] conc_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prvsday_clng_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stnd_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] trade_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] algo_strgy_tp_code;           // 알고리즘 TP 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trdr_id;                      // 거래자코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] ord_grp_no;                   // 호가그룹ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] smp_cd;                       // 자전거래방지코드
    }
    #endregion

    #region Q36001 : 코스닥선물 체결내역 조회
    struct IN_Q36001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] che_gb;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;
    }

    struct OUT_Q36001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tot_conc_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] tot_conc_qty;
    }

    struct OUT_Q36001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rem_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] cert;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] crctn_qty;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] cnlt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rpt_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_ty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_rqst_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] rjct_rsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] conc_amt;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prvsday_clng_prc;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stnd_price;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] trade_type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_tm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] algo_strgy_tp_code;           // 알고리즘 TP 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trdr_id;                      // 거래자코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] ord_grp_no;                   // 호가그룹ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] smp_cd;                       // 자전거래방지코드
    }
    #endregion

    #region Q40001 : KOSPI200 선물/옵션 잔고내역
    struct IN_Q40001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;
    }

    struct OUT_Q40001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q40001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public char[] bk_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] man_prft_ls;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] exer_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] yak_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] yak_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_amt;
    }
    #endregion

    #region Q40004 : KOSPI200 선물/옵션 펀드별 종목 미체결수량 조회
    struct IN_Q40004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;
    }

    struct OUT_Q40004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q40004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] rem_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] status;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_cls;
    }
    #endregion

    #region Q42001 : 주식 선물/옵션 잔고내역
    struct IN_Q42001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;
    }

    struct OUT_Q42001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q42001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public char[] bk_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] man_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] exer_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] yak_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] yak_amt;
    }
    #endregion

    #region Q46001 : 코스닥선물 잔고내역
    struct IN_Q46001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] isu_gb;
    }

    struct OUT_Q46001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;
    }

    struct OUT_Q46001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] kor_isu_nm;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public char[] bk_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] man_prft_ls;
        //SIZE변경
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] exer_prc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] yak_qty;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] yak_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_amt;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_cls;
    }
    #endregion

    #region Q60001 : 주식 10단계 호가
    struct IN_Q60001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q60001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                      // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_clse;                     // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] hilmt_prc;                    // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] lolmt_prc;                    // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public _hoga[] hoga;                        // 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] totofferjan;                  // 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] totbidjan;                    // 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] jang_status;                  // 장운용

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] O_offerjan;                   // 시간외 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] O_bidjan;                     // 시간외 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ycga;                         // 예상체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] ycvl;                         // 예상체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] list_volume;                  // 상장주식 수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] vol_60;                       // 60총거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] avg_vol;                      // 평균거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ovr40_vol;                    // 40% 초과수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] etf_cls;                      // etf_cls 구분, '0': 해당없음

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] stnd_mkt_tr_unt;              // 거래량 단위

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] volume;                       // 누적거래량

        public struct _hoga
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public char[] offerho;                  // 매도호가

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public char[] bidho;                    // 매수호가

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] offerjan;                 // 매도호가수량

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] bidjan;                   // 매수호가수량
        }
    }
    #endregion

    #region Q60002 : 주식 변동거래량
    struct IN_Q60002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q60002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // data record 갯수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_price;                    // 전일종가
    }

    struct OUT_Q60002_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] time;                         // 시간

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;                         // 등락부호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;                       // 등락폭

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] movvol;                       // 변동거래량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] movsign;                      // 변동부호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;                        // 체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;                      // 매도우선호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidgo;                        // 매수우선호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] volume;                       // 누적거래량
    }
    #endregion

    #region Q60003 : 주식 미니 현재가
    struct IN_Q60003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q60003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;                      // 최우선매도호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;                        // 최우선매수호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] hilmt_prc;                    // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] lolmt_prc;                    // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stnd_prc;                     // 기준가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] list_volume;                  // 상장주식 수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;                         // 등락부호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;                       // 등락폭

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] volume;                       // 누적체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stnd_mkt_tr_unt;              // 거래량 단위
    }
    #endregion

    #region Q60004 : 주식 투자자별 조회
    struct IN_Q60004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] dummy;
    }

    struct OUT_Q60004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // data record 갯수
    }

    struct OUT_Q60004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] the_time;                     // 시간

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] tuja_cd;                      // 투자자 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] medo_qty;                     // 매도 체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] medo_amt;                     // 매도 거래대금

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] mesu_qty;                     // 매수 체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] mesu_amt;                     // 매수 거래대금
    }
    #endregion

    #region Q60005 : 주식 거래원 조회
    struct IN_Q60005
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                           // 종목 단축코드
    }

    struct OUT_Q60005
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public Member[] members;


        public struct Member
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
            public char[] medo_memb_cd;                 // 매도 거래원번호

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
            public char[] medo_memb_nm;                 // 매도 거래원명

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] medo_qty;                     // 매도 체결수량

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
            public char[] medo_amt;                     // 매도 거래대금

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
            public char[] mesu_memb_cd;                 // 매수 거래원번호

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
            public char[] mesu_memb_nm;                 // 매수 거래원명

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] mesu_qty;                     // 매수 체결수량

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
            public char[] mesu_amt;                     // 매수 거래대금
        }
    }
    #endregion

    #region Q62001 : 신주인수권 10단계 호가
    struct IN_Q62001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q62001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] presnt_prc;                   // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public _hoga[] hoga;                        // 호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] totofferjan;                  // 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] totbidjan;                    // 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] O_offerjan;                   // 시간외 총매도잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] O_bidjan;                     // 시간외 총매수잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ycga;                         // 예상체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] ycvl;                         // 예상체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] list_volume;                  // 상장주식 수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] etf_yn;                       // etf_cls 구분 '0': 해당없음

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sinju_yn;                     // 신주구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stnd_mkt_tr_unt;              // 거래량 단위

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] exe_open_dt;                  // 행사기간개시일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] exe_end_dt;                   // 행사기간종료일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] pre_volume;                   // 전일누적체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] volume;                       // 누적 거래량

        public struct _hoga
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public char[] offerho;                  // 매도호가

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public char[] bidho;                    // 매수호가

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] offerjan;                 // 매도호가잔량

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public char[] bidjan;                   // 매수호가잔량
        }
    }
    #endregion

    #region Q62002 : 신주인수권 미니 현재가
    struct IN_Q62002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q62002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;                      // 최우선매도호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;                        // 최우선매수호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stnd_prc;                     // 기준가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] list_volume;                  // 상장주식 수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] open;                         // 시가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] high;                         // 고가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] low;                          // 저가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] sign;                         // 등락부호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] change;                       // 등락폭

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public char[] volume;                       // 누적체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] stnd_mkt_tr_unt;              // 거래량 단위
    }
    #endregion

    #region Q70001 : 주식 체결내역
    struct IN_Q70001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] che_gb;                       // 체결구분, 0.전체 / 1.미체결 / 2.체결

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] meme_gb;                      // 매매구분, 0.전체 / 1.매도 / 2.매수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] isu_cd;                       // 종목코드, "AAAAAAAA" 전체

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;                     // NEXT KEY
    }

    struct OUT_Q70001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] next_key;                     // NEXT KEY

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tot_conc_amt;                 // 전체 체결금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public char[] tot_conc_qty;                 // 전체 체결수량
    }

    struct OUT_Q70001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;                     // 계좌번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] offerho;                      // 최우선매도호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bidho;                        // 최우선매수호가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] hilmt_prc;                    // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] lolmt_prc;                    // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stnd_prc;                     // 기준가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] ord_no;                       // 주문번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] mtr_ord_no;                   // 모주문번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_ord_no;                   // 원주문번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] tord_no;                      // 업무계주문번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] org_tord_no;                  // 업무계원주문번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;                       // 매매구분 숫자, 1:매도 / 2:매수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] meme_gb;                      // 매매구분 한글 (매도, 매수)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cls;                      // 주문구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] rjct_cd;                      // 거부사유

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_qty;                      // 주문수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_prc;                      // 주문단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_type;                     // 주문유형

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_qty;                     // 체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] conc_prc;                     // 체결단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] conc_amt;                     // 체결금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] crctn_qty;                    // 정정수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] cnlt_qty;                     // 취소수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rpt_qty;                      // 통보수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] rem_qty;                     // 잔량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] cfirm;                        // 확인

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_cond;                     // 주문조건, 0:없음 / 3.IOC / 4.FOK

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] loan_cls;                     // 차입구분 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] off_type_code;                // 보드ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] conc_tm;                      // 체결시각

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] acc_tm;                       // 접수시각

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] ord_tm;                       // 주문시각

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ord_gb;                       // 주문구분, " ": 일반 / "A": 자동 / "R": 예약 / "F": 펀드간 / "C": CD주문

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pt_type_code;                 // PT 구분코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] shtsl_cls;                    // 공매도 허용여부

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] algo_strgy_tp_code;           // 알고리즘 TP 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trdr_id;                      // 거래자코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] ord_grp_no;                   // 호가그룹ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] smp_cd;                       // 자전거래방지코드
    }
    #endregion

    #region Q80001 : 주식 잔고내역
    struct IN_Q80001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q80001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // data record 갯수
    }

    struct OUT_Q80001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] bk_prc;                       // 장부단가 (x.2)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] loan_sell_prc;                // 차입단가 (x.2)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_sell_amt;                // 차입금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] sell_pos_qty;                 // 주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ass_rate;                     // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_pos_qty;            // 차입주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_ass_prft_ls;             // 차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_prft_ls;         // 전일차익평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_clse;                     // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stop;                         // 매매제한수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] spot;                         // 실물

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고 (차입수량-차입매도수량)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;                         // 수수료

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] hilmt_prc;                    // 상한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] lolmt_prc;                    // 하한가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] list_volume;                  // 상장주식 수
    }
    #endregion

    #region Q80002 : 주식 잔고 내역 합계
    struct IN_Q80002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q80002
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_bk_amt;                   // 장부금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_ass_amt;                  // 평가금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] ass_prft_ls;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_sell_amt;            // 차입매도금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_ass_amt;             // 차입매도평가금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_ass_prft_ls;         // 차입매도평가손익 합계
    }
    #endregion

    #region Q80003 : 주식 잔고테이블 조회
    struct IN_Q80003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mkt_kind;                     // 상품구분, A: 전체 / S: 주식 / E: ELW / J: 신주
    }

    struct OUT_Q80003
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // data record 갯수
    }

    struct OUT_Q80003_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stop;                         // 매매제한수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] spot;                         // 실물

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] loan_sell_prc;                // 차입매도단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_sell_amt;                // 차입매도금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_sell_qt;                  // 일반매도미체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_ord_sell_qty;            // 차입매도미체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_ord_buy_qty;             // 차입매수미체결수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_amt;                  // 전일평가금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_amt;             // 전일차입평가금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_prft_ls;         // 전일차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;                         // 수수료

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고 (차입수량-차입매도수량)
    }
    #endregion

    #region Q80004 : 주식 차입 잔고 내역
    struct IN_Q80004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호
    }

    struct OUT_Q80004
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q80004_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] stnd_cd;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_prc;                // 차입매도단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_sell_amt;                // 차입매도금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_pos_qty;            // 차입주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] loan_ass_rate;                // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] price;                        // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] td_sonik;                     // 당일손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_prft_ls;         // 전일차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jeqprice;                     // 예상체결가격

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] exp_pyung_sonik;              // 예상평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] fut_cnv_qty;                  // 선물환산잔고 (주식평가금액 / (KOS200PRC * 500,000))

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익
    }
    #endregion

    #region Q80005 : 미니 잔고 조회
    struct IN_Q80005
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q80005
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] tr_cls;                       // 매매구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 종목장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] loan_sell_prc;                // 차입매도단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_sell_amt;                // 차입매도금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_ass_prft_ls;             // 차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_prft_ls;         // 전일차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] non_cls;                      // 미체결구분 (1: 미체결 존재)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_pos_qty;                  // 주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_ord_pos_qty;             // 차입주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고 (차입수량-차입매도수량)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ass_rate;                     // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] fund_chkgbn;                  // 주문제한을 위한 펀드구분
    }
    #endregion

    #region Q80006 : 주식 종목별 잔고 내역
    struct IN_Q80006
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q80006
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q80006_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_prc;                // 차입단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_sell_amt;                // 차입금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] sell_pos_qty;                 // 주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ass_rate;                     // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_pos_qty;            // 차입주문가능수량
    }
    #endregion

    #region Q80007 : 주식 사원별 잔고 내역
    struct IN_Q80007
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호
    }

    struct OUT_Q80007
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q80007_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_jango;                   // 차입잔고

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_qty;                     // 차입수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_prc;                     // 차입매도단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_amt;                     // 차입매도금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_qty;                // 차입매도수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_loan_ass_prft_ls;         // 전일차입평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_amt;                 // 평가금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] loan_ass_prft_amt;            // 차입평가금액
    }
    #endregion

    #region Q80008 : 주식 사원별 잔고 합계
    struct IN_Q80008
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호
    }

    struct OUT_Q80008
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_bk_amt;                   // 장부금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_pyung_amt;                // 평가금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] pyung_sonik;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_amt;                 // 차입매도금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_pyung_amt;           // 차입매도평가금액 합계

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] sum_loan_pyung_sonik;         // 차입매도평가손익 합계
    }
    #endregion

    #region Q80009 : 주식 펀드종목별 차입매수가능수량
    struct IN_Q80009
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드
    }

    struct OUT_Q80009
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] ord_pos_qty;                  // 일반매도가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_sell_pos_qty;            // 차입매도가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] loan_buy_pos_qty;             // 차입매수가능수량
    }
    #endregion

    #region Q80012 : 사용자 지수 조회
    struct IN_Q80012
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] dummy;
    }

    struct OUT_Q80012
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q80012_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] jisu_cd;                      // 사용자 지수 코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jisu_prsnt;                   // 현재가 지수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jisu_offer;                   // 매도호가 지수

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] jisu_bid;                     // 매수호가 지수
    }
    #endregion

    #region Q81001 : ELW/신주인수권 펀드별 잔고내역
    struct IN_Q81001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q81001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q81001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] sell_pos_qty;                 // 주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ass_rate;                     // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stop;                         // 매매제한수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] spot;                         // 실물

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;                         // 수수료

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] arbilink_isu;                 // 장내연동종목코드
    }
    #endregion

    #region Q82001 : 신주인수권 잔고 조회
    struct IN_Q82001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q82001
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q82001_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] expcode;                      // 종목 표준코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.MKT_CLS_LEN)]
        public char[] mkt_cls;                      // 시장구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] bk_qty;                       // 장부수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
        public char[] bk_prc;                       // 장부단가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bk_amt;                       // 장부금액

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] sell_pos_qty;                 // 주문가능수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] ass_rate;                     // 평가비율

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] prsnt_prc;                    // 현재가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ass_prft_ls;                  // 평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] tr_prft_ls;                   // 매매손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] bef_ass_prft_ls;              // 전일평가손익

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] pre_close;                    // 전일종가

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] stop;                         // 매매제한수량

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] spot;                         // 실물

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] cmsn;                         // 수수료
    }
    #endregion

    #region Q90025 : 계좌정보 조회
    struct IN_Q90025
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q90025
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q90025_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;                     // 계좌번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] funmd_nm;                     // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.DEPT_CODE_LEN)]
        public char[] dept_cd;                      // 부서코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.TEAM_CODE_LEN)]
        public char[] team_cd;                      // 팀코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NAME_LEN)]
        public char[] emp_nm;                       // 사원명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stk_yn;                       // 주식거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] futr_yn;                      // 선물거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] botr_yn;                      // 채권개래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] accnt_gb;                     // 계좌구분코드 41/61

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] algo_stgy_tp_cd;              // 알고리즘전략구분코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public char[] trdr_id;                      // 거래자 ID

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] ord_grp_no;                   // 호가그룹번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] smp_cd;                       // 자전거래 방지코드 0: 해당없음, 1: 기존호가취소, 2: 신규호가취소, 3: 양방향호가취소

    }
    #endregion

    #region Q90030 : 펀드조회
    struct IN_Q90030
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.USER_ID_LEN)]
        public char[] login_id;                     // 로그인 아이디
    }

    struct OUT_Q90030
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q90030_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NO_LEN)]
        public char[] fund_no;                      // 펀드번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.FUND_NAME_LEN)]
        public char[] fund_nm;                      // 펀드명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ACCOUNT_NO_LEN)]
        public char[] accnt_no;                     // 계좌번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] open_dt;                      // 개설일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] abnd_dt;                      // 해지일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호(딜러)

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] stk_yn;                       // 주식거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] futr_yn;                      // 선물거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] botr_yn;                      // 채권거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] lp_fund_cls;                  // LP펀드구분 'E'/' '

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] elw_fund_yn;                  // ELW-LP펀드 여부

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] loan_yn;                      // 차입거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] recomm_yn;                    // 매매정지종목 거래가능여부

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] in_deal_yn;                   // 내부거래펀드구분 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] mm_fund_yn;                   // 시장조성펀드사용여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] hedge_yn;                     // 헷지거래여부 Y/N

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] arbit_yn;                     // 차익거래여부 Y/N, 차익구분코드 (' ', '1', '2', '3', '4')

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public char[] sort_key;                     // SORT-KEY

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] accnt_gb;                     // 계좌구분코드 41/61

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] ack_cls;                      // 공매도권한여부 Y/N
    }
    #endregion

    #region Q90056 : 매매금지종목 리스트 조회
    struct IN_Q90056
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] dummy;
    }

    struct OUT_Q90056
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public char[] rcnt;                         // DATA RECORD 갯수
    }

    struct OUT_Q90056_SUB
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] the_date;                     // 기준일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.DEPT_CODE_LEN)]
        public char[] dept_cd;                      // 부서코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.SHORT_CODE_LEN)]
        public char[] isu_cd;                       // 종목 단축코드

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.ITEM_NAME_LEN)]
        public char[] isu_nm;                       // 종목명

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] kind;                         // 매매금지유형, 1.추천종목 / 2.공개매수종목 / 3.기타

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] pub_way;                      // 공표방법

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] pub_gb;                       // 공표자료구분

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] strt_date;                    // 시작 일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] strt_tm;                      // 시작 시간

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] end_date;                     // 종료 일자

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
        public char[] end_tm;                       // 종료 시간

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] remark;                       // REMARK

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.EMP_NO_LEN)]
        public char[] emp_no;                       // 사원번호

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public char[] ip;                           // IP주소

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] use_yn;                       // 사용여부, Y:사용 / N: 미사용
    }
    #endregion
}
