﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Text;
using System.Windows.Forms;
using AxGIExpertControl64Lib;

namespace PnK_indi
{
    public partial class StockRsiReversion : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SubState> SubStates = new Dictionary<string, SubState>();
        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_PrevBalanceControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_MarketCapControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;

        private (bool Status, DateTime Time) RankCalculated;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;
        private bool HasPendingRequest = false;

        private new bool Enabled;

        public Thread PriceThread { get; private set; }
        public long MarketCapCutOff { get; private set; }

        public StockRsiReversion(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();
        }

        public void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
            }

            RankCalculated = (false, MarketOpeningTime.AddMinutes(-20));
            OpeningPriceOrdered = (false, MarketOpeningTime.AddSeconds(-60));
            MarketOpened = (false, MarketOpeningTime);
            RsiCalculated = (false, MarketClosingTime.AddMinutes(-15));
            PreClosingOrdered = (false, MarketClosingTime.AddMinutes(-13));
            ClosingPriceOrdered = (false, MarketClosingTime.AddSeconds(-30));
            OnClose = (false, MarketClosingTime.AddMinutes(10));
        }

        private void InitializeIndiControls()
        {
            Indi_PrevBalanceControl.CreateControl();
            Indi_PrevBalanceControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_PrevBalanceControl_ReceiveData);

            Indi_MarketCapControl.CreateControl();
            Indi_MarketCapControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_MarketCapControl_ReceiveData);

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);
        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }

        private void Indi_PrevBalanceControl_ReceiveData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
        }

        public void Enable() { this.Enabled = true; }

        public bool IsEnabled() => this.Enabled;

        public void Disable() { this.Enabled = false; }

        private void StockRsiReversion_Load(object sender, EventArgs e)
        {
        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;
            InitSubStates();
            Enable();
            
            ManageTimer.Set(3.3 * 1000);
            ManageTimer.Start(OnTimer);
        }

        private void PauseButton_Click(object sender, EventArgs e)
        {
            ParamsGroupBox.Enabled = true;
            ManageTimer.Finish();
        }
        private void ClearButton_Click(object sender, EventArgs e)
        {
            foreach (var state in Main.States.Values)
                state.Clear();
        }
        private void UpdateButton_Click(object sender, EventArgs e)
        {
            PriceThread = new Thread(() => CalculateRSIs());
            PriceThread.Start();
        }

        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsDouble(OverSoldBox.Text),
                C.AsDouble(OverBoughtBox.Text),
                C.AsInt(RSIPeriodBox.Text),
                C.AsInt(SignalPeriodBox.Text),
                C.AsInt(MaPeriodBox.Text),
                C.AsInt(RankUpToBox.Text),
                C.AsDouble(AddPositionLevelBox.Text) / 100,
                C.AsDouble(TargetRateBox.Text) / 100,
                C.AsDouble(LossCutRateBox.Text) / 100,
                C.AsLong(MaxNotionalAmountBox.Text) * 100_000_000,
                C.AsInt(MaxPyramidingBox.Text),
                C.AsLong(C.AsDouble(MaxAmountPerOrderBox.Text) * 100_000_000)
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }

        private void InitSubStates()
        {
            foreach (var state in Main.States.Values)
            {
                // 주식 외 제외
                if (state.SecurityGroupId != SecurityGroupId.ST) { continue; }
                // 우선주 제외
                if (!state.ShortCode.EndsWith("0")) { continue; }
                // 락 종목 제외
                if (state.PriceAdjustment != PriceAdjustment.Normal 
                    && state.PriceAdjustment != PriceAdjustment.ExDividend 
                    && state.PriceAdjustment != PriceAdjustment.ExMidDividend) { continue; }
                // 스팩 제외
                if (state.Name.Contains("스팩")) { continue; }
                // 계열사 종목 제외
                if (state.Name.Contains("신한") || state.Name.Contains("제주은행")) { continue; }

                SubStates[state.ShortCode] = new SubState(state, _StrategyParams);


                
            }

            // 시세요청
            foreach (var subState in SubStates.Values)
            {
                var state = subState.State;

                if (state.MarketType == MarketType.Kospi)
                {
                    if (state.SecurityGroupId == SecurityGroupId.EF || state.SecurityGroupId == SecurityGroupId.EN)
                    {
                        Main.RequestA303S(state.StandardCode);
                        Main.RequestB703S(state.StandardCode);
                    }
                    else
                    {
                        Main.RequestA301S(state.StandardCode);
                        Main.RequestB601S(state.StandardCode);
                    }
                }
                else if (state.MarketType == MarketType.Kosdaq)
                {
                    Main.RequestA301Q(state.StandardCode);
                    Main.RequestB601Q(state.StandardCode);
                }
            }
        }

        private void OnTimer(object sender, EventArgs e)
        {
            // 장 개시 전 시총순위 계산
            if (!RankCalculated.Status)
            {
                if (HasPendingRequest) { return; }

                HasPendingRequest = true;
                CalcMarketCapCutOff();
                return;
            }

            // 장 개시 전 시가주문
            else if (!OpeningPriceOrdered.Status && DateTime.Now > OpeningPriceOrdered.Time)
            {
                if (DateTime.Now > MarketOpeningTime)
                {
                    Main.LogWriter.Write("Pass opening price order");
                    OpeningPriceOrdered.Status = true;
                    HasPendingRequest = false;
                    return;
                }
                
                if (HasPendingRequest) { return; }

                HasPendingRequest = true;
                SendOpeningPriceOrders();
                return;
            }
            
            // 장 개시 후 잔고관리
            else if (!MarketOpened.Status && DateTime.Now > MarketOpened.Time)
            {
                if (DateTime.Now > RsiCalculated.Time)
                {
                    Main.LogWriter.Write("Start RSI Calculation");
                    MarketOpened.Status = true;
                    RsiCalculated.Status = false;
                    return;
                }
                
                ManageBalancesOnMarket();
                return;
            }
            
            // 장 종료 전 당일 RSI 계산
            else if (!RsiCalculated.Status && DateTime.Now > RsiCalculated.Time)
            {
                if (HasPendingRequest) { return; }

                HasPendingRequest = true;

                PriceThread = new Thread(() => CalculateRSIs());
                PriceThread.Start();

                return;
            }
            
            // 종가 직전 잔고관리
            else if (!PreClosingOrdered.Status && DateTime.Now > PreClosingOrdered.Time)
            {
                HasPendingRequest = false;
                
                if (DateTime.Now > MarketClosingTime.AddMinutes(-10))
                {
                    Main.LogWriter.Write("Start closing price order");
                    PreClosingOrdered.Status = true;

                    foreach (var subState in SubStates.Values.ToList())
                    {
                        if (subState.State.LiveOrders.Any())
                            subState.State.CancelAllOrders();
                    }
                    return;
                }

                ManageBalancesNearClose();
                return;
            }
            
            // 종가 주문
            else if (!ClosingPriceOrdered.Status && DateTime.Now > ClosingPriceOrdered.Time)
            {
                if (DateTime.Now > OnClose.Time)
                {
                    Main.LogWriter.Write("Pass closing price order");
                    ClosingPriceOrdered.Status = true;
                    HasPendingRequest = false;
                    return;
                }

                if (HasPendingRequest) { return; }

                HasPendingRequest = true;
                SendClosingPriceOrders();
                return;
            }
            
            // 알고리즘 종료
            else if (DateTime.Now > OnClose.Time)
            {
                LogBalanceStatus();
                Environment.Exit(0);
            }
        }

        private bool GetBalanceStatus()
        {
            List<string> BalanceStatusLines = new List<string>();
            string statusFilePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\release\\StockRsIReversion\\BalanceStatus.dat";

            try
            {
                BalanceStatusLines = System.IO.File.ReadAllLines(statusFilePath).ToList();
            }
            catch (FileNotFoundException)
            {
                Main.LogWriter.Write($"There is no Status File");
                return false;
            }

            foreach (var balanceStatusLine in BalanceStatusLines)
            {
                var Status = balanceStatusLine.Split(',');

                var shortCode = Status[0];
                var pyramiding = C.AsDouble(Status[1]);

                if (SubStates.TryGetValue(shortCode, out SubState subState))
                {
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    subState.Pyramiding = C.AsInt((double)bookValue / _StrategyParams.MaxPyramiding / 100_000_000);
                    

                    string msg = "";
                    msg = $"{shortCode} {subState.State.Name} / P: {subState.Pyramiding} / " +
                          $"PL: {(subState.State.AverageBuyPrice > 0 ? (double)subState.State.PreviousDayPrice / subState.State.AverageBuyPrice - 1 : 0):P2} / ";

                    subState.NextPyramidingPrice = subState.Pyramiding == 0 ? 0
                                                   : subState.Pyramiding == 1 ? C.AsLong(subState.State.AverageBuyPrice * (1 + _StrategyParams.AddPositionLevel))
                                                   : subState.Pyramiding == 2 ? C.AsLong(subState.State.AverageBuyPrice * (1 + _StrategyParams.AddPositionLevel * 1.5))
                                                   : 0;

                    msg += $"Next: {subState.NextPyramidingPrice} / ";

                    var lastBuyDate = Status[3] != "0" ? Convert.ToDateTime(Status[3]) : DateTime.MaxValue;

                    msg += $"LastBuy: {lastBuyDate:d}";
                    subState.LastBuyDate = lastBuyDate;
                    Main.LogWriter.Write(msg);
                }
                else
                {
                    Main.LogWriter.Write($"There is no SubState of [{shortCode} {Main.States.Values.Where(x => x.ShortCode == shortCode).First().Name}]");
                    if (pyramiding > 0) { return false; }
                }
            }

            LogBalanceStatus();
            return true;
        }

        private void LogBalanceStatus()
        {
            foreach (var subState in SubStates.Values)
            {
                var shortCode = subState.State.ShortCode;
                subState.Rank = SubStates.Values.Where(x => x.State.CurrentPrice * x.State.OutstandingShares > subState.State.CurrentPrice * subState.State.OutstandingShares).Count() + 1;
            }

            string strStatus = "";
            string statusFilePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\release\\StockRsIReversion\\BalanceStatus.dat";
            FileInfo fileInfo = new FileInfo(statusFilePath);

            foreach (var subState in SubStates.Values.OrderBy(x => x.Rank).ToList())
            {
                if (subState.State.NormalBalance == 0)
                {
                    subState.Pyramiding = 0;
                    subState.NextPyramidingPrice = 0;
                    subState.LastBuyDate = DateTime.MaxValue;
                }
                else
                {
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    subState.Pyramiding = C.AsInt((double)bookValue / _StrategyParams.MaxPyramiding / 100_000_000);
                    
                    if (subState.Pyramiding == 3)
                    {
                        subState.NextPyramidingPrice = 0;
                    }
                    else if (subState.Pyramiding == 2)
                    {
                        subState.NextPyramidingPrice = C.AsLong(subState.State.AverageBuyPrice * (1 + _StrategyParams.AddPositionLevel * 1.5));
                    }
                    else if (subState.Pyramiding == 1)
                    {
                        subState.NextPyramidingPrice = C.AsLong(subState.State.AverageBuyPrice * (1 + _StrategyParams.AddPositionLevel));
                    }
                }
               
                strStatus += $"{subState.State.ShortCode},{subState.Pyramiding}," +
                             $"{subState.NextPyramidingPrice}," +
                             $"{(subState.LastBuyDate == DateTime.MaxValue ? "0" : $"{subState.LastBuyDate:d}")}\n";
            }
            System.IO.File.WriteAllText(statusFilePath, strStatus);
        }
        
        private void CalcMarketCapCutOff()
        {
            Indi_MarketCapControl.SetQueryName("TR_RB001");
            Indi_MarketCapControl.SetSingleData(0, "0");

            var ret = Indi_MarketCapControl.RequestData();

            if (ret <= 0)
            {
                Console.WriteLine("Request Error: [TR_RB001]");
            }
        }

        private void Indi_MarketCapControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            Dictionary<string, long> MarketCaps = new Dictionary<string, long>();

            var nCnt = Indi_MarketCapControl.GetMultiRowCount();

            for (short i = 0; i < nCnt; i++)
            {
                var shortCode = Indi_MarketCapControl.GetMultiData(i, 1).ToString().Trim();
                var securityGroupId = Indi_MarketCapControl.GetMultiData(i, 19).ToString();

                if (securityGroupId != "ST" || !shortCode.EndsWith("0"))
                    continue;

                var outstandingShares = C.AsLong(Indi_MarketCapControl.GetMultiData(i, 18));
                var close = C.AsLong(Indi_MarketCapControl.GetMultiData(i, 26));

                MarketCaps[shortCode] = outstandingShares * close;
            }

            var OrderedMarketCaps = MarketCaps.OrderByDescending(x => x.Value);
            var cutoffShortCode = OrderedMarketCaps.ElementAt(_StrategyParams.RankUpTo).Key;
            var cutoffMarketCap = OrderedMarketCaps.ElementAt(_StrategyParams.RankUpTo).Value;

            this.MarketCapCutOff = cutoffMarketCap;
            SetUniverseStocks();
        }

        private void SetUniverseStocks()
        {
            // Calc Market Cap Ranks
            foreach (var subState in SubStates.Values)
            {
                var shortCode = subState.State.ShortCode;
                subState.Rank = SubStates.Values.Where(x => x.PreviousDayMarketCap > subState.PreviousDayMarketCap).Count() + 1;
            }

            foreach (var subState in SubStates.Values.ToList())
            {
                var shortCode = subState.State.ShortCode;

                if (subState.PreviousDayMarketCap < this.MarketCapCutOff)
                {
                    if (subState.State.NormalBalance == 0)
                    {
                        SubStates.Remove(shortCode);
                        continue;
                    }
                }
            }

            foreach (var subState in SubStates.Values.OrderBy(x => x.Rank).ToList())
            {
                Console.WriteLine($"# {subState.Rank,3} {subState.State.ShortCode} {subState.State.Name}");
            }

            if (!GetBalanceStatus()) { return; }

            RankCalculated.Status = true;
            HasPendingRequest = false;
        }
        

        private void SendOpeningPriceOrders()
        {
            if (!TradeAtOpenCheckBox.Checked)
            {
                Main.LogWriter.Write("Trade at open: False");
                return;
            }
            
            foreach (var subState in SubStates.Values.ToList())
            {
                // 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0) { continue; }

                // 예체가, 예체수량 들어오지 않은 종목 제외
                if (subState.State.Expected.Price == 0 || subState.State.Expected.Volume == 0) { continue; }

                // 기 주문 종목 제외
                if (subState.State.LiveOrders.Any()) { continue; }

                bool signal = subState.State.Expected.Price > subState.State.AverageBuyPrice * (1 + _StrategyParams.TargetRate);

                if (signal)
                {
                    subState.HasToSell = true;
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.Expected.Price, 1);
                    var orderQuantity = C.AsLong(Math.Min(subState.State.NormalBalance, subState.State.Expected.Volume * 0.2));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[  Opening Ask Order  ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }
            Main.LogWriter.Write("Close SendOpeningPriceOrders");
            OpeningPriceOrdered.Status = true;
            HasPendingRequest = false;
        }

        private void ManageBalancesOnMarket()
        {
            Console.WriteLine($"{DateTime.Now:HH:mm:ss.fff} | ManageBalancesOnMarket Tick");
            foreach (var subState in SubStates.Values.ToList())
            {
                // 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0) { continue; }

                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 10초 이상 경과 주문 취소
                if (subState.State.LiveOrders.Any(x => (DateTime.Now - x.OrderTime).TotalSeconds >= 10)) 
                {
                    subState.State.CancelAllOrders();
                    continue; 
                }

                // 미체결 주문 있으면 PASS
                if (subState.State.LiveOrders.Any()) { continue; }
                
                // HasToSell 매도
                if (subState.HasToSell)
                {
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.BestQuote.Bid, 1);
                    var orderQuantity = C.AsLong(Math.Min(subState.State.NormalBalance, Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[   HTS Ask Order    ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }

                // 장부단가 대비 5% 이상 급등 시 전일 장부수량의 50% 매도
                bool signal = subState.State.CurrentPrice > subState.State.AverageBuyPrice * (1 + 0.05);

                if (signal)
                {
                    var remainingQuantity = Math.Min(C.AsLong(subState.State.PreviousDayBalance / 2), subState.State.NormalBalance);

                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.BestQuote.Bid, 1);
                    var orderQuantity = C.AsLong(Math.Min(subState.State.NormalBalance - remainingQuantity, Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[  5.0 %  Ask Order  ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }
        }

        private void CalculateRSIs()
        {
            foreach (var subState in SubStates.Values)
            {
                Indi_StockChartControl.SetQueryName("TR_SCHART");
                Indi_StockChartControl.SetSingleData(0, subState.State.ShortCode);
                Indi_StockChartControl.SetSingleData(1, "D");
                Indi_StockChartControl.SetSingleData(2, "1");
                Indi_StockChartControl.SetSingleData(3, "00000000");
                Indi_StockChartControl.SetSingleData(4, "99999999");
                Indi_StockChartControl.SetSingleData(5, "300");
                Indi_StockChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_StockChart)
                        break;
                }

                this.IsMessageReceived_StockChart = false;

                var nCount = Indi_StockChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }

                if (subState.PriceSet.Count() > 0) { subState.PriceSet.Clear(); }
                
                double adj = 1.0d;
                for (short i = 0; i < nCount; i++)
                {
                    var _datetime = Indi_StockChartControl.GetMultiData(i, 0).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}";

                    var close = C.AsDouble(Indi_StockChartControl.GetMultiData(i, 5)) * adj;
                    subState.AddToPriceSet(close);
                    adj = adj * C.AsDouble(Indi_StockChartControl.GetMultiData(i, 6));

                }
                subState.CalculateRSI();

                int padLen = 20 - Encoding.Default.GetBytes(subState.State.Name).Length;
                Console.WriteLine($"{subState.State.ShortCode} {subState.State.Name}{"".PadRight(padLen)} pRSI={subState.RSI[1]:F2} -> cRSI={subState.RSI[0]:F2}");
            }

            RsiCalculated.Status = true;
        }
        
        private void ManageBalancesNearClose()
        {
            // 종가단일가 직전익절
            foreach (var subState in SubStates.Values.ToList())
            {
                // 전일 & 당일 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0 || subState.State.PreviousDayBalance <= 0) { continue; }

                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 10초 이상 경과 매도주문 취소
                if (subState.State.LiveOrders.Any(x => (DateTime.Now - x.OrderTime).TotalSeconds >= 10 && x.AskBidType == AskBidType.Ask))
                {
                    subState.State.CancelOrders(AskBidType.Ask);
                    continue;
                }

                // 미체결 매도주문 있으면 PASS
                if (subState.State.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask)) { continue; }

                bool signal = subState.State.BestQuote.Bid > subState.State.AverageBuyPrice * (1 + _StrategyParams.TargetRate);

                if (signal)
                {
                    subState.HasToSell = true;
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.BestQuote.Bid, 1);
                    var orderQuantity = Math.Min(subState.State.NormalBalance, C.AsLong(Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[  Target Ask Order  ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }

            // 종가단일가 직전손절
            foreach (var subState in SubStates.Values.ToList())
            {
                // 전일 & 당일 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0 || subState.State.PreviousDayBalance <= 0) { continue; }

                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 10초 이상 경과 매도주문 취소
                if (subState.State.LiveOrders.Any(x => (DateTime.Now - x.OrderTime).TotalSeconds >= 10 && x.AskBidType == AskBidType.Ask))
                {
                    subState.State.CancelOrders(AskBidType.Ask);
                    continue;
                }

                // 미체결 매도주문 있으면 PASS
                if (subState.State.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask)) { continue; }

                bool signal = subState.State.BestQuote.Bid < subState.State.AverageBuyPrice * (1 + _StrategyParams.LossCutRate);

                if (signal)
                {
                    subState.HasToSell = true;
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.BestQuote.Bid, 1);
                    var orderQuantity = Math.Min(subState.State.NormalBalance, C.AsLong(Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[ Loss Cut Ask Order ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }

            // 종가단일가 직전 보유기간 초과 종목 매도
            foreach (var subState in SubStates.Values.ToList())
            {
                // 전일 & 당일 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0 || subState.State.PreviousDayBalance <= 0) { continue; }

                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 10초 이상 경과 매도주문 취소
                if (subState.State.LiveOrders.Any(x => (DateTime.Now - x.OrderTime).TotalSeconds >= 10 && x.AskBidType == AskBidType.Ask))
                {
                    subState.State.CancelOrders(AskBidType.Ask);
                    continue;
                }

                // 미체결 매도주문 있으면 PASS
                if (subState.State.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask)) { continue; }

                bool signal = (DateTime.Now - subState.LastBuyDate).TotalDays >= 30 && subState.Pyramiding == _StrategyParams.MaxPyramiding;

                if (signal)
                {
                    subState.HasToSell = true;
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.BestQuote.Bid, 1);
                    var orderQuantity = Math.Min(subState.State.NormalBalance, C.AsLong(Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[ TimeOver Ask Order ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }

            // 종가단일가 직전매수
            foreach (var subState in SubStates.Values.ToList())
            {
                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 당일 파는 종목 제외
                if (subState.HasToSell) { continue; }

                // 10초 이상 경과 매수주문 취소
                if (subState.State.LiveOrders.Any(x => (DateTime.Now - x.OrderTime).TotalSeconds >= 10 && x.AskBidType == AskBidType.Bid))
                {
                    subState.State.CancelOrders(AskBidType.Bid);
                    continue;
                }

                // 미체결 매수주문 있으면 PASS
                if (subState.State.LiveOrders.Any(x => x.AskBidType == AskBidType.Bid)) { continue; }

                // 기 제출 주문있으면 PASS
                if (subState.State.LiveOrders.Any()) { continue; }

                // 신규매수
                if (!subState.Done && subState.State.PreviousDayBalance == 0)
                {
                    var hasToBuyAmount = _StrategyParams.MaxNotionalAmount / _StrategyParams.MaxPyramiding;
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    var remainedQuantity = C.AsLong((hasToBuyAmount - bookValue) / subState.State.CurrentPrice);

                    // 다 사면 제외
                    if (bookValue >= hasToBuyAmount || remainedQuantity <= 0)
                    {
                        subState.Pyramiding = 1;
                        subState.Done = true;
                        subState.LastBuyDate = DateTime.Today;
                        continue; 
                    }
                    
                    bool signal = subState.RSI[0] > _StrategyParams.OverSold && subState.RSI[1] < _StrategyParams.OverSold;

                    if (signal)
                    {
                        var orderPrice = subState.State.PriceHelper.GetNextPriceAboveTicks(subState.State.BestQuote.Ask, 1);
                        var orderQuantity = Math.Min(remainedQuantity, C.AsLong(Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));
                        if (orderQuantity <= 0) { continue; }

                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            var orderedPrice = liveOrders.Min(x => x.Price);
                            orderPrice = Math.Min(orderPrice, subState.State.PriceHelper.GetNextPriceBelow(orderedPrice));
                        }

                        Main.LogWriter.Write($"[ {subState.Pyramiding+1} Pyramiding Order ] {subState.State.ShortCode} {subState.State.Name} Bid {orderQuantity} @ {orderPrice}");

                        if (TradeOffButton.Checked) { continue; }

                        subState.State.NewOrder(AskBidType.Bid, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                        continue;
                    }
                }
                
                // 추가매수
                else if (!subState.Done && subState.Pyramiding < _StrategyParams.MaxPyramiding && subState.State.NormalBalance > 0)
                {
                    var hasToBuyAmount = _StrategyParams.MaxNotionalAmount / _StrategyParams.MaxPyramiding * (subState.Pyramiding + 1);
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    var remainedQuantity = C.AsLong((hasToBuyAmount - bookValue) / subState.State.CurrentPrice);

                    // 다 사면 제외
                    if (bookValue >= hasToBuyAmount || remainedQuantity <= 0)
                    {
                        subState.Pyramiding += 1;
                        subState.Done = true;
                        subState.LastBuyDate = DateTime.Today;
                        continue;
                    }

                    var nextPyramidingPrice = subState.NextPyramidingPrice;

                    if (nextPyramidingPrice <= 0) 
                    {
                        Main.LogWriter.Write($"{subState.State.ShortCode} {subState.State.Name} Pyramiding Price Error");
                        continue;
                    }

                    bool signal = subState.State.CurrentPrice < nextPyramidingPrice
                                  && subState.RSI[0] > _StrategyParams.OverSold && subState.RSI[1] < _StrategyParams.OverSold;

                    if (signal)
                    {
                        var orderPrice = subState.State.PriceHelper.GetNextPriceAboveTicks(subState.State.BestQuote.Ask, 1);
                        var orderQuantity = Math.Min(remainedQuantity, C.AsLong(Math.Floor((decimal)_StrategyParams.MaxAmountPerOrder / orderPrice)));
                        if (orderQuantity <= 0) { continue; }

                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            var orderedPrice = liveOrders.Min(x => x.Price);
                            orderPrice = Math.Min(orderPrice, subState.State.PriceHelper.GetNextPriceBelow(orderedPrice));
                        }

                        Main.LogWriter.Write($"[ {subState.Pyramiding + 1} Pyramiding Order ] {subState.State.ShortCode} {subState.State.Name} Bid {orderQuantity} @ {orderPrice}");

                        if (TradeOffButton.Checked) { continue; }

                        subState.State.NewOrder(AskBidType.Bid, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                        continue;
                    }
                }
            }

            HasPendingRequest = false;
        }

        private void SendClosingPriceOrders()
        {
            if (!TradeAtCloseCheckBox.Checked)
            {
                Main.LogWriter.Write("Trade at close: false");
                return;
            }
            
            // 종가 매도주문
            foreach (var subState in SubStates.Values.ToList())
            {
                // 전일 & 당일 잔고없는 종목 제외
                if (subState.State.NormalBalance <= 0 || subState.State.PreviousDayBalance <= 0) { continue; }

                // 예체가 들어오지 않는 종목 제외
                if (subState.State.Expected.Price == 0 || subState.State.Expected.Volume == 0) { continue; }
                
                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 기 주문종목 제외
                if (subState.State.LiveOrders.Any()) { continue; }

                if (subState.HasToSell)
                {
                    var orderPrice = subState.State.PriceHelper.GetNextPriceBelowTicks(subState.State.Expected.Price, 1);
                    var orderQuantity = subState.State.NormalBalance;

                    if (orderPrice < subState.State.CurrentPrice * 0.99)
                        orderQuantity = Math.Min(orderQuantity, C.AsLong(subState.State.Expected.Volume * 0.2));

                    if (orderQuantity <= 0) { continue; }

                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                    if (liveOrders.Count() > 0)
                    {
                        var orderedPrice = liveOrders.Max(x => x.Price);
                        orderPrice = Math.Max(orderPrice, subState.State.PriceHelper.GetNextPriceAbove(orderedPrice));
                    }

                    Main.LogWriter.Write($"[ Closing Ask Order ] {subState.State.ShortCode} {subState.State.Name} Ask {orderQuantity} @ {orderPrice}");

                    if (TradeOffButton.Checked) { continue; }
                    subState.State.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                    continue;
                }
            }

            // 종가 매수주문
            foreach (var subState in SubStates.Values.ToList())
            {
                // 가격 들어오지 않은 종목 제외
                if (subState.State.CurrentPrice == 0 || subState.State.BestQuote.Ask == 0 || subState.State.BestQuote.Bid == 0) { continue; }

                // 예체가 들어오지 않는 종목 제외
                if (subState.State.Expected.Price == 0 || subState.State.Expected.Volume == 0) { continue; }

                // 당일 팔던 종목 제외
                if (subState.HasToSell) { continue; }

                // 기 주문종목 제외
                if (subState.State.LiveOrders.Any()) { continue; }

                // 신규매수
                if (!subState.Done && subState.State.PreviousDayBalance == 0)
                {
                    var hasToBuyAmount = _StrategyParams.MaxNotionalAmount / _StrategyParams.MaxPyramiding;
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    var remainedQuantity = C.AsLong((hasToBuyAmount - bookValue) / subState.State.CurrentPrice);

                    bool signal = subState.RSI[0] > _StrategyParams.OverSold && subState.RSI[1] < _StrategyParams.OverSold;

                    if (signal)
                    {
                        var orderPrice = subState.State.PriceHelper.GetNextPriceAboveTicks(subState.State.Expected.Price, 1);
                        var orderQuantity = remainedQuantity;

                        if (orderPrice > subState.State.CurrentPrice * 1.01)
                            orderQuantity = Math.Min(remainedQuantity, C.AsLong(subState.State.Expected.Volume * 0.2));

                        if (orderQuantity <= 0) { continue; }

                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            var orderedPrice = liveOrders.Min(x => x.Price);
                            orderPrice = Math.Min(orderPrice, subState.State.PriceHelper.GetNextPriceBelow(orderedPrice));
                        }

                        Main.LogWriter.Write($"[ {subState.Pyramiding + 1} Pyramiding Order ] {subState.State.ShortCode} {subState.State.Name} Bid {orderQuantity} @ {orderPrice}");

                        if (TradeOffButton.Checked) { continue; }

                        subState.State.NewOrder(AskBidType.Bid, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);

                        subState.Done = true;
                        subState.Pyramiding = 1;
                        subState.LastBuyDate = DateTime.Today;
                        continue;
                    }
                }

                // 추가매수
                else if (!subState.Done && subState.Pyramiding < _StrategyParams.MaxPyramiding)
                {
                    var hasToBuyAmount = _StrategyParams.MaxNotionalAmount / _StrategyParams.MaxPyramiding * (subState.Pyramiding + 1);
                    var bookValue = subState.State.NormalBalance * subState.State.AverageBuyPrice;
                    var remainedQuantity = C.AsLong((hasToBuyAmount - bookValue) / subState.State.CurrentPrice);

                    var nextPyramidingPrice = subState.NextPyramidingPrice;

                    if (nextPyramidingPrice <= 0)
                    {
                        Main.LogWriter.Write($"{subState.State.ShortCode} {subState.State.Name} Pyramiding Price Error");
                        continue;
                    }

                    bool signal = subState.State.CurrentPrice < nextPyramidingPrice
                                  && subState.RSI[0] > _StrategyParams.OverSold && subState.RSI[1] < _StrategyParams.OverSold;

                    if (signal)
                    {
                        var orderPrice = subState.State.PriceHelper.GetNextPriceAboveTicks(subState.State.Expected.Price, 1);
                        var orderQuantity = remainedQuantity;

                        if (orderPrice > subState.State.CurrentPrice * 1.01)
                            orderQuantity = Math.Min(remainedQuantity, C.AsLong(subState.State.Expected.Volume * 0.2));

                        if (orderQuantity <= 0) { continue; }

                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode && x.AskBidType == AskBidType.Ask).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            var orderedPrice = liveOrders.Min(x => x.Price);
                            orderPrice = Math.Min(orderPrice, subState.State.PriceHelper.GetNextPriceBelow(orderedPrice));
                        }

                        Main.LogWriter.Write($"[ {subState.Pyramiding + 1} Pyramiding Order ] {subState.State.ShortCode} {subState.State.Name} Bid {orderQuantity} @ {orderPrice}");

                        if (TradeOffButton.Checked) { continue; }

                        subState.State.NewOrder(AskBidType.Bid, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);

                        subState.Done = true;
                        subState.Pyramiding += 1;
                        subState.LastBuyDate = DateTime.Today;
                        continue;
                    }
                }
            }

            HasPendingRequest = false;

            ClosingPriceOrdered.Status = true;
        }

        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution)
            {
                if (SubStates.TryGetValue(state.ShortCode, out SubState subState))
                {
                    subState.UpdatePrice();
                }
            }
        }
        public void OnConfirm(StockState state)
        {
        }
        public void OnExecution(StockState state)
        {
        }

        private void SignalButton_Click(object sender, EventArgs e)
        {
        }

        private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
        private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

        private class SubState
        {
            public StockState State;
            public StrategyParams Params;
            public TypeConverter C = new TypeConverter();
            public long PreviousDayMarketCap;
            public int Rank;
            public int Pyramiding;

            public bool HasToBuy;
            public bool HasToSell;
            public bool HadToSell;
            public bool Done;

            public bool Enabled;

            public long NextPyramidingPrice;
            public List<double> PriceSet = new List<double>();
            public List<double> uSet = new List<double>();
            public List<double> dSet = new List<double>();
            public List<double> auSet = new List<double>();
            public List<double> adSet = new List<double>();

            public List<double> RSI = new List<double>();

            public DateTime LastBuyDate { get; internal set; } = new DateTime();

            public void Enable() { this.Enabled = true; }
            public bool IsAble() => this.Enabled;
            public void Disable() { this.Enabled = false; }


            public SubState(StockState state, StrategyParams strategyParams)
            {
                this.State = state;
                this.Params = strategyParams;
                this.PreviousDayMarketCap = State.PreviousDayPrice * State.OutstandingShares;

                var bookValue = State.NormalBalance * State.AverageBuyPrice;
                var pyramidingAmount = Params.MaxNotionalAmount / Params.MaxPyramiding;
                this.Pyramiding = C.AsInt(Math.Ceiling((decimal)bookValue / pyramidingAmount));
            }

            public void UpdatePyramiding()
            {
                var bookValue = State.NormalBalance * State.AverageBuyPrice;
                var pyramidingAmount = Params.MaxNotionalAmount / Params.MaxPyramiding;
                this.Pyramiding = C.AsInt(Math.Ceiling((decimal)bookValue / pyramidingAmount));

                Console.WriteLine($"{State.ShortCode} {State.Name} || Pyramiding={Pyramiding}");
            }

            public void AddToPriceSet(double price)
            {
                PriceSet.Add(price);
            }

            public void UpdatePrice()
            {
                if (PriceSet.Count() > Params.RSIPeriod && this.IsAble())
                {
                    PriceSet[0] = State.CurrentPrice;
                    UpdateRSI();
                }
            }

            private void UpdateRSI()
            {
                var delta = State.CurrentPrice - PriceSet[1];

                var u = (delta + Math.Abs(delta)) / 2;
                var d = Math.Abs((delta - Math.Abs(delta)) / 2);

                uSet[0] = u;
                dSet[0] = d;

                var au = (u + auSet[1] * (Params.RSIPeriod - 1)) / Params.RSIPeriod;
                var ad = (d + adSet[1] * (Params.RSIPeriod - 1)) / Params.RSIPeriod;

                auSet[0] = au;
                adSet[0] = ad;

                var rsi = au / (au + ad) * 100;

                RSI[0] = rsi;
            }

            public void CalculateRSI()
            {
                var priceCount = PriceSet.Count();

                for (int i = 0; i < priceCount - 1; i++)
                {
                    var delta = PriceSet.ElementAt(i) - PriceSet.ElementAt(i + 1);

                    var u = (delta + Math.Abs(delta)) / 2;
                    var d = Math.Abs((delta - Math.Abs(delta)) / 2);

                    uSet.Insert(0, u);
                    dSet.Insert(0, d);
                }

                for (int i = 0; i < uSet.Count(); i++)
                {
                    if (i < Params.RSIPeriod)
                    {
                        RSI.Insert(0, 100.0);
                    }
                    else if (i == Params.RSIPeriod)
                    {
                        var au = uSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        var ad = dSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI.Insert(0, rsi);
                    }
                    else
                    {
                        var u = uSet.ToList()[i];
                        var d = dSet.ToList()[i];

                        var au = (u + auSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;
                        var ad = (d + adSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;

                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI.Insert(0, rsi);
                    }
                }
                this.Enable();
            }
        }

        internal class StrategyParams
        {
            public double OverSold { get; private set; }
            public double OverBought { get; private set; }
            public int RSIPeriod { get; private set; }
            public int SignalPeriod { get; private set; }
            public int MAPeriod { get; private set; }
            public int RankUpTo { get; private set; }
            public double AddPositionLevel { get; private set; }
            public double TargetRate { get; private set; }
            public double LossCutRate { get; private set; }
            public long MaxNotionalAmount { get; private set; }
            public int MaxPyramiding { get; private set; }
            public long MaxAmountPerOrder { get; private set; }

            public void StartegyParams()
            {
            }

            public bool Update(double overSold, 
                               double overBought, 
                               int rsiPeriod, 
                               int signalPeriod, 
                               int maPeriod, 
                               int rankUpTo,
                               double addPositionLevel, 
                               double targetRate, 
                               double losscutRate, 
                               long maxNotionalAmount, 
                               int maxPyramiding, 
                               long maxAmountPerOrder)
            {
                if (!DoubleGreaterThan(overSold, 0.0) || !DoubleGreaterThan(overBought, 0.0) || !DoubleGreaterThan(targetRate, 0.0))
                    return false;

                if (!DoubleLessThan(addPositionLevel, 0.0) || !DoubleLessThan(losscutRate, 0.0))
                    return false;

                if (DoubleGreaterThan(overSold, overBought) || DoubleGreaterThan(losscutRate, targetRate))
                    return false;

                if (maxNotionalAmount <= 0 || maxPyramiding <= 0 || maxAmountPerOrder <= 0 || rankUpTo <= 0 || rsiPeriod <= 0 || signalPeriod <= 0 || maPeriod <= 0)
                    return false;

                this.OverSold = overSold;
                this.OverBought = overBought;
                this.RSIPeriod = rsiPeriod;
                this.SignalPeriod = signalPeriod;
                this.MAPeriod = maPeriod;
                this.RankUpTo = rankUpTo;
                this.AddPositionLevel = addPositionLevel;
                this.TargetRate = targetRate;
                this.LossCutRate = losscutRate;
                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxPyramiding = maxPyramiding;
                this.MaxAmountPerOrder = maxAmountPerOrder;

                return true;
            }
        }
    }
}
