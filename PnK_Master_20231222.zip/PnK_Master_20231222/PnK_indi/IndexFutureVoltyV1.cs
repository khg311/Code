﻿using AxGIExpertControl64Lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PnK_indi
{
    public partial class IndexFutureVoltyV1 : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer Timer = new Timer();

        private Dictionary<string, HistoricalData> HistoricalDatas = new Dictionary<string, HistoricalData>();

        private IndexFutureVoltyV1Params kospiParams = new IndexFutureVoltyV1Params();
        private IndexFutureVoltyV1Params kosdaqParams = new IndexFutureVoltyV1Params();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KospiChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KosdaqChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KospiETFChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KosdaqETFChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private DateTime AtBegining = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 40, 0);
        private DateTime OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 1, 0);
        private DateTime StockClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 20, 0);
        private DateTime FutureLastOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 34, 50);
        private DateTime EndTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);

        public bool Enabled;
        public bool isReadyForKospi = false;
        public bool isReadyForKosdaq = false;

        public bool ShouldEnterKospi = false;
        public bool ShouldEnterKosdaq = false;

        public int MarketOperationCase = 1;


        private Dictionary<string, Queue<(DateTime, double)>> PriceQues = new Dictionary<string, Queue<(DateTime, double)>>();
        private bool isReadyForKospiFutures = false;
        private bool isReadyForKosdaqFutures = false;

        private bool isKospiLongTraded;
        private bool isKospiShortTraded;
        private bool isKosdaqLongTraded;
        private bool isKosdaqShortTraded;

        public IndexFutureVoltyV1(MainWindow main)
        {
            InitializeComponent();

            this.Main = main;

            indi_KospiChartCtrl.CreateControl();
            indi_KospiChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKospiChartData);

            indi_KosdaqChartCtrl.CreateControl();
            indi_KosdaqChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKosdaqChartData);

            indi_KospiETFChartCtrl.CreateControl();
            indi_KospiETFChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKospiETFChartData);

            indi_KosdaqETFChartCtrl.CreateControl();
            indi_KosdaqETFChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKosdaqETFChartData);
        }

        private void Enable()
        {
            Enabled = true;
        }
        public bool IsEnabled() => Enabled;
        public void Disable()
        {
            Enabled = false;
        }
        public void ClearAll()
        {
            //foreach (var state in Main.KospiFutureStates.Values)
            //    state.Clear();
        }

        private void InitParams()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {

            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                AtBegining = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 40, 0);
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 1, 0);
                StockClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 20, 0);
                FutureLastOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 34, 30);
                EndTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                AtBegining = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 40, 0);
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 1, 0);
                StockClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 20, 0);
                FutureLastOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 34, 30);
                EndTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 50, 0);
            }

            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            
            kospiParams.Update(
                C.AsInt(KospiLengthTextBox.Text), 
                C.AsDouble(KospiMultiplierTextBox.Text), 
                C.AsDouble(KospiLossCutRateTextBox.Text), 
                C.AsLong(KospiTradingAmountTextBox.Text),
                C.AsLong(KospiMaxAmountPerOrder.Text)
                );
            kosdaqParams.Update(
                C.AsInt(KosdaqLengthTextBox.Text), 
                C.AsDouble(KosdaqMultiplierTextBox.Text), 
                C.AsDouble(KosdaqLossCutRateTextBox.Text), 
                C.AsLong(KosdaqTradingAmountTextBox.Text),
                C.AsLong(KosdaqMaxAmountPerOrder.Text)
                );
        }

        private void RunBtn_Click(object sender, EventArgs e)
        {

            if (!KospiTradeOnBtn.Checked && !KospiTradeOffBtn.Checked)
            {
                MessageBox.Show("KOSPI200 트레이드 옵션을 선택하세요");
                return;
            }

            if (!KosdaqTradeOnBtn.Checked && !KosdaqTradeOffBtn.Checked)
            {
                MessageBox.Show($"KOSDAQ150 트레이드 옵션을 선택하세요");
                return;
            }

            InitParams();
            KospiParamsGroup.Enabled = false;
            KosdaqParamsGroup.Enabled = false;
            InitStates();

            Timer.Set(5 * 1000);
            Timer.Start(OnTimer);
            Main.MainLog($"Run Volty Expan.");
        }

        private void InitStates()
        {
            Enable();

            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear != null)
            {
                Main.RequestG701F(kospiNear.ShortCode);
                Main.RequestB601F(kospiNear.ShortCode);

                HistoricalDatas[kospiNear.ShortCode] = new HistoricalData(kospiNear.ShortCode, kospiParams.Length, kospiParams.Multiplier);
            }

            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear != null)
            {
                Main.RequestG702F(kosdaqNear.ShortCode);
                Main.RequestB602F(kosdaqNear.ShortCode);

                HistoricalDatas[kosdaqNear.ShortCode] = new HistoricalData(kosdaqNear.ShortCode, kosdaqParams.Length, kosdaqParams.Multiplier);
            }

            var kospiETF = Main.States.Values.Where(x => x.ShortCode == "122630").FirstOrDefault();
            if (kospiETF != null)
            {
                Main.RequestB703S(kospiETF.StandardCode);
                Main.RequestA303S(kospiETF.StandardCode);

                HistoricalDatas[kospiETF.ShortCode] = new HistoricalData(kospiETF.ShortCode, kosdaqParams.Length, kosdaqParams.Multiplier);
            }

            var kosdaqETF = Main.States.Values.Where(x => x.ShortCode == "233740").FirstOrDefault();
            if (kosdaqETF != null)
            {
                Main.RequestB703S(kosdaqETF.StandardCode);
                Main.RequestA303S(kosdaqETF.StandardCode);

                HistoricalDatas[kosdaqETF.ShortCode] = new HistoricalData(kosdaqETF.ShortCode, kosdaqParams.Length, kosdaqParams.Multiplier);
            }
        }
        private void SetPreDataKospi()
        {

            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear != null)
            {
                indi_KospiChartCtrl.SetQueryName("TR_FNCHART");
                indi_KospiChartCtrl.SetSingleData(0, kospiNear.ShortCode.Substring(0, 5));
                indi_KospiChartCtrl.SetSingleData(1, "D");
                indi_KospiChartCtrl.SetSingleData(2, "1");
                indi_KospiChartCtrl.SetSingleData(3, "00000000");
                indi_KospiChartCtrl.SetSingleData(4, "99999999");
                indi_KospiChartCtrl.SetSingleData(5, "20");

                var nRet = indi_KospiChartCtrl.RequestData();

                if (nRet <= 0)
                {
                    Main.LogWriter.Write("Error on Indi Request [TR_FCHART] for Kospi200.");
                }
            }
        }

        private void SetPreDataKosdaq()
        {

            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear != null)
            {
                indi_KosdaqChartCtrl.SetQueryName("TR_FNCHART");
                indi_KosdaqChartCtrl.SetSingleData(0, kosdaqNear.ShortCode.Substring(0, 5));
                indi_KosdaqChartCtrl.SetSingleData(1, "D");
                indi_KosdaqChartCtrl.SetSingleData(2, "1");
                indi_KosdaqChartCtrl.SetSingleData(3, "00000000");
                indi_KosdaqChartCtrl.SetSingleData(4, "99999999");
                indi_KosdaqChartCtrl.SetSingleData(5, "20");

                var nRet = indi_KosdaqChartCtrl.RequestData();

                if (nRet <= 0)
                {
                    Main.LogWriter.Write("Error on Indi Request [TR_FCHART] for Kosdaq150.");
                }
            }
        }

        private void SetPreDataKospiETF()
        {
            indi_KospiETFChartCtrl.SetQueryName("TR_SCHART");
            indi_KospiETFChartCtrl.SetSingleData(0, "122630");
            indi_KospiETFChartCtrl.SetSingleData(1, "D");
            indi_KospiETFChartCtrl.SetSingleData(2, "1");
            indi_KospiETFChartCtrl.SetSingleData(3, "00000000");
            indi_KospiETFChartCtrl.SetSingleData(4, "99999999");
            indi_KospiETFChartCtrl.SetSingleData(5, "20");

            var nRet = indi_KospiETFChartCtrl.RequestData();

            if (nRet <= 0)
            {
                Main.LogWriter.Write("Error on Indi Request [TR_SCHART] for 122630.");
            }
        }

        private void SetPreDataKosdaqETF()
        {
            indi_KosdaqETFChartCtrl.SetQueryName("TR_SCHART");
            indi_KosdaqETFChartCtrl.SetSingleData(0, "233740");
            indi_KosdaqETFChartCtrl.SetSingleData(1, "D");
            indi_KosdaqETFChartCtrl.SetSingleData(2, "1");
            indi_KosdaqETFChartCtrl.SetSingleData(3, "00000000");
            indi_KosdaqETFChartCtrl.SetSingleData(4, "99999999");
            indi_KosdaqETFChartCtrl.SetSingleData(5, "20");

            var nRet = indi_KosdaqETFChartCtrl.RequestData();

            if (nRet <= 0)
            {
                Main.LogWriter.Write("Error on Indi Request [TR_SCHART] for 233740.");
            }
        }

        private void Indi_ReceiveKospiChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear == null)
                return;

            var shortCode = kospiNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KospiChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KospiChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 5));

                HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            isReadyForKospiFutures = true;
        }

        private void Indi_ReceiveKosdaqChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear == null)
                return;

            var shortCode = kosdaqNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KosdaqChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KosdaqChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 5));

                HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            isReadyForKosdaqFutures = true;
        }

        private void Indi_ReceiveKospiETFChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            string shortCode = "122630";

            if (Main.States.TryGetValue(shortCode, out var state))
            {
                int updateTimes = 0;

                var todayDay = DateTime.Today.Day;

                int nCnt = C.AsInt(indi_KospiETFChartCtrl.GetMultiRowCount());

                for (short i = 0; i < nCnt; i++)
                {
                    var thisDay = C.AsInt(C.AsString(indi_KospiETFChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                    if (thisDay == todayDay) { continue; }

                    var high = C.AsDouble(indi_KospiETFChartCtrl.GetMultiData(i, 3));
                    var low = C.AsDouble(indi_KospiETFChartCtrl.GetMultiData(i, 4));
                    var close = C.AsDouble(indi_KospiETFChartCtrl.GetMultiData(i, 5));

                    HistoricalDatas[shortCode].Update(high, low, close);

                    updateTimes += 1;

                    if (updateTimes > kospiParams.Length)
                    {
                        break;
                    }
                }

                HistoricalDatas[shortCode].CalcVolty();

                isReadyForKospi = true;
            }
        }

        private void Indi_ReceiveKosdaqETFChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {

            string shortCode = "233740";

            if (Main.States.TryGetValue(shortCode, out var state))
            {
                int updateTimes = 0;

                var todayDay = DateTime.Today.Day;

                int nCnt = C.AsInt(indi_KosdaqETFChartCtrl.GetMultiRowCount());

                for (short i = 0; i < nCnt; i++)
                {
                    var thisDay = C.AsInt(C.AsString(indi_KosdaqETFChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                    if (thisDay == todayDay) { continue; }

                    var high = C.AsDouble(indi_KosdaqETFChartCtrl.GetMultiData(i, 3));
                    var low = C.AsDouble(indi_KosdaqETFChartCtrl.GetMultiData(i, 4));
                    var close = C.AsDouble(indi_KosdaqETFChartCtrl.GetMultiData(i, 5));

                    HistoricalDatas[shortCode].Update(high, low, close);

                    updateTimes += 1;

                    if (updateTimes > kosdaqParams.Length)
                    {
                        break;
                    }
                }

                HistoricalDatas[shortCode].CalcVolty();

                isReadyForKosdaq = true;
            }
        }

        private void OnTimer(object sender, EventArgs e)
        {
            if (DateTime.Now < AtBegining) { return; }
            
            if (!isReadyForKospi)
            {
                SetPreDataKospiETF();
                return;
            }

            if (!isReadyForKosdaq)
            {
                SetPreDataKosdaqETF();
                return;
            }

            if (!isReadyForKospiFutures)
            {
                SetPreDataKospi();
                return;
            }
            
            if (!isReadyForKosdaqFutures)
            {
                SetPreDataKosdaq();
                return;
            }

            if (DateTime.Now < OpeningTime)
            {
                return;
            }

            if (DateTime.Now > EndTime)
            {
                Timer.Finish();
                Environment.Exit(0);
            }

            foreach (var shortCode in HistoricalDatas.Keys)
            {
                if (shortCode.Substring(0, 3) == "101")
                {
                    var dataETF = HistoricalDatas["122630"];
                    var stateETF = Main.States["122630"];
                    var state = Main.DerivStates[shortCode];

                    var currentPrice = state.CurrentPrice;
                    if (currentPrice < 10)
                    {
                        Console.WriteLine($"[K200] PRICE ERROR :: CurrentPrice: {currentPrice}");
                        continue;
                    }

                    bool longEntryCondition = dataETF.VoltyHigh < stateETF.CurrentPrice && DateTime.Now < StockClosingTime;
                    bool longTargetCondition = C.AsDouble(state.Quote[0].BidPrice) > state.AveragePrice * 1.02 && DateTime.Now < StockClosingTime;
                    bool longClearCondition = C.AsDouble(state.Quote[0].BidPrice) > state.AveragePrice && DateTime.Now > StockClosingTime && DateTime.Now < FutureLastOrderTime;

                    bool shortEntryCondition = dataETF.VoltyLow > stateETF.CurrentPrice && DateTime.Now < StockClosingTime;
                    bool shortTargetCondition = C.AsDouble(state.Quote[0].AskPrice) < state.AveragePrice * 0.98 && DateTime.Now < StockClosingTime;
                    bool shortClearCondition = C.AsDouble(state.Quote[0].AskPrice) < state.AveragePrice && DateTime.Now > StockClosingTime && DateTime.Now < FutureLastOrderTime;

                    if (!KospiTradeOnBtn.Checked)
                    {
                        continue;
                    }

                    if (state.LiveOrders.Any(x => x.LiveQuantity > 0) || KospiTradeOffBtn.Checked)
                    {
                        var liveOrders = state.LiveOrders;

                        foreach (var liveOrder in liveOrders.ToList())
                        {
                            if ((DateTime.Now - liveOrder.OrderTime).TotalSeconds > 30)
                                state.CancelOrder(liveOrder);
                        }

                        continue;
                    }

                    //기존 포지션이 없는 경우
                    if (state.NormalBalance == 0)
                    {
                        if (DateTime.Now > StockClosingTime) { continue; }
                        
                        if (stateETF.OpenPrice > dataETF.VoltyHigh * 1.01 || stateETF.OpenPrice < dataETF.VoltyLow * 0.99)
                        {
                            Main.LogWriter.Write($"[K200] Open Price is too far from volty channel.");
                            continue;
                        }

                        if (stateETF.CurrentPrice > dataETF.VoltyHigh * 1.01 || stateETF.CurrentPrice < dataETF.VoltyLow * 0.99)
                        {
                            Main.LogWriter.Write($"[K200] Current Price is too far from volty channel.");
                            continue;
                        }

                        if (state.CurrentPrice > HistoricalDatas[state.ShortCode].PreviousClose * 1.05 
                            || state.CurrentPrice < HistoricalDatas[state.ShortCode].PreviousClose * 0.95)
                        {
                            Main.LogWriter.Write($"[K200] Price is too far from Previous Close +-5%.");
                            continue;
                        }

                        if (longEntryCondition && !isKospiLongTraded)
                        {
                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(Math.Min(kospiParams.TradingAmount, kospiParams.MaxAmountPerOrder) / state.CurrentPrice / 250_000)));
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[1].AskPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            ShouldEnterKospi = true;
                            Main.LogWriter.Write($"[K200] VoltyLE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} > vHigh = {dataETF.VoltyHigh}");
                            continue;
                        }

                        else if (shortEntryCondition && !isKospiShortTraded)
                        {
                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(Math.Min(kospiParams.TradingAmount, kospiParams.MaxAmountPerOrder) / state.CurrentPrice / 250_000)));
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[1].BidPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            ShouldEnterKospi = true;
                            Main.LogWriter.Write($"[K200] VoltySE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} < vLow = {dataETF.VoltyLow}");
                            continue;
                        }
                    }

                    // 기존 롱 포지션 있는 경우
                    else if (state.NormalBalance > 0)
                    {
                        if (ShouldEnterKospi && state.CurrentPrice < state.AveragePrice * 0.997)
                        {
                            var maxContracts = C.AsInt(Math.Floor(kospiParams.TradingAmount / state.CurrentPrice / 250_000));

                            if (state.NormalBalance >= maxContracts)
                            {
                                ShouldEnterKospi = false;
                                continue;
                            }

                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(kospiParams.TradingAmount / kospiParams.NumOrders / state.CurrentPrice / 250_000)));
                            tradingContracts = 1;
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Volty ADD Long  :: Position = {state.NormalBalance} / MaxPosition = {maxContracts}");
                            continue;
                        }
                        else if (longTargetCondition)
                        {
                            isKospiLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Long Clear      :: CurrentPrice = {state.CurrentPrice} > AvgPrice + 2.0%");
                            continue;
                        }
                        else if (longClearCondition)
                        {
                            isKospiLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Long Clear      :: CurrentPrice = {state.CurrentPrice} > AvgPrice = {state.AveragePrice}");
                            continue;
                        }
                        else if (shortEntryCondition)
                        {
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] VoltySE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} < vLow = {dataETF.VoltyLow}");
                            continue;
                        }
                        else if (currentPrice < state.AveragePrice * (1 - kospiParams.LossCut) && DateTime.Now < FutureLastOrderTime)
                        {
                            isKospiLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Long Loss Cut   :: CurrentPrice = {currentPrice} < AvgPrice * (1 - LossCut) = {state.AveragePrice * (1 - 0.01):N2}");
                            continue;
                        }
                    }
                    // 기존 숏 포지션 있는 경우
                    else if (state.NormalBalance < 0)
                    {
                        if (ShouldEnterKospi && state.CurrentPrice > state.AveragePrice * 1.003)
                        {
                            var maxContracts = C.AsInt(Math.Floor(kospiParams.TradingAmount / state.CurrentPrice / 250_000));

                            if (Math.Abs(state.NormalBalance) >= maxContracts)
                            {
                                ShouldEnterKospi = false;
                                continue;
                            }

                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(kospiParams.TradingAmount / kospiParams.NumOrders / state.CurrentPrice / 250_000)));
                            tradingContracts = 1;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Volty ADD SHORT :: Position = {state.NormalBalance} / MaxPosition = {maxContracts}");
                            continue;
                        }
                        else if (shortTargetCondition)
                        {
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Short Target     :: CurrentPrice = {state.CurrentPrice} < AvgPrice - 2.0%");
                            continue;
                        }
                        else if (shortClearCondition)
                        {
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Short Clear     :: CurrentPrice = {state.CurrentPrice} < AvgPrice = {state.AveragePrice}");
                            continue;
                        }
                        else if (longEntryCondition)
                        {
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] VoltyLE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} > vHigh = {dataETF.VoltyHigh}");
                            continue;
                        }
                        else if (currentPrice > state.AveragePrice * (1 + kospiParams.LossCut) && DateTime.Now < FutureLastOrderTime)
                        {
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[K200] Short Loss Cut  :: CurrentPrice = {currentPrice} > AvgPrice * (1 + LossCut) = {state.AveragePrice * (1 + 0.01):N2}");
                            continue;
                        }
                        
                    }
                }

                if (shortCode.Substring(0, 3) == "106")
                {
                    var dataETF = HistoricalDatas["233740"];
                    var stateETF = Main.States["233740"];
                    var state = Main.DerivStates[shortCode];

                    var currentPrice = state.CurrentPrice;
                    if (currentPrice < 10)
                    {
                        Console.WriteLine($"[Q150] PRICE ERROR :: CurrentPrice: {currentPrice}");
                        continue;
                    }

                    bool longEntryCondition = dataETF.VoltyHigh < stateETF.CurrentPrice && DateTime.Now < StockClosingTime;
                    bool longTargetCondition = C.AsDouble(state.Quote[0].BidPrice) > state.AveragePrice * 1.025 && DateTime.Now < StockClosingTime;
                    bool longClearCondition = C.AsDouble(state.Quote[0].BidPrice) > state.AveragePrice && DateTime.Now > StockClosingTime && DateTime.Now < FutureLastOrderTime;
                    

                    bool shortEntryCondition = dataETF.VoltyLow > stateETF.CurrentPrice && DateTime.Now < StockClosingTime;
                    bool shortTargetCondition = C.AsDouble(state.Quote[0].AskPrice) < state.AveragePrice * 0.975 && DateTime.Now < StockClosingTime;
                    bool shortClearCondition = C.AsDouble(state.Quote[0].AskPrice) < state.AveragePrice && DateTime.Now > StockClosingTime && DateTime.Now < FutureLastOrderTime;

                    if (!KosdaqTradeOnBtn.Checked)
                    {
                        continue;
                    }

                    if (state.LiveOrders.Any(x => x.LiveQuantity > 0) || KosdaqTradeOffBtn.Checked)
                    {
                        continue;
                    }

                    //기존 포지션이 없는 경우
                    if (state.NormalBalance == 0)
                    {
                        if (DateTime.Now > StockClosingTime) { continue; }

                        if (stateETF.OpenPrice > dataETF.VoltyHigh * 1.01 || stateETF.OpenPrice < dataETF.VoltyLow * 0.99)
                        {
                            Main.LogWriter.Write($"[Q150] Open Price is too far from volty channel."); 
                            continue;
                        }

                        if (stateETF.CurrentPrice > dataETF.VoltyHigh * 1.01 || stateETF.CurrentPrice < dataETF.VoltyLow * 0.99)
                        {
                            Main.LogWriter.Write($"[Q150] Current Price is too far from volty channel.");
                            continue;
                        }

                        if (stateETF.OpenPrice > stateETF.PreviousDayPrice * 1.03 || stateETF.OpenPrice < stateETF.PreviousDayPrice * 0.97)
                        {
                            Main.LogWriter.Write($"[Q150] Open Price is too far from Prev Close +-3%.");
                            continue;
                        }

                        if (state.CurrentPrice > HistoricalDatas[state.ShortCode].PreviousClose * 1.05
                            || state.CurrentPrice < HistoricalDatas[state.ShortCode].PreviousClose * 0.95)
                        {
                            Main.LogWriter.Write($"[Q150] Price is too far from Previous Close +-5%.");
                            continue;
                        }

                        if (longEntryCondition && !isKosdaqLongTraded)
                        {
                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(Math.Min(kosdaqParams.TradingAmount, kosdaqParams.MaxAmountPerOrder) / state.CurrentPrice / 10_000)));
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[3].AskPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            ShouldEnterKosdaq = true;
                            Main.LogWriter.Write($"[Q150] VoltyLE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} > vHigh = {dataETF.VoltyHigh}");
                            continue;
                        }

                        else if (shortEntryCondition && !isKosdaqShortTraded)
                        {
                            var tradingContracts = Math.Max(1, C.AsInt(Math.Floor(Math.Min(kosdaqParams.TradingAmount, kosdaqParams.MaxAmountPerOrder) / state.CurrentPrice / 10_000)));
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[3].BidPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            ShouldEnterKosdaq = true;
                            Main.LogWriter.Write($"[Q150] VoltySE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} < vLow = {dataETF.VoltyLow}");
                            continue;
                        }
                    }

                    // 기존 롱 포지션 있는 경우
                    else if (state.NormalBalance > 0)
                    {
                        if (ShouldEnterKosdaq && state.CurrentPrice < state.AveragePrice * 0.997)
                        {
                            var maxContracts = C.AsInt(Math.Floor(kosdaqParams.TradingAmount / state.CurrentPrice / 10_000));

                            if (state.NormalBalance >= maxContracts)
                            {
                                ShouldEnterKosdaq = false;
                                continue;
                            }

                            var tradingContracts = 3;
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[4].AskPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Volty ADD Long  :: Position = {state.NormalBalance} / MaxPosition = {maxContracts}");
                            continue;
                        }
                        else if (longTargetCondition)
                        {
                            isKosdaqLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[4].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Long Target      :: CurrentPrice = {state.CurrentPrice} > AvgPrice + 2.5%");
                            continue;
                        }
                        else if (longClearCondition)
                        {
                            isKosdaqLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[4].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Long Clear      :: CurrentPrice = {state.CurrentPrice} > AvgPrice = {state.AveragePrice}");
                            continue;
                        }
                        else if (shortEntryCondition && !isKosdaqShortTraded)
                        {
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[4].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] VoltySE SIGNAL  :: CurrentPrice = {stateETF.CurrentPrice} < vLow = {dataETF.VoltyLow}");
                            continue;
                        }
                        else if (currentPrice < state.AveragePrice * (1 - kosdaqParams.LossCut) && DateTime.Now < FutureLastOrderTime)
                        {
                            isKosdaqLongTraded = true;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[4].BidPrice), state.NormalBalance, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Long Loss Cut   :: CurrentPrice = {currentPrice} < AvgPrice * (1 - LossCut) = {state.AveragePrice * (1 - 0.01):N2}");
                            continue;
                        }
                    }
                    // 기존 숏 포지션 있는 경우
                    else if (state.NormalBalance < 0)
                    {
                        if (ShouldEnterKosdaq && state.CurrentPrice > state.AveragePrice * 1.003)
                        {
                            var maxContracts = C.AsInt(Math.Floor(kosdaqParams.TradingAmount / state.CurrentPrice / 10_000));

                            if (Math.Abs(state.NormalBalance) >= maxContracts)
                            {
                                ShouldEnterKosdaq = false;
                                continue;
                            }

                            var tradingContracts = 3;
                            state.NewOrder(AskBidType.Ask, C.AsDouble(state.Quote[4].BidPrice), tradingContracts, OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Volty ADD Short :: Position = {state.NormalBalance} / MaxPosition = {-maxContracts}");
                            continue;
                        }
                        else if (shortTargetCondition)
                        {
                            isKosdaqShortTraded = true;
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[4].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"Q150] Short Target      :: CurrentPrice = {state.CurrentPrice} < AvgPrice - 2.5%");
                            continue;
                        }
                        else if (shortClearCondition)
                        {
                            isKosdaqShortTraded = true;
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[4].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"Q150] Short Clear      :: CurrentPrice = {state.CurrentPrice} < AvgPrice = {state.AveragePrice}");
                            continue;
                        }
                        else if (longEntryCondition)
                        {
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[4].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"Q150] VoltyLE SIGNAL   :: CurrentPrice = {stateETF.CurrentPrice} > vHigh = {dataETF.VoltyHigh}");
                            continue;
                        }
                        else if (currentPrice > state.AveragePrice * (1 + kosdaqParams.LossCut) && DateTime.Now < FutureLastOrderTime)
                        {
                            isKosdaqShortTraded = true;
                            state.NewOrder(AskBidType.Bid, C.AsDouble(state.Quote[4].AskPrice), Math.Abs(state.NormalBalance), OrderType.Limit, OrderCondition.Normal);
                            Main.LogWriter.Write($"[Q150] Short Loss Cut  :: CurrentPrice = {currentPrice} > AvgPrice * (1 + LossCut) = {state.AveragePrice * (1 + 0.01):N2}");
                            continue;
                        }
                    }
                }
            }
        }

        private void PauseBtn_Click(object sender, EventArgs e)
        {
            Main.LogWriter.Write("Index Future Volty paused");
            KospiParamsGroup.Enabled = true;
            KosdaqParamsGroup.Enabled = true;

            if (Timer != null)
                Timer.Finish();

            Disable();
        }

        public class IndexFutureVoltyV1Params
        {
            public int Length { get; private set; }
            public double Multiplier { get; private set; }
            public double LossCut { get; private set; }
            public long TradingAmount { get; private set; }
            public int NumOrders { get; private set; }
            public long MaxAmountPerOrder { get; private set; }
            public MarketType MarketType { get; private set; }

            public IndexFutureVoltyV1Params()
            {
                this.Length = 5;
                this.Multiplier = 0.8;
                this.LossCut = 0.01;
                this.TradingAmount = 100_000_000;
                this.NumOrders = 1;
            }

            public bool Update(int length, double multiplier, double losscutRate, long tradingAmount, long maxAmountPerOrder)
            {
                if (length <= 0)
                {
                    return false;
                }

                if (multiplier <= 0 || multiplier >= 1)
                {
                    return false;
                }

                this.Length = length;
                this.Multiplier = multiplier;
                this.LossCut = losscutRate / 100.0;
                this.TradingAmount = tradingAmount * 100_000_000;
                this.MaxAmountPerOrder = maxAmountPerOrder * 100_000_000;

                return true;
            }

        }
        internal class HistoricalData
        {
            public string ShortCode { get; private set; }
            public Queue<double> HighPrices { get; private set; }
            public Queue<double> LowPrices { get; private set; }
            public Queue<double> ClosePrices { get; private set; }
            public Queue<double> TrueRange { get; private set; }

            public double PreviousClose { get; private set; }

            public int Length { get; private set; }
            public double ATR { get; private set; }
            public double Multiplier { get; private set; }
            public double VoltyHigh { get; private set; }
            public double VoltyLow { get; private set; }


            public HistoricalData(string shortCode, int length, double multiplier)
            {
                this.ShortCode = shortCode;
                this.Length = length;
                this.Multiplier = multiplier;

                this.HighPrices = new Queue<double>();
                this.LowPrices = new Queue<double>();
                this.ClosePrices = new Queue<double>();
                this.TrueRange = new Queue<double>();
            }

            public void Update(double high, double low, double close)
            {
                this.HighPrices.Enqueue(high);
                this.LowPrices.Enqueue(low);
                this.ClosePrices.Enqueue(close);

                if (this.ShortCode.StartsWith("10"))
                    this.PreviousClose = close;
            }

            public void CalcVolty()
            {
                if (this.HighPrices.Count < this.Length + 1 || this.LowPrices.Count < this.Length + 1 || this.ClosePrices.Count < this.Length + 1)
                {
                    return;
                }

                double cClose = this.ClosePrices.Dequeue();
                this.PreviousClose = cClose;

                for (int i = 0; i < this.Length; i++)
                {
                    double cHigh = this.HighPrices.Dequeue();
                    double cLow = this.LowPrices.Dequeue();
                    double pClose = this.ClosePrices.Dequeue();

                    this.TrueRange.Enqueue(Math.Max(cHigh, pClose) - Math.Min(cLow, pClose));
                }

                this.ATR = this.Multiplier * this.TrueRange.Average();

                this.VoltyHigh = cClose + this.ATR;
                this.VoltyLow = cClose - this.ATR;

                Console.WriteLine($"Today {this.ShortCode} Volty Values => [ {this.VoltyLow:N2}, {this.VoltyHigh:N2} ]");
            }
        }
    }
}