﻿
namespace PnK_indi
{
    partial class StockFuturesBasis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.EntryOffButton = new System.Windows.Forms.RadioButton();
            this.EntryOnButton = new System.Windows.Forms.RadioButton();
            this.ResumeButton = new System.Windows.Forms.Button();
            this.PauseButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TradeOffButton = new System.Windows.Forms.RadioButton();
            this.TradeOnButton = new System.Windows.Forms.RadioButton();
            this.ParamsGroupBox = new System.Windows.Forms.GroupBox();
            this.MaxOrderQuantityBox = new System.Windows.Forms.TextBox();
            this.MaxQuantityBalanceBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.MaxOrderAmountBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MaxNotionalAmountBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TargetReturnBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.EntryBasisBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.RunButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.ParamsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.EntryOffButton);
            this.groupBox2.Controls.Add(this.EntryOnButton);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(36, 363);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(132, 51);
            this.groupBox2.TabIndex = 78;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Entry On/Off";
            // 
            // EntryOffButton
            // 
            this.EntryOffButton.AutoSize = true;
            this.EntryOffButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EntryOffButton.Location = new System.Drawing.Point(72, 25);
            this.EntryOffButton.Name = "EntryOffButton";
            this.EntryOffButton.Size = new System.Drawing.Size(45, 20);
            this.EntryOffButton.TabIndex = 1;
            this.EntryOffButton.Text = "Off";
            this.EntryOffButton.UseVisualStyleBackColor = true;
            // 
            // EntryOnButton
            // 
            this.EntryOnButton.AutoSize = true;
            this.EntryOnButton.Checked = true;
            this.EntryOnButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EntryOnButton.Location = new System.Drawing.Point(16, 25);
            this.EntryOnButton.Name = "EntryOnButton";
            this.EntryOnButton.Size = new System.Drawing.Size(43, 20);
            this.EntryOnButton.TabIndex = 0;
            this.EntryOnButton.TabStop = true;
            this.EntryOnButton.Text = "On";
            this.EntryOnButton.UseVisualStyleBackColor = true;
            // 
            // ResumeButton
            // 
            this.ResumeButton.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ResumeButton.Location = new System.Drawing.Point(678, 179);
            this.ResumeButton.Name = "ResumeButton";
            this.ResumeButton.Size = new System.Drawing.Size(87, 40);
            this.ResumeButton.TabIndex = 80;
            this.ResumeButton.Text = "RESUME";
            this.ResumeButton.UseVisualStyleBackColor = true;
            // 
            // PauseButton
            // 
            this.PauseButton.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.PauseButton.Location = new System.Drawing.Point(678, 119);
            this.PauseButton.Name = "PauseButton";
            this.PauseButton.Size = new System.Drawing.Size(87, 40);
            this.PauseButton.TabIndex = 79;
            this.PauseButton.Text = "PAUSE";
            this.PauseButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TradeOffButton);
            this.groupBox1.Controls.Add(this.TradeOnButton);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(36, 291);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(132, 56);
            this.groupBox1.TabIndex = 77;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trade On/Off";
            // 
            // TradeOffButton
            // 
            this.TradeOffButton.AutoSize = true;
            this.TradeOffButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradeOffButton.Location = new System.Drawing.Point(72, 25);
            this.TradeOffButton.Name = "TradeOffButton";
            this.TradeOffButton.Size = new System.Drawing.Size(45, 20);
            this.TradeOffButton.TabIndex = 1;
            this.TradeOffButton.Text = "Off";
            this.TradeOffButton.UseVisualStyleBackColor = true;
            // 
            // TradeOnButton
            // 
            this.TradeOnButton.AutoSize = true;
            this.TradeOnButton.Checked = true;
            this.TradeOnButton.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradeOnButton.Location = new System.Drawing.Point(16, 25);
            this.TradeOnButton.Name = "TradeOnButton";
            this.TradeOnButton.Size = new System.Drawing.Size(43, 20);
            this.TradeOnButton.TabIndex = 0;
            this.TradeOnButton.TabStop = true;
            this.TradeOnButton.Text = "On";
            this.TradeOnButton.UseVisualStyleBackColor = true;
            // 
            // ParamsGroupBox
            // 
            this.ParamsGroupBox.Controls.Add(this.MaxOrderQuantityBox);
            this.ParamsGroupBox.Controls.Add(this.MaxQuantityBalanceBox);
            this.ParamsGroupBox.Controls.Add(this.label8);
            this.ParamsGroupBox.Controls.Add(this.label6);
            this.ParamsGroupBox.Controls.Add(this.label5);
            this.ParamsGroupBox.Controls.Add(this.label3);
            this.ParamsGroupBox.Controls.Add(this.MaxOrderAmountBox);
            this.ParamsGroupBox.Controls.Add(this.label4);
            this.ParamsGroupBox.Controls.Add(this.MaxNotionalAmountBox);
            this.ParamsGroupBox.Controls.Add(this.label9);
            this.ParamsGroupBox.Controls.Add(this.TargetReturnBox);
            this.ParamsGroupBox.Controls.Add(this.label2);
            this.ParamsGroupBox.Controls.Add(this.EntryBasisBox);
            this.ParamsGroupBox.Controls.Add(this.label1);
            this.ParamsGroupBox.Font = new System.Drawing.Font("굴림", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ParamsGroupBox.Location = new System.Drawing.Point(36, 37);
            this.ParamsGroupBox.Name = "ParamsGroupBox";
            this.ParamsGroupBox.Size = new System.Drawing.Size(591, 234);
            this.ParamsGroupBox.TabIndex = 72;
            this.ParamsGroupBox.TabStop = false;
            this.ParamsGroupBox.Text = "ParamsGroupBox";
            // 
            // MaxOrderQuantityBox
            // 
            this.MaxOrderQuantityBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxOrderQuantityBox.Location = new System.Drawing.Point(484, 87);
            this.MaxOrderQuantityBox.Name = "MaxOrderQuantityBox";
            this.MaxOrderQuantityBox.Size = new System.Drawing.Size(100, 23);
            this.MaxOrderQuantityBox.TabIndex = 33;
            this.MaxOrderQuantityBox.Text = "100";
            this.MaxOrderQuantityBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MaxQuantityBalanceBox
            // 
            this.MaxQuantityBalanceBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxQuantityBalanceBox.Location = new System.Drawing.Point(484, 51);
            this.MaxQuantityBalanceBox.Name = "MaxQuantityBalanceBox";
            this.MaxQuantityBalanceBox.Size = new System.Drawing.Size(100, 23);
            this.MaxQuantityBalanceBox.TabIndex = 32;
            this.MaxQuantityBalanceBox.Text = "1000";
            this.MaxQuantityBalanceBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(275, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(201, 16);
            this.label8.TabIndex = 31;
            this.label8.Text = "Max_Quantity_Balance(계약수)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(276, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(188, 16);
            this.label6.TabIndex = 29;
            this.label6.Text = "Max_Order_Quantity(계약수)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(224, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "BP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(224, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 27;
            this.label3.Text = "BP";
            // 
            // MaxOrderAmountBox
            // 
            this.MaxOrderAmountBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxOrderAmountBox.Location = new System.Drawing.Point(484, 127);
            this.MaxOrderAmountBox.Name = "MaxOrderAmountBox";
            this.MaxOrderAmountBox.Size = new System.Drawing.Size(100, 23);
            this.MaxOrderAmountBox.TabIndex = 26;
            this.MaxOrderAmountBox.Text = "5000";
            this.MaxOrderAmountBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(276, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(202, 16);
            this.label4.TabIndex = 25;
            this.label4.Text = "Max_Order_Amount_(만원단위)";
            // 
            // MaxNotionalAmountBox
            // 
            this.MaxNotionalAmountBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxNotionalAmountBox.Location = new System.Drawing.Point(485, 22);
            this.MaxNotionalAmountBox.Name = "MaxNotionalAmountBox";
            this.MaxNotionalAmountBox.Size = new System.Drawing.Size(100, 23);
            this.MaxNotionalAmountBox.TabIndex = 22;
            this.MaxNotionalAmountBox.Text = "28";
            this.MaxNotionalAmountBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(281, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Max Notional Amount";
            // 
            // TargetReturnBox
            // 
            this.TargetReturnBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TargetReturnBox.Location = new System.Drawing.Point(118, 67);
            this.TargetReturnBox.Name = "TargetReturnBox";
            this.TargetReturnBox.Size = new System.Drawing.Size(100, 23);
            this.TargetReturnBox.TabIndex = 14;
            this.TargetReturnBox.Text = "20";
            this.TargetReturnBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "TargetReturn";
            // 
            // EntryBasisBox
            // 
            this.EntryBasisBox.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EntryBasisBox.Location = new System.Drawing.Point(118, 32);
            this.EntryBasisBox.Name = "EntryBasisBox";
            this.EntryBasisBox.Size = new System.Drawing.Size(100, 23);
            this.EntryBasisBox.TabIndex = 12;
            this.EntryBasisBox.Text = "0";
            this.EntryBasisBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "EntryBasis";
            // 
            // RunButton
            // 
            this.RunButton.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RunButton.Location = new System.Drawing.Point(678, 59);
            this.RunButton.Name = "RunButton";
            this.RunButton.Size = new System.Drawing.Size(87, 40);
            this.RunButton.TabIndex = 71;
            this.RunButton.Text = "RUN";
            this.RunButton.UseVisualStyleBackColor = true;
            this.RunButton.Click += new System.EventHandler(this.RunButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(201, 291);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 16);
            this.label7.TabIndex = 81;
            this.label7.Text = "다음 만기일";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(184, 315);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 31;
            this.textBox1.Text = "2023-11-07";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // StockFuturesBasis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 447);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.ResumeButton);
            this.Controls.Add(this.PauseButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ParamsGroupBox);
            this.Controls.Add(this.RunButton);
            this.Name = "StockFuturesBasis";
            this.Text = "StockFuturesBasis";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ParamsGroupBox.ResumeLayout(false);
            this.ParamsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton EntryOffButton;
        private System.Windows.Forms.RadioButton EntryOnButton;
        private System.Windows.Forms.Button ResumeButton;
        private System.Windows.Forms.Button PauseButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton TradeOffButton;
        private System.Windows.Forms.RadioButton TradeOnButton;
        private System.Windows.Forms.GroupBox ParamsGroupBox;
        private System.Windows.Forms.TextBox MaxOrderAmountBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MaxNotionalAmountBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TargetReturnBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox EntryBasisBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button RunButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox MaxQuantityBalanceBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox MaxOrderQuantityBox;
    }
}