﻿namespace PnK_indi
{
    partial class StockVoltyBreakMidCap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MarketOperationGroupBox = new System.Windows.Forms.GroupBox();
            this.Case3Button = new System.Windows.Forms.RadioButton();
            this.Case2Button = new System.Windows.Forms.RadioButton();
            this.Case1Button = new System.Windows.Forms.RadioButton();
            this.ParamsGroupBox = new System.Windows.Forms.GroupBox();
            this.ShortCheckBox = new System.Windows.Forms.CheckBox();
            this.LongCheckBox = new System.Windows.Forms.CheckBox();
            this.IndexConditionCheckBox = new System.Windows.Forms.CheckBox();
            this.NotionalBox = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TradeOffButton = new System.Windows.Forms.RadioButton();
            this.TradeOnButton = new System.Windows.Forms.RadioButton();
            this.ResumeButton = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.RunButton = new System.Windows.Forms.Button();
            this.BalanceButton = new System.Windows.Forms.Button();
            this.MarketOperationGroupBox.SuspendLayout();
            this.ParamsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NotionalBox)).BeginInit();
            this.SuspendLayout();
            // 
            // MarketOperationGroupBox
            // 
            this.MarketOperationGroupBox.Controls.Add(this.Case3Button);
            this.MarketOperationGroupBox.Controls.Add(this.Case2Button);
            this.MarketOperationGroupBox.Controls.Add(this.Case1Button);
            this.MarketOperationGroupBox.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarketOperationGroupBox.Location = new System.Drawing.Point(15, 270);
            this.MarketOperationGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.MarketOperationGroupBox.Name = "MarketOperationGroupBox";
            this.MarketOperationGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.MarketOperationGroupBox.Size = new System.Drawing.Size(273, 133);
            this.MarketOperationGroupBox.TabIndex = 119;
            this.MarketOperationGroupBox.TabStop = false;
            this.MarketOperationGroupBox.Text = "Market Operation";
            // 
            // Case3Button
            // 
            this.Case3Button.AutoSize = true;
            this.Case3Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Case3Button.Location = new System.Drawing.Point(26, 100);
            this.Case3Button.Margin = new System.Windows.Forms.Padding(4);
            this.Case3Button.Name = "Case3Button";
            this.Case3Button.Size = new System.Drawing.Size(131, 18);
            this.Case3Button.TabIndex = 112;
            this.Case3Button.TabStop = true;
            this.Case3Button.Text = "Case 3: 10 to 4.5";
            this.Case3Button.UseVisualStyleBackColor = true;
            // 
            // Case2Button
            // 
            this.Case2Button.AutoSize = true;
            this.Case2Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Case2Button.Location = new System.Drawing.Point(26, 64);
            this.Case2Button.Margin = new System.Windows.Forms.Padding(4);
            this.Case2Button.Name = "Case2Button";
            this.Case2Button.Size = new System.Drawing.Size(131, 18);
            this.Case2Button.TabIndex = 111;
            this.Case2Button.TabStop = true;
            this.Case2Button.Text = "Case 2: 10 to 3.5";
            this.Case2Button.UseVisualStyleBackColor = true;
            // 
            // Case1Button
            // 
            this.Case1Button.AutoSize = true;
            this.Case1Button.Checked = true;
            this.Case1Button.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Case1Button.Location = new System.Drawing.Point(26, 28);
            this.Case1Button.Margin = new System.Windows.Forms.Padding(4);
            this.Case1Button.Name = "Case1Button";
            this.Case1Button.Size = new System.Drawing.Size(123, 18);
            this.Case1Button.TabIndex = 110;
            this.Case1Button.TabStop = true;
            this.Case1Button.Text = "Case 1: 9 to 3.5";
            this.Case1Button.UseVisualStyleBackColor = true;
            // 
            // ParamsGroupBox
            // 
            this.ParamsGroupBox.Controls.Add(this.ShortCheckBox);
            this.ParamsGroupBox.Controls.Add(this.LongCheckBox);
            this.ParamsGroupBox.Controls.Add(this.IndexConditionCheckBox);
            this.ParamsGroupBox.Controls.Add(this.NotionalBox);
            this.ParamsGroupBox.Controls.Add(this.label2);
            this.ParamsGroupBox.Controls.Add(this.label1);
            this.ParamsGroupBox.Controls.Add(this.TradeOffButton);
            this.ParamsGroupBox.Controls.Add(this.TradeOnButton);
            this.ParamsGroupBox.Location = new System.Drawing.Point(15, 71);
            this.ParamsGroupBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.ParamsGroupBox.Name = "ParamsGroupBox";
            this.ParamsGroupBox.Padding = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.ParamsGroupBox.Size = new System.Drawing.Size(490, 189);
            this.ParamsGroupBox.TabIndex = 118;
            this.ParamsGroupBox.TabStop = false;
            this.ParamsGroupBox.Text = "Params";
            // 
            // ShortCheckBox
            // 
            this.ShortCheckBox.AutoSize = true;
            this.ShortCheckBox.Checked = true;
            this.ShortCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ShortCheckBox.Location = new System.Drawing.Point(285, 59);
            this.ShortCheckBox.Name = "ShortCheckBox";
            this.ShortCheckBox.Size = new System.Drawing.Size(68, 22);
            this.ShortCheckBox.TabIndex = 123;
            this.ShortCheckBox.Text = "Short";
            this.ShortCheckBox.UseVisualStyleBackColor = true;
            // 
            // LongCheckBox
            // 
            this.LongCheckBox.AutoSize = true;
            this.LongCheckBox.Checked = true;
            this.LongCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LongCheckBox.Location = new System.Drawing.Point(181, 59);
            this.LongCheckBox.Name = "LongCheckBox";
            this.LongCheckBox.Size = new System.Drawing.Size(63, 22);
            this.LongCheckBox.TabIndex = 122;
            this.LongCheckBox.Text = "Long";
            this.LongCheckBox.UseVisualStyleBackColor = true;
            // 
            // IndexConditionCheckBox
            // 
            this.IndexConditionCheckBox.AutoSize = true;
            this.IndexConditionCheckBox.Checked = true;
            this.IndexConditionCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IndexConditionCheckBox.Location = new System.Drawing.Point(26, 134);
            this.IndexConditionCheckBox.Name = "IndexConditionCheckBox";
            this.IndexConditionCheckBox.Size = new System.Drawing.Size(191, 22);
            this.IndexConditionCheckBox.TabIndex = 121;
            this.IndexConditionCheckBox.Text = "Apply Index Condition";
            this.IndexConditionCheckBox.UseVisualStyleBackColor = true;
            // 
            // NotionalBox
            // 
            this.NotionalBox.Increment = new decimal(new int[] {
            5000000,
            0,
            0,
            0});
            this.NotionalBox.Location = new System.Drawing.Point(179, 94);
            this.NotionalBox.Margin = new System.Windows.Forms.Padding(4);
            this.NotionalBox.Maximum = new decimal(new int[] {
            30000000,
            0,
            0,
            0});
            this.NotionalBox.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.NotionalBox.Name = "NotionalBox";
            this.NotionalBox.Size = new System.Drawing.Size(192, 26);
            this.NotionalBox.TabIndex = 7;
            this.NotionalBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NotionalBox.ThousandsSeparator = true;
            this.NotionalBox.Value = new decimal(new int[] {
            13000000,
            0,
            0,
            0});
            this.NotionalBox.ValueChanged += new System.EventHandler(this.NotionalBox_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Notional";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Trade";
            // 
            // TradeOffButton
            // 
            this.TradeOffButton.AutoSize = true;
            this.TradeOffButton.Location = new System.Drawing.Point(285, 28);
            this.TradeOffButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.TradeOffButton.Name = "TradeOffButton";
            this.TradeOffButton.Size = new System.Drawing.Size(50, 22);
            this.TradeOffButton.TabIndex = 4;
            this.TradeOffButton.Text = "Off";
            this.TradeOffButton.UseVisualStyleBackColor = true;
            // 
            // TradeOnButton
            // 
            this.TradeOnButton.AutoSize = true;
            this.TradeOnButton.Checked = true;
            this.TradeOnButton.Location = new System.Drawing.Point(183, 28);
            this.TradeOnButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.TradeOnButton.Name = "TradeOnButton";
            this.TradeOnButton.Size = new System.Drawing.Size(47, 22);
            this.TradeOnButton.TabIndex = 3;
            this.TradeOnButton.TabStop = true;
            this.TradeOnButton.Text = "On";
            this.TradeOnButton.UseVisualStyleBackColor = true;
            // 
            // ResumeButton
            // 
            this.ResumeButton.Location = new System.Drawing.Point(140, 15);
            this.ResumeButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.ResumeButton.Name = "ResumeButton";
            this.ResumeButton.Size = new System.Drawing.Size(115, 44);
            this.ResumeButton.TabIndex = 117;
            this.ResumeButton.Text = "RESUME";
            this.ResumeButton.UseVisualStyleBackColor = true;
            this.ResumeButton.Click += new System.EventHandler(this.ResumeButton_Click);
            // 
            // StopButton
            // 
            this.StopButton.Location = new System.Drawing.Point(265, 15);
            this.StopButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.StopButton.Name = "StopButton";
            this.StopButton.Size = new System.Drawing.Size(115, 44);
            this.StopButton.TabIndex = 116;
            this.StopButton.Text = "STOP";
            this.StopButton.UseVisualStyleBackColor = true;
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // RunButton
            // 
            this.RunButton.Location = new System.Drawing.Point(15, 15);
            this.RunButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.RunButton.Name = "RunButton";
            this.RunButton.Size = new System.Drawing.Size(115, 44);
            this.RunButton.TabIndex = 115;
            this.RunButton.Text = "RUN";
            this.RunButton.UseVisualStyleBackColor = true;
            this.RunButton.Click += new System.EventHandler(this.RunButton_Click);
            // 
            // BalanceButton
            // 
            this.BalanceButton.Location = new System.Drawing.Point(390, 15);
            this.BalanceButton.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BalanceButton.Name = "BalanceButton";
            this.BalanceButton.Size = new System.Drawing.Size(115, 44);
            this.BalanceButton.TabIndex = 120;
            this.BalanceButton.Text = "BALANCE";
            this.BalanceButton.UseVisualStyleBackColor = true;
            this.BalanceButton.Click += new System.EventHandler(this.BalanceButton_Click);
            // 
            // StockVoltyBreakMidCap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 416);
            this.Controls.Add(this.BalanceButton);
            this.Controls.Add(this.MarketOperationGroupBox);
            this.Controls.Add(this.ParamsGroupBox);
            this.Controls.Add(this.ResumeButton);
            this.Controls.Add(this.StopButton);
            this.Controls.Add(this.RunButton);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "StockVoltyBreakMidCap";
            this.Text = "StockVoltyBreakMidCap";
            this.Load += new System.EventHandler(this.StockVoltyBreakMidCap_Load);
            this.MarketOperationGroupBox.ResumeLayout(false);
            this.MarketOperationGroupBox.PerformLayout();
            this.ParamsGroupBox.ResumeLayout(false);
            this.ParamsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NotionalBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox MarketOperationGroupBox;
        private System.Windows.Forms.RadioButton Case3Button;
        private System.Windows.Forms.RadioButton Case2Button;
        private System.Windows.Forms.RadioButton Case1Button;
        private System.Windows.Forms.GroupBox ParamsGroupBox;
        private System.Windows.Forms.NumericUpDown NotionalBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton TradeOnButton;
        private System.Windows.Forms.Button ResumeButton;
        private System.Windows.Forms.Button StopButton;
        private System.Windows.Forms.Button RunButton;
        private System.Windows.Forms.Button BalanceButton;
        private System.Windows.Forms.CheckBox IndexConditionCheckBox;
        private System.Windows.Forms.RadioButton TradeOffButton;
        private System.Windows.Forms.CheckBox ShortCheckBox;
        private System.Windows.Forms.CheckBox LongCheckBox;
    }
}