﻿using System;
using System.IO;
using System.Collections.Generic;

namespace PnK_indi
{
    public delegate void EventDelegate(object sender, EventArgs e);

    public class Timer
    {
        private System.Timers.Timer timer;

        public Timer()
        {
            timer = new System.Timers.Timer();
        }

        public void Set(double interval)
        {
            timer.Interval = interval;
        }

        public double GetInterval() => timer.Interval;

        public void Start(EventDelegate eventDelegate)
        {
            timer.Elapsed += new System.Timers.ElapsedEventHandler(eventDelegate);
            timer.Start();
        }

        public void Finish()
        {
            timer.Close();
        }
    }


    public class Order
    {
        public string StandardCode { get; private set; }
        public string ShortCode { get; private set; }
        public AskBidType AskBidType { get; private set; }
        public long Price { get; private set; }
        public long Quantity { get; private set; }
        public OrderType OrderType { get; private set; }
        public OrderCondition OrderCondition { get; private set; }

        public Order(string standardCode, string shortCode, AskBidType askBidType, long price, long quantity, OrderType orderType, OrderCondition orderCondition)
        {
            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.AskBidType = askBidType;
            this.Price = price;
            this.Quantity = quantity;
            this.OrderType = orderType;
            this.OrderCondition = orderCondition;
        }
    }

    public class LiveOrder
    {
        public string StandardCode { get; private set; }
        public string ShortCode { get; private set; }
        public AskBidType AskBidType { get; private set; }
        public OrderType OrderType { get; private set; }
        public OrderCondition OrderCondition { get; private set; }
        public long Price { get; private set; }
        public long OrderQuantity { get; private set; }
        public long LiveQuantity { get; private set; }
        public long OrderId { get; private set; }
        public long OriginalOrderId { get; private set; }
        public long TOrderId { get; private set; }
        public long TOriginalOrderId { get; private set; }
        public string AccountNumber { get; private set; }
        public DateTime OrderTime { get; private set; }

        public LiveOrder(string standardCode, string shortCode, AskBidType askBidType,
            OrderType orderType, OrderCondition orderCondition, long price, long orderQuantity, long liveQuantity,
            long orderId, long originalOrderId, long tOrderId, long tOriginalOrderId, string accountNumber, DateTime orderTime)
        {
            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.AskBidType = askBidType;
            this.OrderType = orderType;
            this.OrderCondition = orderCondition;
            this.Price = price;
            this.OrderQuantity = orderQuantity;
            this.LiveQuantity = liveQuantity;
            this.OrderId = orderId;
            this.OriginalOrderId = originalOrderId;
            this.TOrderId = tOrderId;
            this.TOriginalOrderId = tOriginalOrderId;
            this.AccountNumber = accountNumber;
            this.OrderTime = orderTime;
        }

        public void UpdateLiveQuantity(long tradingQuantity)
        {
            this.LiveQuantity -= tradingQuantity;
        }
    }

    public class DerivOrder
    {
        public string StandardCode { get; private set; }
        public AskBidType AskBidType { get; private set; }
        public double Price { get; private set; }
        public long Quantity { get; private set; }
        public OrderType OrderType { get; private set; }
        public OrderCondition OrderCondition { get; private set; }

        public DerivOrder(string standardCode, AskBidType askBidType, double price, long quantity, OrderType orderType, OrderCondition orderCondition)
        {
            this.StandardCode = standardCode;
            this.AskBidType = askBidType;
            this.Price = price;
            this.Quantity = quantity;
            this.OrderType = orderType;
            this.OrderCondition = orderCondition;
        }
    }

    public class DerivLiveOrder
    {
        public string StandardCode { get; private set; }
        public string ShortCode { get; private set; }
        public AskBidType AskBidType { get; private set; }
        public OrderType OrderType { get; private set; }
        public OrderCondition OrderCondition { get; private set; }
        public double Price { get; private set; }
        public long OrderQuantity { get; private set; }
        public long LiveQuantity { get; private set; }
        public long OrderId { get; private set; }
        public long OriginalOrderId { get; private set; }
        public string AccountNumber { get; private set; }
        public DateTime OrderTime { get; private set; }

        public DerivLiveOrder(string standardCode, string shortCode, AskBidType askBidType,
            OrderType orderType, OrderCondition orderCondition, double price, long orderQuantity, long liveQuantity,
            long orderId, long originalOrderId, string accountNumber, DateTime orderTime)
        {
            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.AskBidType = askBidType;
            this.OrderType = orderType;
            this.OrderCondition = orderCondition;
            this.Price = price;
            this.OrderQuantity = orderQuantity;
            this.LiveQuantity = liveQuantity;
            this.OrderId = orderId;
            this.OriginalOrderId = originalOrderId;
            this.AccountNumber = accountNumber;
            this.OrderTime = orderTime;
        }

        public void UpdateLiveQuantity(long tradingQuantity)
        {
            this.LiveQuantity = this.LiveQuantity - tradingQuantity;
        }
    }

    public class TypeConverter
    {
        public string AsString(object o) => o.ToString();
        public int AsInt(object o) => Convert.ToInt32(Double.Parse(AsString(o)));
        public long AsLong(object o) => Convert.ToInt64(Double.Parse(AsString(o)));
        public double AsDouble(object o) => Double.Parse(AsString(o));

        public string AsString(char[] c) => string.Concat(c);
        public int AsInt(char[] c) => Convert.ToInt32(Double.Parse(AsString(c)));
        public long AsLong(char[] c) => Convert.ToInt64(Double.Parse(AsString(c)));
        public double AsDouble(char[] c) => Double.Parse(AsString(c));
    }

    public class PriceHelper
    {
        private SecurityGroupId SecurityGroupId = SecurityGroupId.ST;

        public PriceHelper(SecurityGroupId securityGroupId)
        {
            this.SecurityGroupId = securityGroupId;
        }

        public long GetTickSize(long price)
        {
            if (SecurityGroupId == SecurityGroupId.EF || SecurityGroupId == SecurityGroupId.EN)
                return 5;

            if (price < 2000)
                return 1;
            else if (price < 5000)
                return 5;
            else if (price < 20000)
                return 10;
            else if (price < 50000)
                return 50;
            else if (price < 200000)
                return 100;
            else if (price < 500000)
                return 500;
            else
                return 1000;
        }

        public long RoundPriceUp(long price)
        {
            var tickSize = GetTickSize(price);
            return (long)Math.Ceiling((double)price / tickSize) * tickSize;
        }

        public long RoundPriceDown(long price)
        {
            var tickSize = GetTickSize(price);
            return (long)Math.Floor((double)price / tickSize) * tickSize;
        }

        public long GetNextPriceAbove(long price)
        {
            if (RoundPriceUp(price) == price)
                return price + GetTickSize(price);
            else
                return RoundPriceUp(price);
        }

        public long GetNextPriceBelow(long price)
        {
            if (RoundPriceDown(price) == price)
                return price - GetTickSize(price - GetTickSize(price));
            else
                return RoundPriceDown(price);
        }

        public long GetNextPriceAboveTicks(long price, int tickAmount)
        {
            for (var i = 0; i < tickAmount; i++)
                price = GetNextPriceAbove(price);

            return price;
        }

        public long GetNextPriceBelowTicks(long price, int tickAmount)
        {
            for (var i = 0; i < tickAmount; i++)
                price = GetNextPriceBelow(price);

            return price;
        }
    }

    public class DerivPriceHelper
    {
        private string ShortCode;

        public DerivPriceHelper(string shortCode)
        {
            this.ShortCode = shortCode;
        }

        public double GetTickSize(double price)
        {
            if (ShortCode.StartsWith("101"))
                return 0.05;
            else if (ShortCode.StartsWith("106"))
                return 0.1;
            else
            {
                if (price < 2000)
                    return 1;
                else if (price < 5000)
                    return 5;
                else if (price < 20000)
                    return 10;
                else if (price < 50000)
                    return 50;
                else if (price < 200000)
                    return 100;
                else if (price < 500000)
                    return 500;
                else
                    return 1000;
            }
        }

        public double RoundPriceUp(double price)
        {
            var tickSize = GetTickSize(price);
            return Math.Ceiling(price / tickSize) * tickSize;
        }

        public double RoundPriceDown(double price)
        {
            var tickSize = GetTickSize(price);
            return Math.Floor(price / tickSize) * tickSize;
        }

        public double GetNextPriceAbove(double price)
        {
            if (DoubleEquals(RoundPriceUp(price), price))
                return price + GetTickSize(price);
            else
                return RoundPriceUp(price);
        }

        public double GetNextPriceBelow(double price)
        {
            if (DoubleEquals(RoundPriceDown(price), price))
                return price - GetTickSize(price - GetTickSize(price));
            else
                return RoundPriceDown(price);
        }

        public double GetNextPriceAboveTicks(double price, int tickAmount)
        {
            for (var i = 0; i < tickAmount; i++)
                price = GetNextPriceAbove(price);

            return price;
        }

        public double GetNextPriceBelowTicks(double price, int tickAmount)
        {
            for (var i = 0; i < tickAmount; i++)
                price = GetNextPriceBelow(price);

            return price;
        }

        private static bool DoubleEquals(double d1, double d2) => Math.Abs(d1 - d2) < Math.Pow(10, -8);
        private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
        private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);
    }

    public class LogWriter
    {

        private readonly MainWindow Main;
        //public string DirPath = "C:/Users/shic/Desktop/Logs";
        public string DirPath = "C:/Users/234046/Desktop/Logs";
        public string FilePath { get; set; }

        public LogWriter(MainWindow main)
        {
            this.Main = main;
            //SetUp();
        }

        public LogWriter(string dirPath, MainWindow main)
        {
            this.DirPath = dirPath;
            this.Main = main;
            //SetUp();
        }

        private void SetUp()
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(this.DirPath);
                if (!directoryInfo.Exists)
                    Directory.CreateDirectory(this.DirPath);

                this.FilePath = this.DirPath + "/logs_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log";
                FileInfo fileInfo = new FileInfo(this.FilePath);
                if (!fileInfo.Exists)
                    File.Create(this.FilePath);
            }
            catch
            {
                Console.WriteLine("some problem in logging");
            }
        }

        public void Write(string log)
        {
            var _log = $"[{DateTime.Now.ToString("HH:mm:ss.fff")}]   {log}";
            this.Main.LogQueue.Enqueue(_log);
        }
    }
    
    public struct Balance
    {
        public string FundCode { get; set; }
        public string StandardCode { get; set; }
        public string ShortCode { get; set; }
        public long NormalBalance { get; set; }
        public long BalanceAvailableToSell { get; set; }
        public long AverageBuyPrice { get; set; }
    }

    public enum MarketType
    {
        Kospi = 'K',
        Kosdaq = 'Q',

        KospiFuture = 'K',
        KosdaqFuture = 'Q',
        KRX300Future = '3',
        KospiOption = 'O',
        KosdaqOption = 'o',

        VKospiFuture = 'V',
        SectorFuture = 'S',

        CommodityFuture = 'C',
        CommodityOption = 'C',

        StockFuture = 'S',
        StockOption = 'S'
    }

    public enum DerivProductType
    {
        KospiFuture = '1',
        KospiOption = '2',

        KosdaqFuture = '3',
        KosdaqOption = '4',

        StockFuture = '5',
        StockOption = '6'
    }

    public enum AskBidType
    {
        Ask = '1',
        Bid = '2',
        Determine = '0',
    }

    public enum PriceAdjustment
    {
        Normal = 0,
        ExRights = 1,
        ExDividend = 2,
        ExDistribution = 3,
        ExRightsAndDividend = 4,
        ExMidDividend = 5,
        ExRightsAndMidDividend = 6,
        Others = 99,
    }

    public enum SecurityGroupId
    {
        ST,     // 주식
        MF,     // 증권투자회사
        RT,     // 리츠
        SC,     // 선박투자회사
        IF,     // 인프라투융자회사
        DR,     // 예탁증서
        SW,     // 신주인수권증권
        SR,     // 신주인수권증서
        BW,     // 주식워런트증권(ELW)
        FU,     // 선물
        OP,     // 옵션
        EF,     // 상장지수펀드(ETF)
        BC,     // 수익증권
        FE,     // 해외ETF
        FS,     // 해외원주
        EN      // ETN
    }

    public enum OrderType
    {
        Market = '1',
        Limit = '2',
        ConditionalLimit = 'I',         // 조건부지정가
        BestOppositeSide = 'X',         // 최유리지정가
        BestSameSide = 'Y',             // 최우선지정가
    }

    public enum OrderCondition
    {
        Normal = '0',
        IOC = '3',
        FOK = '4',
    }

    public enum RealTimeDataType
    {
        Execution,
        Quote,
    }

    public struct StockOrderStruct
    {
        public string StandardCode;
        public OrderStructType OrderStructType;
        public Order Order;
        public LiveOrder LiveOrder;
        public long AmendedPrice;
    }

    public struct DerivOrderStruct
    {
        public string StandardCode;
        public OrderStructType OrderStructType;
        public DerivOrder Order;
        public DerivLiveOrder LiveOrder;
    }

    public enum OrderStructType
    {
        New,
        Amend,
        Cancel
    }

    public static class WM
    {
        private const int WM_USER = 0x0400;
        public const int WM_RECEIVED_DATA = WM_USER + 5;                    // 조회 TR 수신
        public const int WM_RECEIVED_ORDER_ORDER = WM_USER + 6;             // 
        public const int WM_RECEIVED_ORDER_ACK = WM_USER + 7;               // 주문 ACK 수신
        public const int WM_RECEIVED_ORDER_REJECT = WM_USER + 8;            // 주문 거부 수신
        public const int WM_RECEIVED_ORDER_CHEGYUL = WM_USER + 10;          // 주문 체결 수신
        public const int WM_RECEIVED_ORDER_CONFIRFM = WM_USER + 11;         // 주문 확인 수신
        public const int WM_COPY_DATA = 0x004A;                             // 시세 수신
    }

    public static class LENGTH
    {
        public const int USER_ID_LEN = 6;                       // 접속아이디
        public const int ACCOUNT_NO_LEN = 12;                   // 계좌번호
        public const int ACCOUNT_NAME_LEN = 40;                 // 계좌명
        public const int FUND_NO_LEN = 4;                       // 펀드번호
        public const int FUND_NAME_LEN = 40;                    // 편드명
        public const int EMP_NO_LEN = 6;                        // 사원번호
        public const int EMP_NAME_LEN = 40;                     // 사원명
        public const int TEAM_CODE_LEN = 3;                     // 팀코드
        public const int DEPT_CODE_LEN = 3;                     // 부서코드
        public const int MKT_CLS_LEN = 1;                       // 시장구분

        public const int STANDARD_CODE_LEN = 12;                // 표준코드
        public const int SHORT_CODE_LEN = 8;                    // 단축코드
        public const int ITEM_NAME_LEN = 40;                    // 종목명
    }

    public static class Rejects
    {
        public static Dictionary<string, string> TopsMessage;
        public static Dictionary<string, string> KrxMessage;
        public static Dictionary<string, string> InternalMessage;

        static Rejects()
        {
            TopsMessage = new Dictionary<string, string>()
            {
                {"9001", "종목코드 오류" },
                {"9002", "주식잔고가 부족하여 주문이 전송되지 않았습니다"},
                {"9003", "주문 packet 오류" },
                {"9004", "DB 프로시저/펑션(종목코드체크) 호출오류" },
                {"9005", "선물/옵션 미 접수주문 정정/취소거부" },
                {"9006", "영업일 오류" },
                {"9007", "주문가능시간이 아닙니다" },
                {"9008", "FEP Packet 구성 오류가 발생했습니다" },
                {"9009", "펀드코드가 없습니다" },
                {"9010", "주문 불가능한 사번" },
                {"9011", "정정/취소거부(수량부족 또는 중복정정/취소)" },
                {"9012", "주문한도 초과입니다" },
                {"9013", "손실률 초과입니다" },
                {"9014", "한도기초과 상태입니다"},
                {"9015", "정정/취소 시 원주문 번호가 없습니다" },
                {"9016", "선물 포지션한도를 초과하였습니다" },
                {"9017", "옵션 포지션한도를 초과하였습니다" },
                {"9018", "일간 손실한도를 초과하였습니다" },
                {"9019", "월간 손실한도를 초과하였습니다" },
                {"9020", "선물 주문을 할 수 없는 사용자입니다" },
                {"9021", "옵션 주문을 할 수 없는 사용자입니다" },
                {"9022", "SQL 에러입니다" },
                {"9023", "선물 포지션 한도 미등록" },
                {"9024", "옵션 포지션 한도 미등록" },
                {"9025", "손실한도 미등록" },
                {"9026", "자기매매자 접속 불가 주문서버입니다" },
                {"9027", "위탁자 접속불가 주문서버입니다" },
                {"9028", "매매금지종목입니다" },
                {"9029", "주문수량 오류" },
                {"9030", "신규증거금이 부족합니다" },
                {"9031", "정정증거금이 부족합니다" },
                {"9032", "주문가격오류" },
                {"9033", "매도주문 불가능 계좌입니다" },
                {"9034", "매수주문 불가능 계좌입니다" },
                {"9035", "증거금 오류" },
                {"9036", "주문잔고 Update 에러" },
                {"9037", "체결잔고 Update 에러" },
                {"9038", "인증절차를 확인해 주세요" },
                {"9039", "SHM 오류" },
                {"9040", "1회주문 한도초과입니다" },
                {"9041", "호가조건코드 에러입니다" },
                {"9042", "주문금지계좌입니다" },
                {"9043", "회원사항목 계좌번호오류입니다" },
                {"9044", "선물 미체결수량 한도 초과입니다" },
                {"9045", "선물 미체결금액 한도 초과입니다" },
                {"9046", "옵션 미체결수량 한도 초과입니다" },
                {"9047", "옵션 미체결금액 한도 초과입니다" },
                {"9048", "선물 포지션금액 한도 초과입니다" },
                {"9049", "선물 포지션금액 한도 초과입니다" },
                {"9050", "SHM 오류 (NOT FOUND)" },
                {"9051", "SHM 생성중입니다" },
                {"9052", "최대 주문번호를 초과하였습니다" },
                {"9053", "선물 1회한도 초과입니다" },
                {"9054", "콜옵션 1회한도 초과입니다" },
                {"9055", "풋옵션 1회한도 초과입니다" },
                {"9056", "거래제한 월물입니다" },
                {"9057", "호가 적합성 오류" },
                {"9058", "종목코드 이상" },
                {"9059", "매매 금지/중지 종목" },
                {"9060", "해당 호가유형/조건 주문불가" },
                {"9061", "CB 발동 중" },
                {"9062", "자동청산된 사용자입니다. 청산주문만 가능합니다" },
                {"9063", "매매수량단위 오류" },
                {"9064", "상장주식 수 기준 수량 제한" },
                {"9065", "호가 가격단위 오류" },
                {"9066", "가격 제한 폭 이탈" },
                {"9067", "시가 기준가종목 가격제한" },
                {"9068", "최종거래일 마감, 취소주문 불가" },
                {"9069", "시장구분 Error"},
                {"9070", "주식선물 미결제한도계약수 초과입니다" },
                {"9071", "호가 한도수량 초과입니다" },
                {"9072", "호가유형코드 에러입니다" },
                {"9073", "프로그램매매 구분코드 에러입니다" },
                {"9074", "시장조성계좌 해당 호가유형/조건 주문불가" },
                {"9075", "주문번호체번이상" },
                {"9101", "장 개시전 정정, 취소 주문가능시간 아님" },
                {"9110", "대차구분 에러" },
                {"9111", "순포지션 확인, 차입매도 불가" },
                {"9112", "순포지션 확인, 일반매도 먼저" },
                {"9115", "순포지션 확인, 일반매도 불가" },
                {"9116", "순포지션 확인, 일반매도 불가2" },
                {"9117", "순포지션 확인, 순포지션 범위 내 일반매도 가능함" },
                {"9119", "매매구분 에러" },
                {"9120", "대차구분 에러" },
                {"9121", "차입매도수량보다 차입매수수량이 많습니다" },
                {"9122", "순포지션 확인, 차입매수 불가" },
                {"9123", "순포지션 확인, 차입매수 불가(2)" },
                {"9124", "순포지션 확인, 순포지션 범위 내 차입매수 가능함" },
                {"9125", "순포지션 확인, 일반매수 불가" },
                {"9216", "차입매도 수량 확인, 상환매수 먼저" },
                {"9127", "CD Limit 가격을 초과해서 주문 전송하지 않음" },
                {"9128", "CD 주문가격이 0이므로 주문 전송하지 않음" },
                {"9129", "차입매도 주문 가능 수량이 부족합니다" },
                {"9130", "차입매수 주문 가능 수량이 부족합니다" },
                {"9500", "현물 선물 미결제약정 한도 제어 중입니다" },
                {"9700", "FEP File System 장애" },
                {"9701", "대외기관 전송시간 초과" },
                {"9996", "FEP 접수 거부, 주문패킷 확인 요망" },
                {"9997", "chedb와 접속되지 않은 상태입니다. 잠시만 기다려 주십시오" },
                {"9998", "feporder와 접속되지 않은 상태입니다. 잠시만 기다려 주십시오" },
                {"9999", "FEP와 접속되지 않은 상태입니다. 잠시만 기다려 주십시오" }
            };

            KrxMessage = new Dictionary<string, string>()
            {
                {"0101", "호가접수 개시 전" },
                {"0102", "매매거래시간 종료 후" },
                {"0103", "호가접수정지중" },
                {"0104", "종목 호가접수정지중" },
                {"0105", "호가가격 Format 오류" },
                {"0106", "시장조성자호가구분번호 Format 오류" },
                {"0107", "협상번호 Format 오류" },
                {"0108", "협상상세번호 Format 오류" },
                {"0109", "호가수량 Format 오류" },
                {"0110", "주문수신 회선 오류" },
                {"0111", "정규/시간외시장 종료후 취소호가" },
                {"0112", "주문ID Format 오류" },
                {"0113", "현물가격 Format 오류" },
                {"0114", "호가수익률 Format 오류" },

                {"0201", "종목코드 오류" },
                {"0202", "매도매수구분 오류" },
                {"0203", "계좌번호 오류" },
                {"0204", "일자 오류" },
                {"0205", "주문매체구분코드 오류" },
                {"0206", "주문ID 오류" },
                {"0207", "주문ID 중복" },
                {"0208", "정규시간외구분 오류" },
                {"0209", "트랜잭션코드(TR CODE) 오류" },
                {"0211", "위탁사번호 오류" },
                {"0212", "대용주권계좌번호 오류" },
                {"0213", "주문 재송신에 의 한 주문ID 중복" },

                {"0301", "정상호가 범위 위반" },
                {"0302", "호가가격 오류" },
                {"0303", "호가가격단위 오류" },
                {"0304", "현물가격 오류" },
                {"0305", "현물가격단위 오류" },
                {"0306", "실시간가격제한 범위 위반" },

                {"0401", "호가 제한수량 초과" },
                {"0402", "호가수량 오류" },

                {"0501", "거래정지 종목" },
                {"0502", "시장임시정지중" },
                {"0503", "최종거래일 종목마감" },
                {"0504", "예상체결가관련 단일가마감 1분전 호가 정정,취소 불가" },
                {"0505", "CB발동중" },
                {"0506", "선물스프레드종목 주문불가 시점" },
                {"0507", "종가개시후 조건부지정가 입력불가" },
                {"0508", "기준가 미산출종목 호가입력 불가" },
                {"0509", "기초자산소속시장거래정지중" },
                {"0510", "조기종료(상환)발생 매매거래정지 종목" },
                {"0512", "휴장일에 따른 호가접수 중지" },
                {"0513", "Shutdown 중" },

                {"0601", "위탁자기 구분 오류" },
                {"0602", "국가코드 구분오류" },
                {"0603", "투자자구분코드 오류" },
                {"0604", "외국인투자자구분코드 오류" },
                {"0605", "Reg.S 미국국적 개인투자자 매수호가불가" },

                {"0701", "호가유형 오류" },
                {"0702", "호가조건 오류" },
                {"0703", "종가미실시종목 조건부지정가 입력불가" },
                {"0704", "상하한가격 호가유형 오류" },
                {"0705", "단일가연장중 호가유형 오류" },
                {"0706", "단일가연장중 호가조건 오류" },
                {"0707", "실시간가격제한해제중 호가유형 오류" },

                {"0801", "정정취소구분 오류" },
                {"0802", "원주문ID 누락" },
                {"0803", "원호가 없음" },
                {"0804", "정정취소잔량 없음" },
                {"0805", "정정취소잔량 초과" },
                {"0806", "취소호가에 대한 정정, 취소" },
                {"0807", "거부호가에 대한 정정, 취소" },
                {"0808", "동일가격 정정불가" },
                {"0809", "특정 호가유형간 정정불가" },
                {"0810", "원주문ID 오류" },
                {"0811", "취소후 잔량 최소요건 위반" },
                {"0812", "정정취소 매도수구분 불일치" },
                {"0813", "정정취소 위탁상품 불일치" },
                {"0814", "정정취소 공매도구분 불일치" },

                {"0901", "회원번호 오류" },
                {"0902", "해당 종목 거래불가 회워/계좌" },
                {"0907", "포지션한도 초과" },
                {"0908", "회원의 해당종목 매매 제한중" },
                {"0911", "회원 매매거래 제한중" },

                {"1001", "지점번호 오류" },
                {"1006", "지점의 해당종목 매매 제한중" },
                {"1007", "지점 매매거래 제한중" },

                {"1101", "LP/MM호가구분번호 오류" },
                {"1102", "LP/MM 대상종목 아님" },
                {"1103", "해당 종목의 LP/MM 회원 아님" },
                {"1104", "LP/MM호가 호가유형 오류" },
                {"1105", "LP/MM호가 호가조건오류" },
                {"1106", "LP/MM호가 위탁자기구분 오류" },
                {"1107", "LP호가 최소호가수량 위반" },
                {"1108", "LP호가 정상호가 범위 위반" },
                {"1109", "MM호가 단일가 주문시간 입력불가" },
                {"1110", "상장주식수 초과" },
                {"1111", "LP 보유수량 초과" },
                {"1112", "LP 상대호가 없음" },
                {"1113", "LP호가 상대최우선 호가수량 이상" },
                {"1114", "LP호가 상대최우선 LP호가 기제출" },
                {"1115", "LP호가 허용 방향 오류" },
                {"1116", "MM호가 신탁계좌 불가" },

                {"1201", "대량매매구분 오류" },
                {"1202", "대량매매 호가 중복" },
                {"1204", "협상서 없음" },
                {"1205", "대랑매매 불가 종목" },
                {"1206", "대량매매 불가 시점" },
                {"1207", "대량매매 호가수량 오류" },
                {"1208", "거래미형성으로 대량매매 불가" },
                {"1209", "협의대량거래 상대회원번호 입력 오류" },
                {"1210", "협의대량거래 상대계좌번호 입력 오류" },
                {"1211", "협의대랑거래 협의완료시각 입력 오류" },
                {"1212", "협의대랑거래 협의완료시각 초과" },
                {"1214", "대량매매 체결가격범위 위반" },
                {"1215", "협의대량거래 불가능 계좌" },
                {"1216", "대량매매 일부취소 불가" },
                {"1217", "대랑거래 협상번호 입력오류" },
                {"1218", "대량거래 협의상세번호 입력오류" },
                {"1219", "대량거래 협상자ID 입력오류" },
                {"1220", "바스켓 구성종목중 일부종목 거래정지중" },
                {"1221", "대량거래 체결 완료" },
                {"1222", "정상협상에 대한 취소" },
                {"1223", "대량매매호가 협상무효" },
                {"1225", "협상서 불일치 매도매수구분코드 오류" },
                {"1226", "협상서 불일치 정규시간외구분코드 오류" },
                {"1227", "협상서 불일치 대량매매구분코드 오류" },
                {"1228", "협상서 불일치 회원번호 오류" },
                {"1229", "협상서 불일치 호가수량 오류" },
                {"1230", "협상서 불일치 호가일자 오류" },
                {"1231", "협상서 불일치 종목코드 오류" },
                {"1232", "EFP 현물가격 가격범위 위반" },
                {"1233", "EFP 미결제약정수량 초과" },
                {"1234", "EFP 거래 불가 종목" },
                {"1235", "FLEX거래 불가 종목" },
                {"1236", "협의거래 거래리포트ID 오류" },
                {"1237", "협의거래 EUREX청산결제계좌 오류" },
                {"1238", "협의거래 불일치 종목코드 오류" },
                {"1239", "협의거래 불일치 회원번호 오류" },
                {"1240", "협의거래 불일치 계좌비밀번호 오류" },
                {"1241", "협의거래 호가제한수량 초과" },
                {"1243", "협의거래 수탁거부신고 불가시점" },
                {"1244", "협의거래 수탁거부신고및취소 수량없음" },
                {"1245", "협의거래 호가제한수량 미만" },
                {"1246", "협상서 불일치 자사주신고서ID 오류" },
                {"1247", "협상서 불일치 자사주매매방법코드 오류" },
                {"1248", "협상서 불일치 협상자ID 오류" },
                {"1249", "협상서 불일치 호가가격 오류" },
                {"1250", "협상서 불일치 매도유형코드 오류" },
                {"1251", "장중 경쟁대량매매 불가 시점" },
                {"1252", "시간외 경쟁대량매매 불가 시점" },
                {"1253", "경쟁대량매매 불가종목" },

                {"1301", "계좌구분코드 오류" },
                {"1302", "계좌증거금유형 오류" },
                {"1303", "사후위탁증거금 적용계좌의 미등록" },
                {"1304", "시장조성 적용계좌의 미등록" },

                {"1401", "시간외매매 불가 종목" },
                {"1402", "장개시전 시간외매매 불가 종목" },
                {"1403", "시간외종가매매 정정 불가" },
                {"1404", "임의종료 적용중 시간외매매 불가" },
                {"1405", "거래미형성으로 시간외매매 불가(또는 종가단일가 임의종료 발동 중)" },
                {"1406", "시간외 매매 정상호가 범위 위반" },
                {"1407", "BUY-IN 매매 불가종목" },
                {"1408", "일반 BUY-IN 호가접수 불가 시점" },
                {"1409", "당일 BUY-IN 호가접수 불가 시점" },

                {"1501", "신용구분 오류" },
                {"1502", "신용주문 불가종목" },

                {"1601", "자사주신고서 ID 오류" },
                {"1602", "자사주 매매방법 구분 오류" },
                {"1603", "자사주 매도매수구분 오류" },
                {"1604", "자사주 호가수량 오류" },
                {"1605", "자사주 호가가격 오류" },
                {"1606", "자사주 호가제한 수량 초과" },
                {"1607", "자사주 호가유형 오류" },
                {"1608", "자사주 호가조건 오류" },
                {"1609", "자사주 호가 회원사 오류" },
                {"1610", "자사주 일반호가 불가 시점" },
                {"1611", "자사주 정정 불가 시점" },
                {"1612", "자사주 호가취소 불가" },
                {"1613", "자사주 불가 종목" },
                {"1614", "자사주호가 LP/MM호가구분번호 오류" },
                {"1615", "자사주호가 매도유형코드 오류" },
                {"1616", "자사주호가 투자자구분코드 오류" },

                {"1701", "프로그램매매 구분 오류" },
                {"1702", "프로그램매매 종목 오류" },

                {"1801", "매도유형코드 오류" },
                {"1802", "공매도 호가가격 오류" },
                {"1803", "공매도 호가유형 오류" },
                {"1804", "공매도 호가조건 오류" },
                {"1805", "공매도 호가입력제한" },
                {"1806", "차입증권 공매도 불가종목" },

                {"1901", "프로그램호가 신고구분코드 오류" },
                {"1902", "종가단일가시 신고구분코드 오류" },
                {"1903", "불균형 미발생시 사후신고 불가" },
                {"1904", "매수호가 기준가 초과 오류" },
                {"1905", "매수호가 현재가 초과 오류" },
                {"1906", "매도 불균형시 매도호가 입력 불가" },
                {"1907", "매도호가 기준가 미만 오류" },
                {"1908", "매도호가 현재가 미만 오류" },
                {"1909", "매수 불균형시 매수호가 입력 불가" },
                {"1912", "사후신고시 시장가호가 불가" },

                {"2001", "경매매호가 접수불가시점" },
                {"2002", "경매매 매도호가 정정불가" },
                {"2003", "경매매 불가종목" },
                {"2004", "시가기준가종목 경매매 불가" },
                {"2005", "경매매신청서에 대한 종목 불일치" },
                {"2006", "경매매 신청서에 대한 회원번호 불일치" },
                {"2007", "경매매 신청서에 대한 신청수량 불일치" },
                {"2008", "경매매 신청서에 대한 가격 불일치" },
                {"2009", "경매매 미신청 종목에 대한 매수호가 불가" },
                {"2010", "경매매 최저입찰가격 미만 매수호가 불가" },
                {"2011", "경매매 매도잔량 존재시 매도호가 추가제출 불가" },

                {"4001", "복합호가 미적용 상품/종목" },
                {"4002", "복합호가 구성종목별 기초자산 상이" },
                {"4003", "복합호가 구성종목별 거래상수 상이" },
                {"4004", "복합호가 선물스프레드종목과 동일" },
                {"4005", "복합호가 국채선물간 기초자산 동일" },
                {"4006", "복합호가 주문불가시점(단일가 중)" },
                {"4007", "복합호가 구성종목수 미달" },
                {"4008", "복합호가 정정취소 불가" },
                {"4009", "복합호가 구성종목 중복" },
                {"4010", "복합호가 제재대상 구성종목 포함" },
                {"4011", "복합호가 전종목 체결불가" },
                {"4101", "Kill Switch 발동계좌 호가거부" },

                {"9998", "개별종목장애" },
            };

            InternalMessage = new Dictionary<string, string>()
            {
                {"A1875", "원주문내역을 찾을 수 없습니다!" },
                {"A0845", "매도수량이 매도가능수량을 초과합니다" },
                {"C0944", "60일평균 80%초과수량 매수불가" },
                {"A1878", "원주문이 거부되었습니다" },
                {"A2733", "주문잔량이 없습니다" },
                {"A1877", "원주문번호를 확인하시기 바랍니다" },
                {"A6831", "해당주문 접수시간이 아닙니다" },
                {"C2544", "거래제한종목 매매불가입니다" },
                {"C0942", "리서치 추천종목으로 매매 불가합니다" },
                {"C2382", "순포지션 확인, 차입매도 불가" },
            };
        }
    }
    public struct AlgoInfo
    {
        // 알고리즘계좌 정보
        public string AlgoStrategyTypeCode { get; set; }
        public string TraderId { get; set; }
        public string OrderGroupNumber { get; set; }
        public string SmpCode { get; set; }
    }
}
