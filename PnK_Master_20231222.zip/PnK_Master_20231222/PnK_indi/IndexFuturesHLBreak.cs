﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using AxGIExpertControl64Lib;
//using TicTacTec.TA.Library;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PnK_indi
{
    public partial class IndexFuturesHLBreak : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SaveState> SaveStates = new Dictionary<string, SaveState>();
        private Dictionary<string, FuturesSubState> FuturesSubStates = new Dictionary<string, FuturesSubState>();

        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KospiChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_KosdaqChartCtrl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_IndexfuturesChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();


        private List<string> PairUniverseList = new List<string>() { };


        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;


        /// <summary>
        ///  tuple 변수로 상태 bool과 시간을 저장
        /// </summary>
        private (bool Status, DateTime Time) Calculate_Rsi_signal_tuple;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) CloseSameHogaTime;
        private (bool Status, DateTime Time) EntryOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;

        private bool IsMessageReceived_IndexfuturesChart = false;

        private bool SetCandleBarBefore_Flag = false;
        private bool SetSpreadStart_Flag = false;

        private new bool Enabled;

        public Thread SetCandleBarBef { get; private set; }
        public Thread Calculate_Rsi_Thread { get; private set; }

        public double sfutures_multiple = 10;


        private bool working_flag = true;

        public DateTime short_entry_const;

        private (bool Status, DateTime Time) SetCandleStandard;

        private bool first_setcandle_flag = false;

        public string start_time;



        // 형식에 맞게 파일 이름을 생성합니다.
        string filePath_log = "C:/Users/234046/Desktop/Logs/IndexFuturesHLBreak/" + DateTime.Now.ToString("yyyy-MM-dd") + "_output.log";

        public IndexFuturesHLBreak(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();
        }


        private void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 45, 0);

                start_time = "0900";
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 45, 0);

                start_time = "1000";
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 45, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 45, 0);

                start_time = "1000";
            }

            Calculate_Rsi_signal_tuple = (false, MarketOpeningTime.AddMinutes(5));

            //OpeningPriceOrdered = (false, MarketOpeningTime.AddSeconds(-60));
            MarketOpened = (false, MarketOpeningTime);

            CloseSameHogaTime = (false, MarketClosingTime.AddMinutes(-10));
            ClosingPriceOrdered = (false, MarketClosingTime.AddMinutes(-11));

            OnClose = (false, MarketClosingTime.AddMinutes(10));

            short_entry_const = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
        }

        /// <summary>
        /// 선언한 인디객체에 이벤트 함수를 연결 
        /// </summary>
        private void InitializeIndiControls()
        {

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);


            indi_KospiChartCtrl.CreateControl();
            indi_KospiChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKospiChartData);

            indi_KosdaqChartCtrl.CreateControl();
            indi_KosdaqChartCtrl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveKosdaqChartData);

            indi_IndexfuturesChartControl.CreateControl();
            indi_IndexfuturesChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_IndexfuturesChartControl_ReceiveData);

        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }

        private void Indi_IndexfuturesChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_IndexfuturesChart = true;
        }

        private void Indi_ReceiveKospiChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kospiNear == null)
                return;

            var shortCode = kospiNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KospiChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KospiChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KospiChartCtrl.GetMultiData(i, 5));

                //HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            //isReadyForKospiFutures = true;
        }

        private void Indi_ReceiveKosdaqChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear == null)
                return;

            var shortCode = kosdaqNear.ShortCode;

            var todayDay = DateTime.Today.Day;

            int nCnt = C.AsInt(indi_KosdaqChartCtrl.GetMultiRowCount());

            for (short i = 0; i < nCnt; i++)
            {
                var thisDay = C.AsInt(C.AsString(indi_KosdaqChartCtrl.GetMultiData(i, 0)).Substring(6, 2));

                if (thisDay == todayDay) { continue; }

                var high = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 3));
                var low = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 4));
                var close = C.AsDouble(indi_KosdaqChartCtrl.GetMultiData(i, 5));

                //HistoricalDatas[shortCode].Update(high, low, close);

                break;
            }

            //isReadyForKosdaqFutures = true;
        }


        public bool IsEnabled() => this.Enabled;

        public void OnConfirm(DerivState state)
        {
        }

        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution)
            {   //SubStates 의 State에 StockState state가 어떻게 업데이트되는지 이해가 잘안감

            }
        }

        public void UpdateQuotes(RealTimeDataType dataType, DerivState futuresState)
        {
            //if(dataType == RealTimeDataType.Execution)
            // {
            //     Console.WriteLine("futuresState");
            // }

        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("RunButton_Click");
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;

            InitFuturesStates();
            InitStates();


            Enable();
            Console.WriteLine("ManageTimer before");

            SetCandleStandard = (true, DateTime.Now);
            ManageTimer.Set(2 * 1000);
            ManageTimer.Start(OnTimer);
        }


        private void InitFuturesStates()
        {


            //var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            //if (kospiNear != null)
            //{
            //    Main.RequestG701F(kospiNear.ShortCode);
            //    Main.RequestB601F(kospiNear.ShortCode);


            //    var futuresShortCode = kospiNear.ShortCode;

            //    FuturesSubStates[futuresShortCode] = new FuturesSubState(kospiNear, kospiNear.StandardCode, kospiNear.ShortCode, kospiNear.Name);
            //    FuturesSubStates[futuresShortCode].Easyname = "KOSPI";

            //}

            var kosdaqNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("106") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();
            if (kosdaqNear != null)
            {
                Main.RequestG702F(kosdaqNear.ShortCode);
                Main.RequestB602F(kosdaqNear.ShortCode);

                var futuresShortCode = kosdaqNear.ShortCode;

                FuturesSubStates[futuresShortCode] = new FuturesSubState(kosdaqNear, kosdaqNear.StandardCode, kosdaqNear.ShortCode, kosdaqNear.Name , _StrategyParams);
                FuturesSubStates[futuresShortCode].Easyname = "KOSDAQ";
            }


        }
        /// <summary>
        /// spread state 객체 생성
        /// </summary>
        private void InitStates()
        {
            string filePath_states = $@"C:\Users\234046\Desktop\States\IndexFuturePairIntraBreak\States.dat";
            if (File.Exists(filePath_states))
            {
                Console.WriteLine("State 데이터가 존재 합니다");
                using (FileStream fileStream = new FileStream(filePath_states, FileMode.Open))
                {
                    if (fileStream.Length > 0) // 데이터가 있는지 확인
                    {
                        BinaryFormatter binaryFormatter = new BinaryFormatter();
                        SaveStates = (Dictionary<string, SaveState>)binaryFormatter.Deserialize(fileStream);

                        foreach (string keys in SaveStates.Keys)
                        {

                            SaveStates[keys].Params = _StrategyParams;

                        }

                    }
                    else
                    {
                        Console.WriteLine("SaveState 데이터가 존재 하지만, 데이터가 비어있습니다");

                    }
                }
            }
            else
            {
                Console.WriteLine("SaveState 데이터가 존재 하지 않습니다");
                foreach (string ticker in FuturesSubStates.Keys)
                {
                    SaveStates[ticker] = new SaveState(_StrategyParams);

                }
            }

        }




        /// <summary>
        /// 장시작전 전일 까지의 종가데이터를 불러와 객체에 저장하는 함수
        /// </summary>
        private void SetCandleBarBefore()
        {

            foreach (var fderivState in FuturesSubStates.Values)
            {

                var shortcode = fderivState.DerivState.ShortCode;
                indi_IndexfuturesChartControl.SetQueryName("TR_FNCHART");
                indi_IndexfuturesChartControl.SetSingleData(0, shortcode.Substring(0, 5));
                indi_IndexfuturesChartControl.SetSingleData(1, "1");
                indi_IndexfuturesChartControl.SetSingleData(2, "15");
                indi_IndexfuturesChartControl.SetSingleData(3, "00000000");
                indi_IndexfuturesChartControl.SetSingleData(4, "99999999");
                indi_IndexfuturesChartControl.SetSingleData(5, "201");

                indi_IndexfuturesChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_IndexfuturesChart)
                        break;
                }

                this.IsMessageReceived_IndexfuturesChart = false;
                var nCount = indi_IndexfuturesChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }

                string today = DateTime.Now.ToString("yyyyMMdd");


                fderivState.PriceSetClose = new List<double>();
                fderivState.PriceSetHigh = new List<double>();
                fderivState.PriceSetLow = new List<double>();
                fderivState.DatetimeSet = new List<string>();

                for (short i = 0; i < nCount; i++)
                {
                    if (i == 0)
                    {   //첫봉은 pass
                        continue;
                    }
                           
                    var _datetime = indi_IndexfuturesChartControl.GetMultiData(i, 0).ToString().Trim();
                    var _time = indi_IndexfuturesChartControl.GetMultiData(i, 1).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}_{_time}";

                    var open = C.AsDouble(indi_IndexfuturesChartControl.GetMultiData(i, 2));
                    var high = C.AsDouble(indi_IndexfuturesChartControl.GetMultiData(i, 3));
                    var low = C.AsDouble(indi_IndexfuturesChartControl.GetMultiData(i, 4));
                    var close = C.AsDouble(indi_IndexfuturesChartControl.GetMultiData(i, 5));


                    fderivState.PriceSetClose.Add(close);
                    fderivState.DatetimeSet.Add(strDate);

                    fderivState.PriceSetHigh.Add(high);
                    fderivState.PriceSetLow.Add(low);

                    if (today == _datetime & _time == start_time)
                    {
                        fderivState.today_open = open;

                    }
                }

                fderivState.channel_high_entry = fderivState.PriceSetHigh.Take(20).Max();
                fderivState.channel_high_exit = fderivState.PriceSetHigh.Take(10).Max();

                fderivState.channel_low_entry = fderivState.PriceSetHigh.Take(20).Min();
                fderivState.channel_low_exit = fderivState.PriceSetHigh.Take(10).Min();

                fderivState.ma_price_long = fderivState.PriceSetHigh.Take(200).Min();
                fderivState.ma_price_short = fderivState.PriceSetHigh.Take(40).Min();

                Console.WriteLine($"SetCandleBarBefore :{DateTime.Now} {shortcode}, {fderivState.Easyname}, {fderivState.DerivState.Name}");
                Console.WriteLine($"현재 기준 직전 15분봉 종가 {fderivState.PriceSetClose.First()}");
                Console.WriteLine($"today_open 가격 {fderivState.today_open}");
                Console.WriteLine($"channel_high_entry: {fderivState.channel_high_entry},channel_low_entry: {fderivState.channel_low_entry}");
                Console.WriteLine($"channel_high_exit: {fderivState.channel_high_exit},channel_low_exit: {fderivState.channel_low_exit}");
                Console.WriteLine($"ma_price_long: {fderivState.ma_price_long},ma_price_short: {fderivState.ma_price_short}");

                Console.WriteLine("");


            }

            first_setcandle_flag = true;


        }


        private void OnTimer(object sender, EventArgs e)
        {   
            //candle 세팅을 하지 않은경우 (처음 시작)
            if (!first_setcandle_flag)
            {
                SetCandleBarBef = new Thread(() => SetCandleBarBefore());
                SetCandleBarBef.Start();
            }
            else if ((DateTime.Now - this.MarketOpeningTime).Minutes >= 1)
            {
                if (DateTime.Now.Minute == 1 || DateTime.Now.Minute == 16 || DateTime.Now.Minute == 31 || DateTime.Now.Minute == 46)
                //if (true)
                {
                    if (!SetCandleStandard.Status)
                    {
                        if((DateTime.Now- SetCandleStandard.Time).Minutes>1)
                        {
                            SetCandleStandard.Status = true;
                        }
                    }

                    if (SetCandleStandard.Status)
                    {
                        SetCandleStandard.Time = DateTime.Now;
                        SetCandleStandard.Status = false;

                        SetCandleBarBef = new Thread(() => SetCandleBarBefore());
                        SetCandleBarBef.Start();
                        Console.WriteLine("SetCandleBarBef start ");
                    }


                }



            }
            if (working_flag & first_setcandle_flag)
            {
                Calculate_signal();
                signal_entry_check_and_order();
                signal_exit_check_and_order();
            }

        }

        private void Calculate_signal()
        {

            int cnt = 0;
            foreach (var fsubstates in FuturesSubStates.Values)
            {



                fsubstates.now_price = fsubstates.DerivState.CurrentPrice;


                //long order_quantity = 9;

                long target_amount = (long)(fsubstates.Params.OrderAmount * 10000 * 10000);

                bool minute15_update_flag = false;
                bool minute_update_flag = false;


                // 코스피 선물 기준으로 개수를 맞춤

               // Console.WriteLine($"signal_Check : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");

                //Console.WriteLine($"{fsubstates.DerivState.Name}");

                if (fsubstates.DerivState.Quote == null)
                {
                    Console.WriteLine("Calculate_signal : Quote 데이터가 null 입니다");
                    Console.WriteLine("");
                    continue;
                }
                else if (fsubstates.DerivState.CurrentPrice == 0  )
                {
                    Console.WriteLine("DerivState의 CurrentPrice가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }



                if (DateTime.Now.Minute != fsubstates.minute1_pre.Minute)
                {
                    minute_update_flag = true;
                    fsubstates.minute1_pre = DateTime.Now;

                    if (DateTime.Now.Minute == 0 || DateTime.Now.Minute == 15 || DateTime.Now.Minute == 30 || DateTime.Now.Minute == 45)
                    {   
                        Console.WriteLine($"Calculate_signal 15minutes_signal calc! : {DateTime.Now}");
                        minute15_update_flag = true;
                    }

                }

                //entry 모니터링
                if (object.ReferenceEquals(fsubstates.entry_side, null))
                {

                    long entry_quantity = 0;

                    DateTime front_entry_time =  new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 1, 0);
                    DateTime end_entry_time = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 33, 0);


                    bool tdopen_price_long_flag = fsubstates.today_open < fsubstates.now_price;
                    bool cb_break_high_flag = fsubstates.channel_high_entry < fsubstates.now_price;
                    bool entry_time_const = (DateTime.Now > front_entry_time) & (DateTime.Now < end_entry_time);

                    bool tdopen_price_short_flag = fsubstates.today_open > fsubstates.now_price;
                    bool cb_break_low_flag = fsubstates.channel_low_entry > fsubstates.now_price;

                    bool ma_downcross_flag = fsubstates.ma_price_short < fsubstates.ma_price_long;

                    bool long_entry_flag = (tdopen_price_long_flag) & (cb_break_high_flag) & (entry_time_const) & (minute15_update_flag) ;

                    //spread short 진입 체크
                    bool short_entry_flag = (tdopen_price_short_flag) & (cb_break_low_flag) & (ma_downcross_flag) & (entry_time_const) & (minute15_update_flag);

                    ////spread long 진입 pair1 long, pair2 short
                    ///
                    if (minute_update_flag)
                    {
                        Console.WriteLine("");

                        if((fsubstates.channel_high_entry- fsubstates.now_price) > (fsubstates.now_price - fsubstates.channel_low_entry))
                        {
                            Console.WriteLine($"{DateTime.Now}, long signal check ,minute15_update_flag:{minute15_update_flag},entry_time_const:{entry_time_const}");
                            Console.WriteLine($"now_price:{fsubstates.now_price}, today_open:{fsubstates.today_open},channel_high_entry:{fsubstates.channel_high_entry}");
                            Console.WriteLine($"Expecte Loss cut pct: { Math.Round(100*Math.Abs(Math.Max(fsubstates.channel_low_exit, fsubstates.today_open) / fsubstates.now_price - 1),2)} %");
                        }
                        else
                        {
                            Console.WriteLine($"{DateTime.Now}, short signal check ,minute15_update_flag:{minute15_update_flag},entry_time_const:{entry_time_const}");
                            Console.WriteLine($"now_price:{fsubstates.now_price}, today_open:{fsubstates.today_open},channel_high_entry:{fsubstates.channel_high_entry}");
                            Console.WriteLine($"Expecte Loss cut pct: {Math.Round(100*Math.Abs(1 - Math.Min(fsubstates.channel_high_exit, fsubstates.today_open) / fsubstates.now_price), 2) }%");
                        }

                    }

                    //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    //{
                    //    writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowEntryPrice},pair1_open: {FuturesSubStates[pair1_shortcode].today_open},pair1_return:{Math.Round(100 * pari1_norm_return, 2)}%");
                    //    writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowEntryPrice},pair2_open: {FuturesSubStates[pair2_shortcode].today_open},pair2_return:{Math.Round(100 * pari2_norm_return, 2)}%");
                    //    writer.WriteLine($"pair1_order_q:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity},pair2_order_q:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}");
                    //    writer.WriteLine($"spread_now:{Math.Round(100 * spread_now, 2)}%,spread_past1_min:{Math.Round(100 * spread_past1_min, 2)}%,pre_spread_vol:{Math.Round(100 * pre_spread_vol, 2)}%");
                    //    writer.WriteLine($"target_barrier:{Math.Round(100 * target_barrier, 2)}%");
                    //    writer.WriteLine($"spread_to_entry:{Math.Round(100 * remain_pct_entry, 2)}%");
                    //    writer.WriteLine($"already_break_long_by_const:{SpreadSubStates[pair_key].already_break_long_by_const} , already_break_short_by_const:{SpreadSubStates[pair_key].already_break_short_by_const} , already_exit:{SpreadSubStates[pair_key].already_exit}");
                    //    writer.WriteLine($"minute_update_flag:{minute_update_flag},already_break_long_by_const:{SpreadSubStates[pair_key].already_break_long_by_const} , already_break_short_by_const:{SpreadSubStates[pair_key].already_break_short_by_const} , already_exit:{SpreadSubStates[pair_key].already_exit}");

                    //    writer.WriteLine("");
                    //}

                    //Console.WriteLine("");


                    if (TradeOffButton.Checked)
                    {
                        //Console.WriteLine("TradeOffButton.Checked");
                        //Console.WriteLine("");
                        long_entry_flag = false;
                        short_entry_flag = false;
                    }
                    else if (EntryOffButton.Checked)
                    {
                        //Console.WriteLine("EntryOffButton.Checked");
                        //Console.WriteLine("");
                        long_entry_flag = false;
                        short_entry_flag = false;
                    }


                    if (long_entry_flag)
                    {

                        fsubstates.entry_signal_now = true;
                        fsubstates.entry_side = "long";

                        fsubstates.losscut_price = Math.Max(fsubstates.channel_low_exit, fsubstates.today_open);

                        double losscut_pct = Math.Abs( fsubstates.losscut_price/fsubstates.now_price  - 1);
                        fsubstates.inv_weight = 0.005 / losscut_pct;
                        fsubstates.inv_weight = Math.Round(fsubstates.inv_weight, 1);
                        fsubstates.inv_weight = Math.Max( 0.1 , Math.Min(fsubstates.inv_weight, 1));

                        fsubstates.TargetOrderQuantity = (long)( (fsubstates.inv_weight * target_amount) / (fsubstates.now_price * fsubstates.DerivState.Multiplier));
                        
                        Console.WriteLine($"Entry long signal, inv_weight:{fsubstates.inv_weight} ,target_amount : {target_amount}");
                        Console.WriteLine($"{fsubstates.Name}:{fsubstates.TargetOrderQuantity}계약 long ");
                        //Save_substates();

                        //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        //{
                        //    writer.WriteLine($"Entry long signal {pair_key},target_amount : {target_amount}");
                        //    writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 long ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 short ");
                        //    writer.WriteLine("");
                        //}
                    }
                    else if (short_entry_flag)
                    {

                        fsubstates.entry_signal_now = true;
                        fsubstates.entry_side = "short";

                
                        fsubstates.losscut_price = Math.Min(fsubstates.channel_high_exit, fsubstates.today_open);

                        double losscut_pct = Math.Abs(1-fsubstates.losscut_price / fsubstates.now_price );
                        fsubstates.inv_weight = 0.005 / losscut_pct;
                        fsubstates.inv_weight = Math.Round(fsubstates.inv_weight, 1);
                        fsubstates.inv_weight = Math.Max(0.1, Math.Min(fsubstates.inv_weight, 1));

                        fsubstates.TargetOrderQuantity = (long)((fsubstates.inv_weight * target_amount) / (fsubstates.now_price * fsubstates.DerivState.Multiplier));

                        Console.WriteLine($"Entry short signal, inv_weight:{fsubstates.inv_weight} ,target_amount : {target_amount}");
                        Console.WriteLine($"{fsubstates.Name}:{fsubstates.TargetOrderQuantity}계약 long ");
                        ////Save_spreadsubstates();

                        //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        //{
                        //    writer.WriteLine($"Entry short signal {pair_key},target_amount : {target_amount}");
                        //    writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 short ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 long ");
                        //    writer.WriteLine("");
                        //}
                    }

                }

                //exit 모니터링
                if (!object.ReferenceEquals(fsubstates.entry_side, null) & fsubstates.exit_monitoring)
                {
                    
                    
                    double total_amount = fsubstates.DerivState.Multiplier * fsubstates.DerivState.AveragePrice * Math.Abs(fsubstates.DerivState.NormalBalance);

                    

                    if ((fsubstates.DerivState.NormalBalance != 0 & fsubstates.DerivState.AveragePrice == 0))
                    {
                        Console.WriteLine("AveragePrice가 0 입니다");
                        Console.WriteLine("");

                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {
                            writer.WriteLine("AveragePrice가 0 입니다");
                            writer.WriteLine("");
                        }
                        continue;
                    }

                    if (fsubstates.DerivState.NormalBalance == 0 )
                    {
                        Console.WriteLine("NormalBalance=0 ");
                        fsubstates.exit_signal_now = true;
                        fsubstates.exit_monitoring = false;


                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {
                            writer.WriteLine("NormalBalance=0");
                            writer.WriteLine("");
                        }
                        continue;
                    }



                    double expected_return = (fsubstates.entry_side == "long") ?  (fsubstates.now_price/ fsubstates.DerivState.AveragePrice-1) : fsubstates.inv_weight * (1-fsubstates.now_price / fsubstates.DerivState.AveragePrice );
                    double bar1_last_return = (fsubstates.entry_side == "long") ? (fsubstates.now_price / fsubstates.PriceSetClose.First() - 1) : (1 - fsubstates.now_price / fsubstates.PriceSetClose.First());


                    //spraed long 청산 체크
                    bool Fast_exit_flag = bar1_last_return > 0.02;
                    bool Losscut_flag = (fsubstates.entry_side == "long") ? fsubstates.now_price < fsubstates.losscut_price : fsubstates.now_price > fsubstates.losscut_price;
                    bool signal_flag = (fsubstates.entry_side == "long") ? fsubstates.now_price < fsubstates.channel_low_exit : fsubstates.now_price > fsubstates.channel_high_exit;

                    Losscut_flag = Losscut_flag & minute15_update_flag;
                    signal_flag = signal_flag & minute15_update_flag;

                    Console.WriteLine($"{DateTime.Now}, {fsubstates.entry_side} Exit signal check ,minute15_update_flag:{minute15_update_flag}");
                    Console.WriteLine($"bar1_last_return:{bar1_last_return}, expected_return:{expected_return}");
                    Console.WriteLine($"curr_price:{fsubstates.now_price},losscut_price:{fsubstates.losscut_price}, channel_low_exit: {fsubstates.channel_low_exit}, channel_high_exit:{fsubstates.channel_high_exit}");

                    //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    //{
                    //    writer.WriteLine($"pair1_exit_price:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair2_exit_price:{SpreadSubStates[pair_key].Pair2NowExitPrice}");
                    //    writer.WriteLine($"expected_return:{Math.Round(100 * expected_return, 2)}%,,Time_after_entry:{Time_after_entry}분 , pair1_ratio:{Math.Round(pair1_ratio, 2)},pair2_ratio:{Math.Round(pair2_ratio, 2)}");
                    //    writer.WriteLine($"Profit_flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.TargetRate, 2)}%,Loss_Flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.LossCutRate, 2)}%");
                    //    writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair1_avg_price:{DerivState_pair1.AveragePrice},pair1_return_percent:{Math.Round(100 * pair1_return_percent, 2)}%");
                    //    writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowExitPrice},pair2_avg_price:{DerivState_pair2.AveragePrice},pair2_return_percent:{Math.Round(100 * pair2_return_percent, 2)}%");

                    //    writer.WriteLine("");
                    //}

                    if (TradeOffButton.Checked) { continue; }


                    if (Fast_exit_flag | Losscut_flag| signal_flag)
                    {
                        fsubstates.exit_signal_now = true;
                        fsubstates.exit_monitoring = false;

                        if (Fast_exit_flag)
                        {
                            Console.WriteLine($"Fast_exit Take!! {fsubstates.Easyname}");

                            //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            //{
                            //    writer.WriteLine($"Exit Profit Take!! {pair_key}");
                            //    writer.WriteLine("");
                            //}
                        }
                        else if (Losscut_flag)
                        {
                            Console.WriteLine($"Entry  Loss cut!! {fsubstates.Easyname}");

                            //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            //{
                            //    writer.WriteLine($"Exit Loss cut!! {pair_key}");
                            //    writer.WriteLine("");
                            //}
                        }
                        else if (signal_flag)
                        {
                            Console.WriteLine($"signal_flag cut!! {fsubstates.Easyname}");

                            //using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            //{
                            //    writer.WriteLine($"Exit Loss cut!! {pair_key}");
                            //    writer.WriteLine("");
                            //}
                        }


                        //Save_spreadsubstates();

                    }

                }

            }
            Console.WriteLine("");

            //Console.WriteLine("");
        }

        private void signal_entry_check_and_order()
        {
            foreach (var fsubstates in FuturesSubStates.Values)
            {
                var DerivState = fsubstates.DerivState;
                string Shortcode = DerivState.ShortCode;
                string Name = DerivState.Name;
                long order_quantity_standard = 3;

                if (EntryOffButton.Checked) { continue; }


                //미체결된 주문 여부 확인

                if (DerivState.LiveOrders.Count != 0 )
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시
                    // 미체결 비율 체크하는 로직 필요
                    if (DerivState.LiveOrders.Count != 0)
                    {
                        DerivState.CancelOrders(DerivState.LiveOrders[0].AskBidType);
                    }
                }

                //
                long TargetOrderQuantity = fsubstates.TargetOrderQuantity;


                //event loop 직전 Quantity
                long NowQuantity = fsubstates.NowQuantity;

                // 현재 Quantity
                long Real_NowQuantity = (long)Math.Abs(DerivState.NormalBalance);


                bool target_quantity_complete = (Real_NowQuantity == TargetOrderQuantity);

                if (!fsubstates.entry_signal_now)
                {   //entry_today_signal이 존재할시만 주문
                    continue;
                }
                else if (DerivState.Quote == null)
                {
                    Console.WriteLine("signal_entry_check : Quote 데이터가 null 입니다");
                    continue;
                }


                Console.WriteLine($"Entry Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");

                //entry long
                double AskPrice = C.AsDouble(DerivState.Quote[0].AskPrice);

                //entry short
                double BidPrice = C.AsDouble(DerivState.Quote[0].BidPrice);

   
                if (AskPrice == 0 | BidPrice == 0 )
                {
                    Console.WriteLine("Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                //오늘 처음 entry order , 첫번째 주문을 내지 않은 조건에서 실행됌.
                if (!fsubstates.first_entry_order_done)
                {
                    fsubstates.EntryTime = DateTime.Now;
                    // spread long 진입 pair1 long, pair2 short
                    if (fsubstates.entry_side == "long")
                    {

                        long order_quantity = Math.Min(TargetOrderQuantity, order_quantity_standard);


                        if (order_quantity <= 0 ) { continue; }
                        else if (AskPrice > 1000000000 | BidPrice > 1000000000) { continue; }
                        else if (order_quantity > 20 | order_quantity > 20)
                        {
                            Console.WriteLine($"order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }

                        Console.WriteLine($"First Entry Order long {Name}");
                        Console.WriteLine($"Send NewOrder entry long: {Shortcode}  AskPrice: {AskPrice} order_quantity:{order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {

                            writer.WriteLine($"First Entry Order long {Name}");
                            writer.WriteLine($"Send NewOrder entry long: {Shortcode}  AskPrice: {AskPrice} order_quantity:{order_quantity}");
                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState.NewOrder(AskBidType.Bid, AskPrice, order_quantity, OrderType.Limit, OrderCondition.Normal);
                        fsubstates.RecentOrderQuantity = order_quantity;

                    }// spread short 진입 pair1 short, pair2 long
                    else if (fsubstates.entry_side == "short")
                    {
                        long order_quantity = Math.Min(TargetOrderQuantity, order_quantity_standard);
     
                        if (order_quantity <= 0 ) { continue; }
                        else if (AskPrice > 1000000000 ) { continue; }
                        else if (order_quantity > 20 )
                        {
                            Console.WriteLine($"order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"First Entry Order short {Name}");
                        Console.WriteLine($"Send NewOrder entry short: {Shortcode} BidPrice: {BidPrice} order_quantity:{order_quantity}");
 
                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {
                            writer.WriteLine($"First Entry Order short {Name}");
                            writer.WriteLine($"Send NewOrder entry short: {Shortcode} BidPrice: {BidPrice} order_quantity:{order_quantity}");
                            writer.WriteLine("");
                        }


                        //AskBidType.Bid: long , AskBidType.Ask: short
                        DerivState.NewOrder(AskBidType.Ask, BidPrice, order_quantity, OrderType.Limit, OrderCondition.Normal);
                        fsubstates.RecentOrderQuantity = order_quantity;
      


                    }

                    //주문을 냈으므로 True로 변환 , 다음 loop에선 들어가지 않음

                    fsubstates.first_entry_order_done = true;

                    //Save_spreadsubstates();
                    Console.WriteLine("");
                }
                else // order entry이후 order check, 미체결 및  재진입 여부 판단 
                {

                    if (!target_quantity_complete) //미체결이 없을시 & target_quantity에서 현재 quantity 를 뺀금액만큼 추가주문
                    {

                        //time event 직전 Quantity와 차이가 있을때 체결이 되었다 가정
                        if (NowQuantity != Real_NowQuantity)
                        {
                            Console.WriteLine($"TargetOrderQuantity:{TargetOrderQuantity} , Real_NowQuantity {Real_NowQuantity}");

                            // 현재 balance로 amount 업데이트
                            fsubstates.NowQuantity = Real_NowQuantity;

                            //재주문을 내야하는 quantity를 계산함
                            long reentry_order_quantity = fsubstates.TargetOrderQuantity - Real_NowQuantity;


                            if (fsubstates.entry_side == "long")
                            {

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity = Math.Min(reentry_order_quantity, order_quantity_standard);
         
                                Console.WriteLine($"Entry reentry Order long {Name}");


                                if (reentry_order_quantity > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity > 20 )
                                    {
                                        Console.WriteLine($"order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder long: {Shortcode} reentry order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder long: {Shortcode} reentry order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState.NewOrder(AskBidType.Bid, AskPrice, reentry_order_quantity, OrderType.Limit, OrderCondition.Normal);
                                    fsubstates.RecentOrderQuantity = reentry_order_quantity;


                                }

                            }
                            else if (fsubstates.entry_side == "short")
                            {

                                reentry_order_quantity = Math.Min(reentry_order_quantity, order_quantity_standard);

                                Console.WriteLine($"Entry reentry Order short {Name}");


                                if (reentry_order_quantity > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity > 20 )
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder short: {Shortcode} reentry order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder short: {Shortcode} reentry order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState.NewOrder(AskBidType.Ask, BidPrice, reentry_order_quantity, OrderType.Limit, OrderCondition.Normal);
                                    fsubstates.RecentOrderQuantity = reentry_order_quantity;

                                }

                            }
                            //Save_spreadsubstates();
                            Console.WriteLine("");
                        }


                    }
                    else
                    {
                        //Console.WriteLine("이미 target_amount를 채웠습니다");
                        fsubstates.exit_monitoring = true;

                        // 진입 주문 함수에 들어오지 못하게 하는 flag
                        fsubstates.entry_signal_now = false;

                        //exit에선 현재 잔고를 기반으로 target order quanity가 정해지므로 초기화함
                        fsubstates.TargetOrderQuantity = 0;
                        fsubstates.RecentOrderQuantity = 0;

                        //Save_spreadsubstates();

                        Console.WriteLine($"target_quantity_order_complete {Name}");

                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {
                            writer.WriteLine($"target_quantity_order_complete {Name}");
                            writer.WriteLine("");
                        }
                    }



                }

            }

        }


        private void signal_exit_check_and_order()
        {
            foreach (var fsubstates in FuturesSubStates.Values)
            {
                var DerivState = fsubstates.DerivState;
                string Shortcode = DerivState.ShortCode;
                string Name = DerivState.Name;
                long order_quantity_standard = 3;

                if (EntryOffButton.Checked) { continue; }


                //미체결된 주문 여부 확인

                if (DerivState.LiveOrders.Count != 0)
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시
                    // 미체결 비율 체크하는 로직 필요
                    if (DerivState.LiveOrders.Count != 0)
                    {
                        DerivState.CancelOrders(DerivState.LiveOrders[0].AskBidType);
                    }
                }

                //
                //long TargetOrderQuantity = fsubstates.TargetOrderQuantity;


                //event loop 직전 Quantity
                long NowQuantity = fsubstates.NowQuantity;

                // 현재 Quantity
                long Real_NowQuantity = (long)Math.Abs(DerivState.NormalBalance);


                bool target_quantity_complete = (Real_NowQuantity == 0);

                if (!fsubstates.exit_signal_now)
                {   //entry_today_signal이 존재할시만 주문
                    continue;
                }
                else if (DerivState.Quote == null)
                {
                    Console.WriteLine("signal_entry_check : Quote 데이터가 null 입니다");
                    continue;
                }


                Console.WriteLine($"Exit Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");

                //entry long
                double AskPrice = C.AsDouble(DerivState.Quote[0].AskPrice);

                //entry short
                double BidPrice = C.AsDouble(DerivState.Quote[0].BidPrice);


                if (AskPrice == 0 | BidPrice == 0)
                {
                    Console.WriteLine("Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                //오늘 처음 entry order , 첫번째 주문을 내지 않은 조건에서 실행됌.
                if (!fsubstates.first_exit_order_done)
                {

                    // spread long 진입 pair1 long, pair2 short
                    if (fsubstates.entry_side == "short")
                    {

                        long order_quantity = Math.Min(Real_NowQuantity, order_quantity_standard);


                        if (order_quantity <= 0) { continue; }
                        else if (AskPrice > 1000000000 | BidPrice > 1000000000) { continue; }
                        else if (order_quantity > 20 | order_quantity > 20)
                        {
                            Console.WriteLine($"order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }

                        Console.WriteLine($"First Exit Order long {Name}");
                        Console.WriteLine($"Send NewOrder exit long: {Shortcode}  AskPrice: {AskPrice} order_quantity:{order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {

                            writer.WriteLine($"First Exit Order long {Name}");
                            writer.WriteLine($"Send NewOrder exit long: {Shortcode}  AskPrice: {AskPrice} order_quantity:{order_quantity}");
                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState.NewOrder(AskBidType.Bid, AskPrice, order_quantity, OrderType.Limit, OrderCondition.Normal);
                        fsubstates.RecentOrderQuantity = order_quantity;

                    }// spread short 진입 pair1 short, pair2 long
                    else if (fsubstates.entry_side == "long")
                    {
                        long order_quantity = Math.Min(Real_NowQuantity, order_quantity_standard);

                        if (order_quantity <= 0) { continue; }
                        else if (AskPrice > 1000000000) { continue; }
                        else if (order_quantity > 20)
                        {
                            Console.WriteLine($"order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"First Exit Order short {Name}");
                        Console.WriteLine($"Send NewOrder exit short: {Shortcode} BidPrice: {BidPrice} order_quantity:{order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                        {
                            writer.WriteLine($"First Exit Order short {Name}");
                            writer.WriteLine($"Send NewOrder exit short: {Shortcode} BidPrice: {BidPrice} order_quantity:{order_quantity}");
                            writer.WriteLine("");
                        }


                        //AskBidType.Bid: long , AskBidType.Ask: short
                        DerivState.NewOrder(AskBidType.Ask, BidPrice, order_quantity, OrderType.Limit, OrderCondition.Normal);
                        fsubstates.RecentOrderQuantity = order_quantity;



                    }

                    //주문을 냈으므로 True로 변환 , 다음 loop에선 들어가지 않음

                    fsubstates.first_exit_order_done = true;

                    //Save_spreadsubstates();
                    Console.WriteLine("");
                }
                else // order entry이후 order check, 미체결 및  재진입 여부 판단 
                {

                    if (!target_quantity_complete) //미체결이 없을시 & target_quantity에서 현재 quantity 를 뺀금액만큼 추가주문
                    {

                        //time event 직전 Quantity와 차이가 있을때 체결이 되었다 가정
                        if (NowQuantity != Real_NowQuantity)
                        {
                            Console.WriteLine($"Real_NowQuantity {Real_NowQuantity}");

                            // 현재 balance로 amount 업데이트
                            fsubstates.NowQuantity = Real_NowQuantity;

                            //재주문을 내야하는 quantity를 계산함
                            long reentry_order_quantity = Real_NowQuantity;


                            if (fsubstates.entry_side == "short")
                            {

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity = Math.Min(reentry_order_quantity, order_quantity_standard);

                                Console.WriteLine($"Exit reexit Order long {Name}");


                                if (reentry_order_quantity > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity > 20)
                                    {
                                        Console.WriteLine($"order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reexit NewOrder long: {Shortcode} reexit order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                                    {
                                        writer.WriteLine($"Send Reexit NewOrder long: {Shortcode} reexit order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState.NewOrder(AskBidType.Bid, AskPrice, reentry_order_quantity, OrderType.Limit, OrderCondition.Normal);
                                    fsubstates.RecentOrderQuantity = reentry_order_quantity;


                                }

                            }
                            else if (fsubstates.entry_side == "long")
                            {

                                reentry_order_quantity = Math.Min(reentry_order_quantity, order_quantity_standard);

                                Console.WriteLine($"Entry reexit Order short {Name}");


                                if (reentry_order_quantity > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity > 20)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reexit NewOrder short: {Shortcode} reexit order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");

                                    using (StreamWriter writer = new StreamWriter(filePath_log, append: true))
                                    {
                                        writer.WriteLine($"Send Reexit NewOrder short: {Shortcode} reexit order_amount:{reentry_order_quantity} AskPrice: {AskPrice}");
                                        writer.WriteLine("");
                                    }

                                    DerivState.NewOrder(AskBidType.Ask, BidPrice, reentry_order_quantity, OrderType.Limit, OrderCondition.Normal);
                                    fsubstates.RecentOrderQuantity = reentry_order_quantity;

                                }

                            }
                            //Save_spreadsubstates();
                            Console.WriteLine("");
                        }


                    }
                    else
                    {
                        Console.WriteLine($"All Complete Exit {Name}");
                        //변수 초기화
                        fsubstates.entry_signal_now = false;
                        fsubstates.exit_signal_now = false;

                        fsubstates.first_entry_order_done = false;
                        fsubstates.first_exit_order_done = false;

                        fsubstates.exit_monitoring = false;

                        fsubstates.entry_side = null;

                        fsubstates.RecentOrderQuantity = 0;

                        //Save_spreadsubstates();
                    }



                }

            }

        }


        private void Save_states()
        {
            // Person 클래스 직렬화하여 C:\Users\234046\Desktop\release\StockFuturesPairRsi 경로에 저장 (관리자 권한 필요)

            string filePath_states = $@"C:\Users\234046\Desktop\States\IndexFuturePairIntraBreak\SaveStates_{DateTime.Now.ToString("yyyy-MM-dd")}.dat";

            using (FileStream fileStream = new FileStream(filePath_states, FileMode.Create))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, SaveStates);
            }
            Console.WriteLine("딕셔너리 Spread Sub State Class Update Complete");
        }

        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsDouble(TargetRateBox.Text) / 100,
                C.AsDouble(LossCutRateBox.Text) / 100,
                C.AsLong(MaxNotionalAmountBox.Text) * 100_000_000,
                C.AsLong(C.AsDouble(MaxAmountPerOrderBox.Text) * 100_000_000),
                C.AsLong(C.AsDouble(OrderAmountBox.Text))
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }


        public void Enable() { this.Enabled = true; }

        private class FuturesSubState
        {
            public string StandardCode { get; private set; }
            public string ShortCode { get; private set; }
            public string Name { get; private set; }
            public DerivState DerivState { get; private set; }
            public StrategyParams Params;

            public string Easyname;

            public long NowQuantity = 0;
            public long remainQuantity;

            public long TargetOrderQuantity;
            public long RecentOrderQuantity;

            public List<double> PriceSetClose = new List<double>();
            public List<double> PriceSetHigh = new List<double>();
            public List<double> PriceSetLow = new List<double>();
            public List<string> DatetimeSet = new List<string>();

            public double today_open;
            public double channel_high_entry;
            public double channel_low_entry;

            public double channel_high_exit;
            public double channel_low_exit;

            public double ma_price_long;
            public double ma_price_short;

            public double now_price;

            public DateTime minute1_pre;
            public DateTime EntryTime;

            public string entry_side = null;

            // entry exit signal 발생 flag
            public bool entry_signal_now = false;
            public bool exit_signal_now = false;

            //entry exit signal 이후 첫주문이 나갔는지 여부
            public bool first_entry_order_done = false;
            public bool first_exit_order_done = false;

            //exit 모니터링 여부 flag
            public bool exit_monitoring = false;

            public double losscut_price;
            public double inv_weight;

            public FuturesSubState(DerivState deriveState, string standardCode, string shortCode, string name, StrategyParams strategyParams)
            {
                this.DerivState = deriveState;
                this.StandardCode = standardCode;
                this.ShortCode = shortCode;
                this.Name = name;

                this.Params = strategyParams;
            }
        }

        [Serializable]
        class SaveState
        {

            public StrategyParams Params;

            public List<double> Pair1PriceSet = new List<double>();
            public List<double> Pair2PriceSet = new List<double>();
            public List<double> normSpreadSet = new List<double>();


            public string Pair1ShortCode;
            public string Pair2ShortCode;

            public string Pair1FuturesShortCode;
            public string Pair2FuturesShortCode;

            public double Pair1NowPrice;
            public double Pair2NowPrice;

            public double Pair1NowEntryPrice;
            public double Pair2NowEntryPrice;

            public double Pair1NowExitPrice;
            public double Pair2NowExitPrice;

            public long Pair1TargetOrderQuantity;
            public long Pair2TargetOrderQuantity;

            public long Pair1RecentOrderQuantity;
            public long Pair2RecentOrderQuantity;

            public double cointvalue;
            public double TakeProfitAdj;
            public double LossCutAdj;

            public double pre_spread_vol;
            public double spread_past1_min;
            public DateTime minute1_pre;
            public DateTime EntryTime;


            public bool HasPendingRequest = false;
            public string entry_side = null;

            // entry exit signal 발생 flag
            public bool entry_signal_now = false;
            public bool exit_signal_now = false;

            //entry exit signal 이후 첫주문이 나갔는지 여부
            public bool first_entry_order_done = false;
            public bool first_exit_order_done = false;

            //exit 모니터링 여부 flag
            public bool exit_monitoring = false;

            public bool Enabled = true;
            public bool already_exit = false;

            public bool already_break_long_by_const = false;
            public bool already_break_short_by_const = false;

            public SaveState(StrategyParams strategyParams)
            {
                this.Params = strategyParams;
            }

        }



        [Serializable]
        internal class StrategyParams
        {

            public double TargetRate { get; private set; }
            public double LossCutRate { get; private set; }
            public long MaxNotionalAmount { get; private set; }
            public long MaxAmountPerOrder { get; private set; }
            public long OrderAmount { get; private set; }
            public void StartegyParams()
            {
            }
            private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
            private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

            public bool Update(
                               double targetRate,
                               double losscutRate,
                               long maxNotionalAmount,
                               long maxAmountPerOrder,
                               long OrderAmount)
            {
                if (!DoubleGreaterThan(targetRate, 0.0))
                    return false;

                if (!DoubleLessThan(losscutRate, 0.0))
                    return false;

                if (DoubleGreaterThan(losscutRate, targetRate))
                    return false;

                if (maxAmountPerOrder <= 0)
                    return false;


                this.TargetRate = targetRate;
                this.LossCutRate = losscutRate;

                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxAmountPerOrder = maxAmountPerOrder;
                this.OrderAmount = OrderAmount;


                return true;
            }
        }


        private void PauseButton_Click(object sender, EventArgs e)
        {
            working_flag = false;
        }

        private void ResumeButton_Click(object sender, EventArgs e)
        {
            working_flag = true;
        }


    }
}