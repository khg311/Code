﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PnK_indi
{
    public class Safety
    {
        private readonly MainWindow Main;

        // 1회 주문금액한도 20억
        public long SingleOrderAmountLimit { get; private set; } = 2_000_000_000;
        // 선물 주문금액 한도 40억
        public long FuturesSingleOrderAmountLimit { get; private set; } = 4_000_000_000;

        // 종목당 포지션 한도
        public long SingleAssetPositionLimit { get; private set; } = 5_000_000_000;

        // 선물 포지션 한도
        public long FuturesSingleAssetPositionLimit { get; private set; } = 10_000_000_000;

        // 펀드별 포지션 한도
        public long FundPositionLimit { get; private set; } = 20_000_000_000;

        // 시간당 주문횟수 한도
        public long Interval { get; private set; } = 5;
        public long OrderNumberLimit { get; private set; } = 1000;

        private List<DateTime> TimeSet { get; set; }

        public Safety(MainWindow main)
        {
            this.Main = main;
            this.TimeSet = new List<DateTime>();
        }

        public bool CheckCrossTrade(Order order)
        {
            var liveOrders = Main.LiveOrders.ToList();
            liveOrders = liveOrders.Where(x => x.StandardCode == order.StandardCode).ToList();

            if (liveOrders.Count() == 0)
                return false;

            if (order.AskBidType == AskBidType.Ask)
                return liveOrders.Any(x => x.AskBidType == AskBidType.Bid && x.Price >= order.Price);
            else
                return liveOrders.Any(x => x.AskBidType == AskBidType.Ask && x.Price <= order.Price);
        }

        public bool CheckCrossTrade(DerivOrder order)
        {
            var liveOrders = Main.DerivLiveOrders.Where(x => x.StandardCode == order.StandardCode).ToList();

            if (liveOrders.Count() == 0)
                return false;

            if (order.AskBidType == AskBidType.Ask)
                return liveOrders.Any(x => x.AskBidType == AskBidType.Bid && x.Price >= order.Price);
            else
                return liveOrders.Any(x => x.AskBidType == AskBidType.Ask && x.Price <= order.Price);
        }

        public bool Update(long singleOrderAmountLimit, long singleAssetPositionLimit, long fundPositionLimit, long interval, long orderNumberLimit)
        {
            if (singleOrderAmountLimit < 0)
                return false;

            if (singleAssetPositionLimit < 0)
                return false;

            if (fundPositionLimit < 0)
                return false;

            if (interval <= 0)
                return false;

            if (orderNumberLimit < 0)
                return false;

            this.SingleOrderAmountLimit = singleOrderAmountLimit;
            this.SingleAssetPositionLimit = singleAssetPositionLimit;
            this.FundPositionLimit = fundPositionLimit;
            this.Interval = interval;
            this.OrderNumberLimit = orderNumberLimit;

            return true;
        }

        public bool CheckLimits(Order order)
        {
            if (CheckSingleOrderAmountLimit(order))
            {
                Main.LogWriter.Write("single stock singleOrderAmountLimit");
                return true;
            }

            if (CheckSingleAssetPositionLimit(order))
            {
                Main.LogWriter.Write("single stock singleAssetPositionLimit");
                return true;
            }

            if (CheckFundPositionLimit(order))
            {
                Main.LogWriter.Write("single stock fundPositionLimit");
                return true;
            }

            if (CheckOrderNumberLimit())
                return true;

            return false;
        }

        public bool CheckLimits(DerivOrder order)
        {
            if (CheckSingleOrderAmountLimit(order))
            {
                Main.LogWriter.Write("futures singleOrderAmountLimit");
                return true;
            }

            if (CheckSingleAssetPositionLimit(order))
            {
                Main.LogWriter.Write("futures singleAssetPositionLimit");
                return true;
            }

            if (CheckFundPositionLimit(order))
            {
                Main.LogWriter.Write("futures fundPositionLimit");
                return true;
            }

            if (CheckOrderNumberLimit())
                return true;

            return false;
        }

        public bool CheckSingleOrderAmountLimit(Order order)
        {
            long orderPrice = order.OrderType == OrderType.Market ? Main.States[order.StandardCode].CurrentPrice : order.Price;
            return orderPrice * order.Quantity >= SingleOrderAmountLimit;
        }

        public bool CheckSingleOrderAmountLimit(DerivOrder order)
        {
            double orderPrice = order.OrderType == OrderType.Market ? Main.DerivStates[order.StandardCode].CurrentPrice : order.Price;

            double orderAmount;

            if (order.StandardCode.StartsWith("KR4101"))
            {
                orderAmount = 250_000 * orderPrice * order.Quantity;
                return orderAmount >= FuturesSingleOrderAmountLimit;
            }
            else if (order.StandardCode.StartsWith("KR4106"))
            {
                orderAmount = 10_000 * orderPrice * order.Quantity;
                return orderAmount >= FuturesSingleOrderAmountLimit;
            }
            else
            {
                orderAmount = 10 * orderPrice * order.Quantity;
                return orderAmount >= FuturesSingleOrderAmountLimit;
            }
        }

        public bool CheckSingleAssetPositionLimit(Order order)
        {
            if (order.AskBidType != AskBidType.Bid)
                return false;

            long orderPrice = order.OrderType == OrderType.Market ? Main.States[order.StandardCode].CurrentPrice : order.Price;
            return Main.States[order.StandardCode].NormalBalance * Main.States[order.StandardCode].AverageBuyPrice + orderPrice * order.Quantity >= SingleAssetPositionLimit;
        }

        public bool CheckSingleAssetPositionLimit(DerivOrder order)
        {
            int askBidType = order.AskBidType == AskBidType.Bid ? 1 : -1;
            double orderPrice = order.OrderType == OrderType.Market ? Main.DerivStates[order.StandardCode].CurrentPrice : order.Price;

            double positionAmount;

            if (order.StandardCode.StartsWith("KR4101"))
            {
                positionAmount = 250_000 * Math.Abs(Main.DerivStates[order.StandardCode].NormalBalance * Main.DerivStates[order.StandardCode].AveragePrice + orderPrice * order.Quantity * askBidType);
                return positionAmount >= FuturesSingleAssetPositionLimit;
            }
            else if (order.StandardCode.StartsWith("KR4106"))
            {
                positionAmount = 10_000 * Math.Abs(Main.DerivStates[order.StandardCode].NormalBalance * Main.DerivStates[order.StandardCode].AveragePrice + orderPrice * order.Quantity * askBidType);
                return positionAmount >= FuturesSingleAssetPositionLimit;
            }
            else
            {
                positionAmount = 10 * Math.Abs(Main.DerivStates[order.StandardCode].NormalBalance * Main.DerivStates[order.StandardCode].AveragePrice + orderPrice * order.Quantity * askBidType);
                return positionAmount >= FuturesSingleAssetPositionLimit;
            }
        }

        public bool CheckFundPositionLimit(Order order)
        {
            if (order.AskBidType != AskBidType.Bid)
                return false;

            long orderPrice = order.OrderType == OrderType.Market ? Main.States[order.StandardCode].CurrentPrice : order.Price;
            return Main.FundBalanceAmount + orderPrice * order.Quantity >= FundPositionLimit;
        }

        public bool CheckFundPositionLimit(DerivOrder order)
        {
            //int multiplier = Main.IndexFutureStates[order.StandardCode].MarketType == MarketType.KospiFuture ? 250_000 : 10_000;
            //int side = order.AskBidType == AskBidType.Bid ? 1 : -1;
            //double orderPrice = order.OrderType == OrderType.Market ? Main.IndexFutureStates[order.StandardCode].CurrentPrice : order.Price;

            //return multiplier * Math.Abs(Main.FundBalanceAmount + orderPrice * order.Quantity * side) >= FundPositionLimit;
            return false;
        }

        public bool CheckOrderNumberLimit()
        {
            if (TimeSet.Count(x => (DateTime.Now - x).TotalSeconds < Interval) >= OrderNumberLimit)
            {
                Main.LogWriter.Write($"ordernumberlimit {TimeSet.Count(x => (DateTime.Now - x).TotalSeconds < Interval)}/{OrderNumberLimit}");
                return true;
            }

            TimeSet.RemoveAll(x => (DateTime.Now - x).TotalSeconds >= Interval);
            TimeSet.Add(DateTime.Now);

            return false;
        }
    }
}
