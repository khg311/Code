﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace PnK_indi
{
    public class StockState
    {
        private MainWindow Main;
        private ICommHelper CommHelper { get; set; }
        public PriceHelper PriceHelper { get; private set; }
        private TypeConverter C { get; set; }

        public string StandardCode { get; private set; }
        public string ShortCode { get; private set; }
        public string Name { get; private set; }
        public MarketType MarketType { get; private set; }
        public PriceAdjustment PriceAdjustment { get; private set; }
        public SecurityGroupId SecurityGroupId { get; private set; }
        public long PreviousDayPrice { get; private set; }
        public long OutstandingShares { get; private set; }
        public long PreviousDayTradingAmount { get; private set; }
        public long UpperLimitPrice { get; private set; }
        public long LowerLimitPrice { get; private set; }
        public long OpenPrice { get; private set; }
        public long HighPrice { get; private set; }
        public long LowPrice { get; private set; }
        public long CurrentPrice { get; private set; }
        public DateTime TradingTime { get; private set; }
        public long CumulativeTradingVolume { get; private set; }
        public long CumulativeTradingAmount { get; private set; }
        public Quote[] Quote { get; set; }
        public ETPQuote[] ETPQuote { get; set; }
        public (long Ask, long Bid) BestQuote { get; private set; }
        public (long Price, long Volume) Expected { get; private set; }

        public List<LiveOrder> LiveOrders { get; private set; }
        public long NormalBalance { get; private set; }
        public long BalanceAvailableToSell { get; private set; }
        public long AverageBuyPrice { get; private set; }

        public long PreviousDayBalance { get; private set; }
        public long PreviousDayAverageBuyPrice { get; private set; }

        public DateTime DelayTime { get; private set; }
        private bool HasPendingBidOrder { get; set; }
        private bool HasPendingAskOrder { get; set; }
        private bool HasPendingOrders { get; set; }

        private bool Enabled { get; set; }
        internal bool IsViActive { get; set; }
        private bool IsCleared { get; set; }

        private StockOrderStruct OrderStruct = new StockOrderStruct();

        public StockState(MainWindow main, ICommHelper commHelper, string standardCode, string shortCode, string name,
                        MarketType marketType, SecurityGroupId securityGroupId, long previousDayPrice, long outstandingShares, long previousDayTradingAmount,
                        long upperLimitPrice, long lowerLimitPrice, PriceAdjustment priceAdjustment)
        {
            this.Main = main;
            this.CommHelper = commHelper;
            this.PriceHelper = new PriceHelper(securityGroupId);
            this.C = new TypeConverter();

            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.Name = name;
            this.MarketType = marketType;
            this.SecurityGroupId = securityGroupId;
            this.PreviousDayPrice = previousDayPrice;
            this.OutstandingShares = outstandingShares;
            this.PreviousDayTradingAmount = previousDayTradingAmount;
            this.UpperLimitPrice = upperLimitPrice;
            this.LowerLimitPrice = lowerLimitPrice;
            this.PriceAdjustment = priceAdjustment;

            this.Quote = new Quote[10];
            this.ETPQuote = new ETPQuote[10];
            this.BestQuote = (0, 0);
            this.Expected = (0, 0);
            this.LiveOrders = new List<LiveOrder>();
            DelayTime = DateTime.Now;
            OrderStruct.StandardCode = StandardCode;

            Enable();
        }

        public void Enable()
        {
            if (!IsViActive && !Main.Prohibited.Contains(ShortCode) && !Main.Disables.Contains(ShortCode))
            {
                Enabled = true;
                IsCleared = false;
            }
        }

        public bool IsEnabled() => Enabled;

        public void Disable()
        {
            Enabled = false;
        }

        public void ResetPendingOrder(AskBidType? askBidType)
        {
            if (askBidType == AskBidType.Bid)
                HasPendingBidOrder = false;
            else if (askBidType == AskBidType.Ask)
                HasPendingAskOrder = false;
            else
                HasPendingOrders = false;
        }

        public void Clear()
        {
            IsCleared = true;

            if (NormalBalance == 0 && !LiveOrders.Any())
            {
                Disable();
                return;
            }

            if (HasPendingAskOrder || HasPendingOrders)
                return;

            if (LiveOrders.Any())
            {
                CancelAllOrders();
                return;
            }
            else if (NormalBalance > 0 && IsSellable())
                NewOrder(AskBidType.Ask, PriceHelper.GetNextPriceBelowTicks(CurrentPrice, 10), BalanceAvailableToSell, OrderType.Limit, OrderCondition.Normal);
        }

        public bool IsSellable() => BalanceAvailableToSell > 0 && (DateTime.Now - DelayTime).TotalSeconds >= 3;

        public void UpdateVolatilityInterruption(string viCategoryCode)
        {
            if (viCategoryCode == "1")
            {
                //LogWriter.Write($"{ShortCode} {Name} vi is activated");
                IsViActive = true;
                //Disable();
            }
            else if (viCategoryCode == "2")
            {
                //LogWriter.Write($"{ShortCode} {Name} vi is de-activated");
                IsViActive = false;
                //if (!IsCleared && !Main.Prohibited.Contains(ShortCode) && Main.Disables.Contains(ShortCode))
                //    Enable();
            }
        }

        public void UpdateQuotes(IFMSRPD0004 m)
        {
            this.OpenPrice = C.AsLong(m.OpenPrice);
            this.HighPrice = C.AsLong(m.HighPrice);
            this.LowPrice = C.AsLong(m.LowPrice);
            this.CurrentPrice = C.AsLong(m.TradingPrice);
            this.CumulativeTradingVolume = C.AsLong(m.CumulativeTradingVolume);
            this.CumulativeTradingAmount = C.AsLong(m.CumulativeTradingAmount);
            this.BestQuote = (C.AsLong(m.Ask1Price), C.AsLong(m.Bid1Price));
            this.TradingTime = DateTime.Now;

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Execution, this);
        }

        public void UpdateQuotes(IFMSRPD0002 m)
        {
            this.Quote = m.Quote;
            this.Expected = (C.AsLong(m.ExpectedTradingPrice), C.AsLong(m.ExpectedTradingVolume));

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Quote, this);
        }

        public void UpdateQuotes(IFMSRPD0007 m)
        {
            this.ETPQuote = m.Quote;
            this.Expected = (C.AsLong(m.ExpectedTradingPrice), C.AsLong(m.ExpectedTradingVolume));

            if (IsCleared)
            {
                Clear();
                return;
            }
            
            Main.UpdateQuotes(RealTimeDataType.Quote, this);
        }

        public void OnExecution(long orderId, long tradingPrice, long tradingQuantity)
        {
            AskBidType askBidType = AskBidType.Bid;
            if (LiveOrders.Exists(x => x.OrderId == orderId))
            {
                var filledLiveOrder = LiveOrders.Find(x => x.OrderId == orderId);
                filledLiveOrder.UpdateLiveQuantity(tradingQuantity);
                if (filledLiveOrder.AskBidType == AskBidType.Bid)
                {
                    AverageBuyPrice = (long)((NormalBalance * AverageBuyPrice + tradingPrice * tradingQuantity) / (double)(NormalBalance + tradingQuantity));
                    NormalBalance += tradingQuantity;
                    BalanceAvailableToSell += tradingQuantity;
                    DelayTime = DateTime.Now;
                }
                else if (filledLiveOrder.AskBidType == AskBidType.Ask)
                {
                    NormalBalance -= tradingQuantity;
                    askBidType = AskBidType.Ask;
                }
                
                LiveOrders.RemoveAll(x => x.LiveQuantity <= 0);
                
                if (NormalBalance == 0)
                {
                    BalanceAvailableToSell = 0;
                    AverageBuyPrice = 0;
                }
            }
            else
            {
                Main.LogWriter.Write($"{ShortCode} {Name} OnExecution there is no orderId {orderId} in LiveOrders!!!!");
                return;
            }

            Main.OnExecution(this);

            if (Main.Verbose)
                Main.LogWriter.Write($"OnExecution state {ShortCode} {Name} {askBidType} {NormalBalance} {BalanceAvailableToSell} {AverageBuyPrice} {orderId}");
        }

        public void OnConfirm(long originalOrderId, LiveOrder liveOrder)
        {
            if (originalOrderId != 0)
            {
                if (liveOrder == null && LiveOrders.Any(x => x.AskBidType == AskBidType.Ask && x.OrderId == originalOrderId))
                {
                    var cancelOrder = LiveOrders.Find(x => x.AskBidType == AskBidType.Ask && x.OrderId == originalOrderId);
                    BalanceAvailableToSell += cancelOrder.LiveQuantity;
                    DelayTime = DateTime.Now;
                }

                LiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                HasPendingOrders = false;

                if (Main.Verbose)
                    Main.LogWriter.Write($"OnConfirm state {ShortCode} {Name} {LiveOrders.Count} {NormalBalance} {BalanceAvailableToSell} {AverageBuyPrice} {originalOrderId}");
            }

            if (liveOrder != null)
            {
                LiveOrders.Add(liveOrder);
                if (originalOrderId == 0 && liveOrder.AskBidType == AskBidType.Ask)
                {
                    HasPendingAskOrder = false;
                    BalanceAvailableToSell -= liveOrder.OrderQuantity;
                }
                else if (originalOrderId == 0 && liveOrder.AskBidType == AskBidType.Bid)
                    HasPendingBidOrder = false;

                if (Main.Verbose)
                    Main.LogWriter.Write($"OnConfirm NEW state {ShortCode} {Name} {LiveOrders.Count} {NormalBalance} {BalanceAvailableToSell} {AverageBuyPrice} {liveOrder.OrderId} {originalOrderId}");
            }

            Main.OnConfirm(this);
        }

        public void OnReject(string orderCategoryCode, AskBidType askBidType)
        {
            if (orderCategoryCode == "2" || orderCategoryCode == "3")
                HasPendingOrders = false;
            else if (orderCategoryCode == "1")
            {
                if (askBidType == AskBidType.Ask)
                    HasPendingAskOrder = false;
                else if (askBidType == AskBidType.Bid)
                    HasPendingBidOrder = false;
            }

            Main.LogWriter.Write($"OnReject {ShortCode} {Name} {orderCategoryCode} {askBidType} {HasPendingBidOrder} {HasPendingAskOrder} {HasPendingOrders}");
        }

        public void UpdateLiveOrders(LiveOrder liveOrder)
        {
            LiveOrders.Add(liveOrder);

            if (Main.Verbose)
                Main.LogWriter.Write($"UpdateLiveOrders {ShortCode} {Name} {liveOrder.AskBidType} {liveOrder.Price} @ {liveOrder.OrderQuantity}({liveOrder.LiveQuantity})");
        }

        public void Reset()
        {
            LiveOrders.Clear();
            this.NormalBalance = 0;
            this.BalanceAvailableToSell = 0;
            this.AverageBuyPrice = 0;
        }

        public void UpdatePreviousDayBalance(long normalBalance, long averageBuyPrice)
        {
            this.PreviousDayBalance = normalBalance;
            this.PreviousDayAverageBuyPrice = averageBuyPrice;
        }

        public void UpdateBalanceFromIndi(long normalBalance, long balanceAvailableToSell, long averageBuyPrice)
        {
            //NormalBalance = normalBalance;
            //BalanceAvailableToSell = balanceAvailableToSell;
            //AverageBuyPrice = averageBuyPrice;

            //Main.LogWriter.Write($"AD INDI {ShortCode} {HasPendingBidOrder} {HasPendingAskOrder} {HasPendingOrders} {CurrentPrice} {LiveOrders.Count} {NormalBalance} {BalanceAvailableToSell} {AverageBuyPrice}");
        }

        public void UpdateBalanceFromTops(long normalBalance, long balanceAvailableToSell, long averageBuyPrice)
        {
            if (normalBalance > this.NormalBalance)
                DelayTime = DateTime.Now;

            this.NormalBalance = normalBalance;
            this.BalanceAvailableToSell = balanceAvailableToSell;
            this.AverageBuyPrice = averageBuyPrice;

            if (Main.Verbose)
                Main.LogWriter.Write($"AD TOPS {ShortCode} {Name} {LiveOrders.Count} {NormalBalance} {BalanceAvailableToSell} {AverageBuyPrice}");
        }

        public void NewOrder(AskBidType askBidType, long price, long quantity, OrderType orderType, OrderCondition orderCondition)
        {
            if (!Enabled)
                return;

            if (askBidType == AskBidType.Bid && HasPendingBidOrder)
                return;

            if (askBidType == AskBidType.Ask)
            {
                if (HasPendingAskOrder || !IsSellable())
                    return;
            }

            if (askBidType == AskBidType.Bid)
                HasPendingBidOrder = true;
            else if (askBidType == AskBidType.Ask)
            {
                HasPendingAskOrder = true;
                DelayTime = DateTime.Now;
            }

            OrderStruct.OrderStructType = OrderStructType.New;
            OrderStruct.Order = new Order(StandardCode, ShortCode, askBidType, price, quantity, orderType, orderCondition);
            Main.OrderQueue.Enqueue(OrderStruct);
        }

        public void AmendOrder(LiveOrder liveOrder, long price)
        {
            if (!Enabled)
                return;

            if (HasPendingOrders)
                return;

            HasPendingOrders = true;
            OrderStruct.OrderStructType = OrderStructType.Amend;
            OrderStruct.LiveOrder = liveOrder;
            OrderStruct.AmendedPrice = price;
            Main.OrderQueue.Enqueue(OrderStruct);
        }

        public void CancelOrder(LiveOrder liveOrder)
        {
            if (!Enabled)
                return;

            if (HasPendingOrders)
                return;

            HasPendingOrders = true;
            OrderStruct.OrderStructType = OrderStructType.Cancel;
            OrderStruct.LiveOrder = liveOrder;
            Main.OrderQueue.Enqueue(OrderStruct);
        }

        public void CancelAllOrders()
        {
            if (!Enabled)
                return;

            if (!LiveOrders.Any() || HasPendingOrders)
                return;

            HasPendingOrders = true;
            foreach (var liveOrder in LiveOrders.ToList())
            {
                OrderStruct.OrderStructType = OrderStructType.Cancel;
                OrderStruct.LiveOrder = liveOrder;
                Main.OrderQueue.Enqueue(OrderStruct);
            }
        }

        public void CancelOrders(AskBidType askBidType)
        {
            if (!Enabled)
                return;

            if (HasPendingOrders)
                return;

            if (!LiveOrders.Any(x => x.AskBidType == askBidType))
                return;

            HasPendingOrders = true;
            foreach (var liveOrder in LiveOrders.Where(x => x.AskBidType == askBidType).ToList())
            {
                OrderStruct.OrderStructType = OrderStructType.Cancel;
                OrderStruct.LiveOrder = liveOrder;
                Main.OrderQueue.Enqueue(OrderStruct);
            }
        }
    }
}
