﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PnK_indi
{
    public class DerivState
    {
        private MainWindow Main;
        private ICommHelper CommHelper { get; set; }
        private TypeConverter C { get; set; }
        public DerivPriceHelper PriceHelper { get; private set; }

        public string StandardCode { get; private set; }
        public string ShortCode { get; private set; }
        public string UnderlyingAssetShortCode { get; private set; }
        public string Name { get; private set; }
        public MarketType MarketType { get; private set; }
        public double Multiplier { get; private set; }
        public string ExpiryDate { get; private set; }

        public IFMSRPD0037 Execution5;
        public IFMSRPD0034 Quote5;

        public IFMSRPD0038 Execution10;
        public IFMSRPD0035 Quote10;

        public double OpenPrice { get; private set; }
        public double HighPrice { get; private set; }
        public double LowPrice { get; private set; }
        public double CurrentPrice { get; private set; }
        public DerivQuote[] Quote { get; private set; }

        public List<DerivLiveOrder> LiveOrders { get; private set; }
        public long NormalBalance { get; private set; }
        public double AveragePrice { get; private set; }
        private bool HasPendingBidOrder { get; set; }
        private bool HasPendingAskOrder { get; set; }
        private bool HasPendingOrders { get; set; }

        private bool Enabled { get; set; }
        private bool IsCleared { get; set; }

        private DerivOrderStruct OrderStruct = new DerivOrderStruct();


        public DerivState(MainWindow main, ICommHelper commHelper, string standardCode, string shortCode, string name, double multiplier, string expiryDate)
        {
            this.Main = main;
            this.CommHelper = commHelper;
            this.C = new TypeConverter();
            this.PriceHelper = new DerivPriceHelper(shortCode);

            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.Name = name;
            this.Multiplier = multiplier;
            this.ExpiryDate = expiryDate;

            if (shortCode.StartsWith("101"))
            {
                this.MarketType = MarketType.KospiFuture;
            }
            else if (shortCode.StartsWith("106"))
            {
                this.MarketType = MarketType.KosdaqFuture;
            }

            this.LiveOrders = new List<DerivLiveOrder>();
            OrderStruct.StandardCode = StandardCode;
        }

        public DerivState(MainWindow main, ICommHelper commHelper, string standardCode, string shortCode, string name, double multiplier, string expiryDate, string underlyingAssetShortCode)
        {
            this.Main = main;
            this.CommHelper = commHelper;
            this.C = new TypeConverter();
            this.PriceHelper = new DerivPriceHelper(shortCode);

            this.StandardCode = standardCode;
            this.ShortCode = shortCode;
            this.Name = name;
            this.Multiplier = multiplier;
            this.ExpiryDate = expiryDate;
            this.UnderlyingAssetShortCode = underlyingAssetShortCode;

            if (shortCode.StartsWith("1"))
            {
                this.MarketType = MarketType.StockFuture;
            }

            this.LiveOrders = new List<DerivLiveOrder>();
            OrderStruct.StandardCode = StandardCode;
        }

        public void Enable()
        {
            Enabled = true;

            IsCleared = false;
            HasPendingBidOrder = false;
            HasPendingAskOrder = false;
            HasPendingOrders = false;
        }

        public bool IsEnabled() => Enabled;

        public void Disable()
        {
            Enabled = false;
        }

        public void ResetPendingOrder(AskBidType? askBidType)
        {
            if (askBidType == AskBidType.Bid)
                HasPendingBidOrder = false;
            else if (askBidType == AskBidType.Ask)
                HasPendingAskOrder = false;
            else
                HasPendingOrders = false;
        }

        public void Clear()
        {
            IsCleared = true;

            if (NormalBalance == 0 && !LiveOrders.Any())
            {
                Disable();
                return;
            }

            if (HasPendingAskOrder || HasPendingOrders)
                return;

            if (LiveOrders.Any())
            {
                CancelAllOrders();
                return;
            }
            else if (NormalBalance != 0)
            {
                var askBidType = NormalBalance > 0 ? AskBidType.Ask : AskBidType.Bid;
                var orderPrice = NormalBalance > 0 ? CurrentPrice - PriceHelper.GetTickSize(CurrentPrice) * 10 : CurrentPrice + PriceHelper.GetTickSize(CurrentPrice) * 10;
                var orderQuantity = Math.Abs(NormalBalance);

                NewOrder(askBidType, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
            }
        }

        public void UpdateQuotes(IFMSRPD0037 m)
        {
            this.Execution5 = m;
            this.OpenPrice = C.AsDouble(Execution5.OpenPrice);
            this.HighPrice = C.AsDouble(Execution5.HighPrice);
            this.LowPrice = C.AsDouble(Execution5.LowPrice);
            this.CurrentPrice = C.AsDouble(Execution5.TradingPrice);
            this.Quote = Execution5.Quote;

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Execution, this);
        }

        public void UpdateQuotes(IFMSRPD0038 m)
        {
            this.Execution10 = m;
            this.OpenPrice = C.AsDouble(Execution10.OpenPrice);
            this.HighPrice = C.AsDouble(Execution10.HighPrice);
            this.LowPrice = C.AsDouble(Execution10.LowPrice);
            this.CurrentPrice = C.AsDouble(Execution10.TradingPrice);
            this.CurrentPrice = C.AsDouble(m.TradingPrice);
            this.Quote = m.Quote;

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Execution, this);
        }

        public void UpdateQuotes(IFMSRPD0034 m)
        {
            this.Quote5 = m;
            this.Quote = Quote5.Quote;

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Quote, this);
        }

        public void UpdateQuotes(IFMSRPD0035 m)
        {
            this.Quote10 = m;
            this.Quote = m.Quote;

            if (IsCleared)
            {
                Clear();
                return;
            }

            Main.UpdateQuotes(RealTimeDataType.Quote, this);
        }

        public void OnExecution(long orderId, double price, long quantity)
        {
            if (LiveOrders.Exists(x => x.OrderId == orderId))
            {
                var filledLiveOrder = LiveOrders.Find(x => x.OrderId == orderId);
                filledLiveOrder.UpdateLiveQuantity(quantity);

                var signedQuantity = filledLiveOrder.AskBidType == AskBidType.Ask ? -quantity : quantity;

                if (NormalBalance * signedQuantity > 0)
                {
                    AveragePrice = (AveragePrice * NormalBalance + price * signedQuantity) / (NormalBalance + signedQuantity);
                    NormalBalance += signedQuantity;
                }
                else if (NormalBalance * signedQuantity < 0)
                {
                    NormalBalance += signedQuantity;

                    if (NormalBalance * signedQuantity > 0)
                        AveragePrice = price;
                    else if (NormalBalance == 0)
                        AveragePrice = 0;
                }
                else
                {
                    NormalBalance += signedQuantity;
                    AveragePrice = price;
                }

                LiveOrders.RemoveAll(x => x.LiveQuantity <= 0);
                Main.LogWriter.Write($"OnExecution   {ShortCode} {NormalBalance} {AveragePrice}");
            }
            else
            {
                Main.LogWriter.Write($"OnExecution there is no orderId {orderId} in LiveOrders");
            }

            Main.LogWriter.Write($"OnExecution state {DateTime.Now.ToString("HH:mm:ss.fff")} {StandardCode} {HasPendingBidOrder} {HasPendingAskOrder} {HasPendingOrders} {LiveOrders.Count} {NormalBalance} {orderId}");
            Main.OnExecution(this);
        }

        public void OnConfirm(long originalOrderId, DerivLiveOrder liveOrder)
        {
            if (originalOrderId != 0)
            {
                LiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                HasPendingOrders = false;
                Main.LogWriter.Write($"OnConfirm state {DateTime.Now.ToString("HH:mm:ss.fff")} {StandardCode} {HasPendingBidOrder} {HasPendingAskOrder} {HasPendingOrders} {LiveOrders.Count} {NormalBalance} {originalOrderId}");
            }

            if (liveOrder != null)
            {
                LiveOrders.Add(liveOrder);
                if (originalOrderId == 0 && liveOrder.AskBidType == AskBidType.Ask)
                    HasPendingAskOrder = false;
                else if (originalOrderId == 0 && liveOrder.AskBidType == AskBidType.Bid)
                    HasPendingBidOrder = false;

                Main.LogWriter.Write($"OnConfirm NEW state {StandardCode} {HasPendingBidOrder} {HasPendingAskOrder} {HasPendingOrders} {LiveOrders.Count} {NormalBalance} {liveOrder.OrderId} {originalOrderId}");
            }

            Main.OnConfirm(this);
        }

        public void OnReject(string orderCategoryCode, AskBidType askBidType)
        {
            if (orderCategoryCode == "2" || orderCategoryCode == "3")
                HasPendingOrders = false;
            else if (orderCategoryCode == "1")
            {
                if (askBidType == AskBidType.Ask)
                    HasPendingAskOrder = false;
                else if (askBidType == AskBidType.Bid)
                    HasPendingBidOrder = false;
            }
        }

        public void UpdateLiveOrders(DerivLiveOrder liveOrder)
        {
            LiveOrders.Add(liveOrder);
        }

        public void UpdateBalance(long normalBalance, double averagePrice)
        {
            this.NormalBalance = normalBalance;
            this.AveragePrice = averagePrice;

            Main.LogWriter.Write($"UpdateBalance {StandardCode} {ShortCode} {NormalBalance} {averagePrice}");
        }

        public void NewOrder(AskBidType askBidType, double price, long quantity, OrderType orderType, OrderCondition orderCondition)
        {
            if (HasPendingBidOrder && askBidType == AskBidType.Bid)
                return;

            if (HasPendingAskOrder && askBidType == AskBidType.Ask)
                return;

            if (askBidType == AskBidType.Bid)
                HasPendingBidOrder = true;
            else if (askBidType == AskBidType.Ask)
                HasPendingAskOrder = true;

            OrderStruct.OrderStructType = OrderStructType.New;
            OrderStruct.Order = new DerivOrder(StandardCode, askBidType, price, quantity, orderType, orderCondition);
            Main.OrderQueue.Enqueue(OrderStruct);
        }

        public void AmendOrder(DerivLiveOrder liveOrder, long price)
        {
            if (HasPendingOrders)
                return;

            //HasPendingOrders = true;
            //if (CommHelper.AmendOrder(liveOrder, price) < 0)
            //    HasPendingOrders = false;
        }

        public void CancelOrder(DerivLiveOrder liveOrder)
        {
            if (HasPendingOrders)
                return;

            HasPendingOrders = true;
            OrderStruct.OrderStructType = OrderStructType.Cancel;
            OrderStruct.LiveOrder = liveOrder;
            Main.OrderQueue.Enqueue(OrderStruct);
        }

        public void CancelAllOrders()
        {
            if (!LiveOrders.Any() || HasPendingOrders)
                return;

            HasPendingOrders = true;
            foreach (var liveOrder in LiveOrders.ToList())
            {
                OrderStruct.OrderStructType = OrderStructType.Cancel;
                OrderStruct.LiveOrder = liveOrder;
                Main.OrderQueue.Enqueue(OrderStruct);
            }
        }

        public void CancelOrders(AskBidType askBidType)
        {
            if (HasPendingOrders)
                return;

            if (!LiveOrders.Any(x => x.AskBidType == askBidType))
                return;

            HasPendingOrders = true;
            foreach (var liveOrder in LiveOrders.Where(x => x.AskBidType == askBidType))
            {
                OrderStruct.OrderStructType = OrderStructType.Cancel;
                OrderStruct.LiveOrder = liveOrder;
                Main.OrderQueue.Enqueue(OrderStruct);
            }
        }

        private static bool DoubleEquals(double d1, double d2) => Math.Abs(d1 - d2) < Math.Pow(10, -8);
        private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
        private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);
    }
}
