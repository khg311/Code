﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.Linq;
using AxGIExpertControl64Lib;

namespace PnK_indi
{
    public partial class MainWindow : Form
    {
        #region TopsAPI dll functions
        [DllImport("Tops2API.dll")]
        public static extern bool InitAPI(IntPtr hWnd);

        [DllImport("Tops2API.dll")]
        public static extern void ExitAPI();

        [DllImport("Tops2API.dll")]
        public static extern IntPtr GetLoginID();

        [DllImport("Tops2API.dll")]
        public static extern void RegistRealStockOrders(IntPtr hWnd);

        [DllImport("Tops2API.dll")]
        public static extern void RegistRealOrders(IntPtr hWnd);
        #endregion

        public ICommHelper CommHelper;
        public ISiseHelper SiseHelper;
        public Safety Safety;
        public LogWriter LogWriter;
        public int n_mKey = -1;

        public DateTime MarketOpenTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
        public DateTime MarketCloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);

        public Dictionary<string, StockState> States = new Dictionary<string, StockState>();
        public List<LiveOrder> LiveOrders = new List<LiveOrder>();

        public Dictionary<string, DerivState> DerivStates = new Dictionary<string, DerivState>();
        public List<DerivLiveOrder> DerivLiveOrders = new List<DerivLiveOrder>();

        public List<Balance> StockBalances = new List<Balance>();
        public List<string> FundCodes = new List<string>();
        public Dictionary<string, AlgoInfo> AlgoInfos = new Dictionary<string, AlgoInfo>();

        public TypeConverter C = new TypeConverter();

        public Thread OrderThread;
        public ConcurrentQueue<object> OrderQueue = new ConcurrentQueue<object>();

        public Thread QuoteThread;
        public ConcurrentQueue<object> QuoteQueue = new ConcurrentQueue<object>();

        public Thread LogWriterThread;
        public ConcurrentQueue<string> LogQueue = new ConcurrentQueue<string>();
        private readonly string logDirectory = "C:/AlgoLogs";

        private (bool Initialized, DateTime Time) InitSystem;
        private bool IsStrategyInitialized;
        public string EmployeeId = "";
        public string FundCode = "";
        public bool Verbose = true;

        public long FundBalanceAmount;
        public List<string> Prohibited = new List<string>();
        public List<string> Disables = new List<string>();
        public List<string> Borrowings = new List<string>();

        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_Connector = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockBatchGetter = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_IndexFutureBatchGetter = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockFuturesBatchGetter = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockBalanceRTReceiver = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_DerivBalanceRTReceiver = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_FuturesBalanceGetter = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_ViRTReceiver = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_FundRegister = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockBalanceGetter = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockRightsReceiver = new AxGIExpertControl64Lib.AxGIExpertControl64();

        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_TestControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_InitStockBalance = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_InitStockLiveOrders = new AxGIExpertControl64Lib.AxGIExpertControl64();

        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_InitFuturesBalance = new AxGIExpertControl64Lib.AxGIExpertControl64();
        public AxGIExpertControl64Lib.AxGIExpertControl64 Indi_InitFuturesLiveOrders = new AxGIExpertControl64Lib.AxGIExpertControl64();

        public bool isReady = false;
        public bool ClickedRunButton = false;

        private IndexFutureVoltyV1 _indexFutureVoltyV1;
        private StockRsiReversion _stockRsiReversion;
        private StockVoltyBreakLargeCap _stockVoltyBreak;
        private StockVoltyBreakMidCap _stockVoltyBreakMidCap;

        private StockFuturesPairRsi _stockFuturesPairRsi;
        private StockFuturesPairStd _stockFuturesPairStd;
        private StockRsiSwing _stockRsiSwing;
        private StockFuturesBasis _stockFuturesBasis;
        private IndexFuturePairIntraBreak _indexFuturePairIntraBreak;
        private IndexFuturesHLBreak _IndexFuturesHLBreak;


        public MainWindow()
        {
            InitializeComponent();
            this.Safety = new Safety(this);

            LogWriter = new LogWriter(logDirectory, this);
            LogWriterThread = new Thread(() => OnWriteLogs());
            LogWriterThread.Start();

            SingleOrderAmountLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleOrderAmountLimit);
            SingleAssetPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleAssetPositionLimit);
            FundPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.FundPositionLimit);
            IntervalTextBox.Text = C.AsString(Safety.Interval);
            OrderNumberLimitTextBox.Text = C.AsString(Safety.OrderNumberLimit);

            DisableView.ColumnCount = 3;
            DisableView.Columns[0].Name = "No";
            DisableView.Columns[0].Width = 30;
            DisableView.Columns[1].Name = "종목코드";
            DisableView.Columns[1].Width = 100;
            DisableView.Columns[2].Name = "종목명";

            Open9Close15RadioButton.Checked = true;
        }

        private void Indi_ReceivedStockBatchData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var nCount = C.AsInt(Indi_StockBatchGetter.GetMultiRowCount());

            for (short i = 0; i < nCount; i++)
            {
                var standardCode = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 0));
                var shortCode = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 1));
                var name = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 5)).Trim();
                var marketType = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 2)) == "0" ? MarketType.Kospi : MarketType.Kosdaq;
                var securityGroupId = (SecurityGroupId)Enum.Parse(typeof(SecurityGroupId), C.AsString(Indi_StockBatchGetter.GetMultiData(i, 19)));
                var previousDayPrice = C.AsLong(Indi_StockBatchGetter.GetMultiData(i, 23));
                var upperLimitPrice = C.AsLong(Indi_StockBatchGetter.GetMultiData(i, 27));
                var lowerLimitPrice = C.AsLong(Indi_StockBatchGetter.GetMultiData(i, 28));
                var isSuspended = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 30));
                var isAdministrated = C.AsString(Indi_StockBatchGetter.GetMultiData(i, 31));
                var priceAdjustment = (PriceAdjustment)C.AsInt(Indi_StockBatchGetter.GetMultiData(i, 33));
                var outstandingShares = C.AsLong(Indi_StockBatchGetter.GetMultiData(i, 18));
                var previousDayTradingAmount = C.AsLong(Indi_StockBatchGetter.GetMultiData(i, 25));

                if (Borrowings.Contains(shortCode) || outstandingShares < 1_000_000 || isSuspended != "0" || isAdministrated == "1")
                    continue;

                if (name.StartsWith("신한") || name.StartsWith("제주은행"))
                    continue;

                var state = new StockState(this, CommHelper, standardCode, shortCode, name, marketType, securityGroupId, previousDayPrice, outstandingShares, previousDayTradingAmount, upperLimitPrice, lowerLimitPrice, priceAdjustment);
                States[standardCode] = state;
                States[shortCode] = state;

                if (Prohibited.Contains(shortCode))
                    state.Disable();

                Indi_ViRTReceiver.RequestRTReg("SY", shortCode);
            }

            Indi_StockBalanceRTReceiver.RequestRTReg("AD", "*");

            Indi_IndexFutureBatchGetter.SetQueryName("fut_mst");
            Indi_IndexFutureBatchGetter.RequestData();
        }

        private void Indi_ReceivedIndexFutureBatchData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var nCount = C.AsInt(Indi_IndexFutureBatchGetter.GetMultiRowCount());

            for (short i = 0; i < nCount; i++)
            {
                var standardCode = C.AsString(Indi_IndexFutureBatchGetter.GetMultiData(i, 0));
                var shortCode = C.AsString(Indi_IndexFutureBatchGetter.GetMultiData(i, 1)).PadRight(8, '0');
                var name = C.AsString(Indi_IndexFutureBatchGetter.GetMultiData(i, 2));
                var expiryDate = C.AsString(Indi_IndexFutureBatchGetter.GetMultiData(i, 7));
                var multiplier = C.AsDouble(Indi_IndexFutureBatchGetter.GetMultiData(i, 9));

                var state = new DerivState(this, CommHelper, standardCode, shortCode, name, multiplier, expiryDate);
                DerivStates[standardCode] = state;
                DerivStates[shortCode] = state;
            }

            Indi_StockFuturesBatchGetter.SetQueryName("sfut_mst");
            Indi_StockFuturesBatchGetter.RequestData();
        }

        private void Indi_ReceivedStockFuturesBatchData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var nCount = C.AsInt(Indi_StockFuturesBatchGetter.GetMultiRowCount());

            for (short i = 0; i < nCount; i++)
            {
                var standardCode = C.AsString(Indi_StockFuturesBatchGetter.GetMultiData(i, 0));
                var shortCode = C.AsString(Indi_StockFuturesBatchGetter.GetMultiData(i, 1)).PadRight(8, '0');
                var name = C.AsString(Indi_StockFuturesBatchGetter.GetMultiData(i, 3));

                var expiryDate = C.AsString(Indi_StockFuturesBatchGetter.GetMultiData(i, 7));
                var underlyingAssetShortCode = C.AsString(Indi_StockFuturesBatchGetter.GetMultiData(i, 8));

                var state = new DerivState(this, CommHelper, standardCode, shortCode, name, 10.0, expiryDate, underlyingAssetShortCode);
                DerivStates[standardCode] = state;
                DerivStates[shortCode] = state;
            }

            LiveOrders.Clear();
            DerivLiveOrders.Clear();

            foreach (var fundCode in FundCodes)
            {
                // get stock balance
                CommHelper.RequestQ80001(n_mKey, fundCode, EmployeeId);
                // get stock live orders
                CommHelper.RequestQ70001(n_mKey, EmployeeId, fundCode);
                //get kospi futures balance
                CommHelper.RequestQ40001(n_mKey, fundCode, EmployeeId);
                // get kospi futures live orders
                CommHelper.RequestQ30003(n_mKey, EmployeeId, fundCode);
                //get kosdaq futures balance
                CommHelper.RequestQ46001(n_mKey, fundCode, EmployeeId);
                // get kosdaq futures live orders
                CommHelper.RequestQ36001(n_mKey, EmployeeId, fundCode);
                // get stock futures balance
                CommHelper.RequestQ42001(n_mKey, fundCode, EmployeeId);
                // get stock futures live orders
                CommHelper.RequestQ32001(n_mKey, EmployeeId, fundCode);
            }

            InitSystem = (true, DateTime.Now);
        }

        private void Indi_ReceivedRTStockBalances(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveRTDataEvent e)
        {
            var shortCode = C.AsString(Indi_StockBalanceRTReceiver.GetSingleData(2));
            var fundCode = C.AsString(Indi_StockBalanceRTReceiver.GetSingleData(0)).Substring(11 - 4);
            
            if (fundCode == FundCode && States.TryGetValue(shortCode, out var state))
            {
                var normalBalance = C.AsLong(Indi_StockBalanceRTReceiver.GetSingleData(6));
                var balanceAvailableToSell = C.AsLong(Indi_StockBalanceRTReceiver.GetSingleData(8));
                var averageBuyPrice = C.AsLong(Indi_StockBalanceRTReceiver.GetSingleData(7));

                FundBalanceAmount -= state.NormalBalance * state.AverageBuyPrice;
                state.UpdateBalanceFromIndi(normalBalance, balanceAvailableToSell, averageBuyPrice);
                FundBalanceAmount += state.NormalBalance * state.AverageBuyPrice;
                FundBalanceAmountTextBox.Text = string.Format("{0:#,0}", FundBalanceAmount);
            }
        }

        private void Indi_ReceivedRTVolatilityInterruption(object send, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveRTDataEvent e)
        {
            var standardCode = C.AsString(Indi_ViRTReceiver.GetSingleData(0));
            var viCategoryCode = C.AsString(Indi_ViRTReceiver.GetSingleData(5));
            if (States.TryGetValue(standardCode, out var state))
                state.UpdateVolatilityInterruption(viCategoryCode);
        }

        private void Indi_ReceivedFundRegistration(object send, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            Indi_StockBalanceGetter.SetQueryName("SCBA321Q1");
            Indi_StockBalanceGetter.SetSingleData(0, DateTime.Now.AddDays(-1).ToString("yyyyMMdd"));
            Indi_StockBalanceGetter.SetSingleData(1, FundCode);
            Indi_StockBalanceGetter.SetSingleData(2, "");
            Indi_StockBalanceGetter.SetSingleData(3, "1");
            Indi_StockBalanceGetter.SetSingleData(4, "0");
            Indi_StockBalanceGetter.SetSingleData(5, "3");
            Indi_StockBalanceGetter.SetSingleData(6, "744");
            Indi_StockBalanceGetter.RequestData();
        }

        private void Indi_ReceivedStockBalances(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var nCount = C.AsInt(Indi_StockBalanceGetter.GetMultiRowCount());

            for (short i = 0; i < nCount; i++)
            {
                var fundCode = C.AsString(Indi_StockBalanceGetter.GetMultiData(i, 1));
                var shortCode = C.AsString(Indi_StockBalanceGetter.GetMultiData(i, 3)).Replace("A", "");
                var normalBalance = C.AsLong(Indi_StockBalanceGetter.GetMultiData(i, 5));
                var averageBuyPrice = C.AsLong(Indi_StockBalanceGetter.GetMultiData(i, 7));

                if (FundCode == fundCode && States.TryGetValue(shortCode, out var state))
                    state.UpdatePreviousDayBalance(normalBalance, averageBuyPrice);
            }

            Indi_FuturesBalanceGetter.SetQueryName("SCBC222Q1");
            Indi_FuturesBalanceGetter.SetSingleData(0, FundCode);
            Indi_FuturesBalanceGetter.SetSingleData(1, "0");
            Indi_FuturesBalanceGetter.SetSingleData(2, DateTime.Now.ToString("yyyyMMdd"));
            Indi_FuturesBalanceGetter.SetSingleData(3, "744");
            Indi_FuturesBalanceGetter.RequestData();
        }

        private void Indi_ReceivedFuturesBalances(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            var nCount = C.AsInt(Indi_FuturesBalanceGetter.GetMultiRowCount());

            for (short i = 0; i < nCount; i++)
            {
                var fundCode = C.AsString(Indi_FuturesBalanceGetter.GetMultiData(i, 0));
                var issueCode = C.AsString(Indi_FuturesBalanceGetter.GetMultiData(i, 1)) + "000";
                var name = C.AsString(Indi_FuturesBalanceGetter.GetMultiData(i, 2));
                var askBidType = C.AsString(Indi_FuturesBalanceGetter.GetMultiData(i, 3)) == "매도" ? AskBidType.Ask : AskBidType.Bid;
                var quantity = C.AsLong(Indi_FuturesBalanceGetter.GetMultiData(i, 4));
                var vwap = C.AsDouble(Indi_FuturesBalanceGetter.GetMultiData(i, 5));

                if (fundCode == FundCode)
                {
                    if (DerivStates.TryGetValue(issueCode, out var state))
                    {
                        quantity = askBidType == AskBidType.Ask ? -quantity : quantity;
                        state.UpdateBalance(quantity, vwap);
                        Console.WriteLine($"futures balances {issueCode} {name} {vwap} {quantity}");
                    }
                }
            }
        }

        ///
        private void StartWorkerButton_Click(object sender, EventArgs e)
        {
            if (ClickedRunButton)
                return;

            Indi_Connector.CreateControl();

            if (Indi_Connector.GetCommState() != 0)
            {
                MainLog("indi should be connected");
                return;
            }

            if (InitSystem.Initialized)
            {
                MainLog("system is already running");
                return;
            }

            ClickedRunButton = true;

            if (InitAPI(this.Handle))
            {

                _stockRsiReversion = new StockRsiReversion(this);
                _indexFutureVoltyV1 = new IndexFutureVoltyV1(this);
                _stockVoltyBreak = new StockVoltyBreakLargeCap(this);
                _stockVoltyBreakMidCap = new StockVoltyBreakMidCap(this);

                _stockFuturesPairRsi = new StockFuturesPairRsi(this);
                _stockFuturesPairStd = new StockFuturesPairStd(this);
                _stockRsiSwing = new StockRsiSwing(this);
                _stockFuturesBasis = new StockFuturesBasis(this);
                _indexFuturePairIntraBreak = new IndexFuturePairIntraBreak(this);
                _IndexFuturesHLBreak = new IndexFuturesHLBreak(this);

                #region Initiate Indi Ax Controls

                Indi_StockBatchGetter.CreateControl();
                Indi_StockBatchGetter.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedStockBatchData);

                Indi_IndexFutureBatchGetter.CreateControl();
                Indi_IndexFutureBatchGetter.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedIndexFutureBatchData);

                Indi_StockFuturesBatchGetter.CreateControl();
                Indi_StockFuturesBatchGetter.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedStockFuturesBatchData);

                Indi_StockBalanceRTReceiver.CreateControl();
                Indi_StockBalanceRTReceiver.ReceiveRTData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveRTDataEventHandler(this.Indi_ReceivedRTStockBalances);

                Indi_ViRTReceiver.CreateControl();
                Indi_ViRTReceiver.ReceiveRTData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveRTDataEventHandler(this.Indi_ReceivedRTVolatilityInterruption);

                Indi_FuturesBalanceGetter.CreateControl();
                Indi_FuturesBalanceGetter.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedFuturesBalances);

                Indi_StockBalanceGetter.CreateControl();
                Indi_StockBalanceGetter.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedStockBalances);

                #endregion

                CommHelper = new ICommHelper(this);
                SiseHelper = new ISiseHelper();

                OrderThread = new Thread(() => OnSendingOrdersAsync());
                OrderThread.Start();

                QuoteThread = new Thread(() => OnUpdatingQuotesAsync());
                QuoteThread.Start();

                n_mKey = CommHelper.AddHwnd(this.Handle, "API_Sample");
                RegistRealStockOrders(this.Handle);
                RegistRealOrders(this.Handle);
                EmployeeId = Marshal.PtrToStringAnsi(GetLoginID(), LENGTH.EMP_NO_LEN);
                EmployeeIdTextBox.Text = EmployeeId;

                CommHelper.RequestQ90025(n_mKey, EmployeeId);
                CommHelper.RequestQ90056(n_mKey);

                Indi_StockBatchGetter.SetQueryName("TR_RB001");
                Indi_StockBatchGetter.SetSingleData(0, "0");
                Indi_StockBatchGetter.RequestData();
            }
        }
        /// <summary>
        /// 주문관련 정보가 있는 OrderQueue에서 주문정보가 들어왔다면, 들어온순서대로 orderStruct 에 저장하여 ResetPendingOrder 처리를 하는 함수
        /// 
        /// </summary>
        private void OnSendingOrdersAsync()
        {
            while (true)
            {
                if (OrderQueue.TryDequeue(out object orderStruct))
                {
                    if (orderStruct.GetType() == typeof(StockOrderStruct))
                    {
                        var _orderStruct = (StockOrderStruct)orderStruct;
                        if (States.TryGetValue(_orderStruct.StandardCode, out var state))
                        {
                            if (_orderStruct.OrderStructType == OrderStructType.New)
                            {
                                if (CommHelper.NewOrder(_orderStruct.Order) < 0)
                                    state.ResetPendingOrder(_orderStruct.Order.AskBidType);
                            }
                            else if (_orderStruct.OrderStructType == OrderStructType.Amend)
                            {
                                if (CommHelper.AmendOrder(_orderStruct.LiveOrder, _orderStruct.AmendedPrice) < 0)
                                    state.ResetPendingOrder(null);
                            }
                            else if (_orderStruct.OrderStructType == OrderStructType.Cancel)
                            {
                                if (CommHelper.CancelOrder(_orderStruct.LiveOrder) < 0)
                                    state.ResetPendingOrder(null);
                            }
                        }
                    }
                    else if (orderStruct.GetType() == typeof(DerivOrderStruct))
                    {
                        var _orderStruct = (DerivOrderStruct)orderStruct;
                        if (DerivStates.TryGetValue(_orderStruct.StandardCode, out var state))
                        {
                            if (_orderStruct.OrderStructType == OrderStructType.New)
                            {
                                if (CommHelper.NewOrder(_orderStruct.Order) < 0)
                                    state.ResetPendingOrder(_orderStruct.Order.AskBidType);
                            }
                            else if (_orderStruct.OrderStructType == OrderStructType.Cancel)
                            {
                                if (CommHelper.CancelOrder(_orderStruct.LiveOrder) < 0)
                                    state.ResetPendingOrder(null);
                            }
                        }
                    }
                }
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM.WM_COPY_DATA)
                OnReceivedRTQuotes(m);
            else if (m.Msg == WM.WM_RECEIVED_DATA)
                OnReceivedData(m);
            else if (m.Msg == WM.WM_RECEIVED_ORDER_CHEGYUL)
                OnExecution(m);
            else if (m.Msg == WM.WM_RECEIVED_ORDER_CONFIRFM || m.Msg == WM.WM_RECEIVED_ORDER_REJECT)
                OnConfirm(m);
            else if (m.Msg == WM.WM_RECEIVED_ORDER_ACK)
                OnAck(m);

            base.WndProc(ref m);
        }

        private void OnReceivedRTQuotes(Message m)
        {
            var rawQuote = (COPYDATASTRUCT)m.GetLParam(typeof(COPYDATASTRUCT));

            if ((int)rawQuote.dwData != 8282)
                return;

            var dataType = Marshal.PtrToStringAnsi(rawQuote.lpData, 5);

            if (dataType == "A301S" || dataType == "A301Q" || dataType == "A302S" || dataType == "A303S" || dataType == "A304S")
            {
                IFMSRPD0004 message = (IFMSRPD0004)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0004));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "B601S" || dataType == "B601Q")
            {
                IFMSRPD0002 message = (IFMSRPD0002)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0002));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "B702S" || dataType == "B703S" || dataType == "B704S")
            {
                IFMSRPD0007 message = (IFMSRPD0007)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0007));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "G701F" || dataType == "G702F")
            {
                IFMSRPD0037 message = (IFMSRPD0037)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0037));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "B601F" || dataType == "B602F")
            {
                IFMSRPD0034 message = (IFMSRPD0034)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0034));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "G704F")
            {
                IFMSRPD0038 message = (IFMSRPD0038)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0038));
                QuoteQueue.Enqueue(message);
            }
            else if (dataType == "B604F")
            {
                IFMSRPD0035 message = (IFMSRPD0035)Marshal.PtrToStructure(rawQuote.lpData, typeof(IFMSRPD0035));
                QuoteQueue.Enqueue(message);
            }
        }
        /// <summary>
        /// 체결,호가데이터 정보가 있는 QuoteQueue 에서 
        /// </summary>
        private void OnUpdatingQuotesAsync()
        {
            while (true)
            {
                if (QuoteQueue.TryDequeue(out object message))
                {
                    if (message.GetType() == typeof(IFMSRPD0004))
                        OnIFMSRPD0004((IFMSRPD0004)message);
                    else if (message.GetType() == typeof(IFMSRPD0002))
                        OnIFMSRPD0002((IFMSRPD0002)message);
                    else if (message.GetType() == typeof(IFMSRPD0007))
                        OnIFMSRPD0007((IFMSRPD0007)message);
                    else if (message.GetType() == typeof(IFMSRPD0037))
                        OnIFMSRPD0037((IFMSRPD0037)message);
                    else if (message.GetType() == typeof(IFMSRPD0034))
                        OnIFMSRPD0034((IFMSRPD0034)message);
                    else if (message.GetType() == typeof(IFMSRPD0038))
                        OnIFMSRPD0038((IFMSRPD0038)message);
                    else if (message.GetType() == typeof(IFMSRPD0035))
                        ONIFMSRPD0035((IFMSRPD0035)message);
                }
            }
        }

        private void OnWriteLogs()
        {
            while (true)
            {
                if (LogQueue.TryDequeue(out string message))
                {
                    DirectoryInfo directoryInfo = new DirectoryInfo(LogWriter.DirPath);
                    LogWriter.FilePath = LogWriter.DirPath + $"/logs_{StrategyTextBox.Text}_" + DateTime.Now.ToString("yyyyMMdd") + ".log";
                    FileInfo fileInfo = new FileInfo(LogWriter.FilePath);
                    try
                    {
                        if (!directoryInfo.Exists) Directory.CreateDirectory(LogWriter.DirPath);
                        if (!fileInfo.Exists)
                        {
                            using (StreamWriter sw = new StreamWriter(LogWriter.FilePath))
                            {
                                sw.WriteLine(message);
                                Console.WriteLine(message);
                                sw.Close();
                            }
                        }
                        else
                        {
                            using (StreamWriter sw = File.AppendText(LogWriter.FilePath))
                            {
                                sw.WriteLine(message);
                                Console.WriteLine(message);
                                sw.Close();
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        string m = e.Message.ToString();
                        Console.WriteLine(m);
                    }
                }
            }
        }

        private void OnIFMSRPD0004(IFMSRPD0004 m)
        {
            if (States.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        private void OnIFMSRPD0002(IFMSRPD0002 m)
        {
            if (States.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        private void OnIFMSRPD0007(IFMSRPD0007 m)
        {
            if (States.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        private void OnIFMSRPD0037(IFMSRPD0037 m)
        {
            if (DerivStates.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        public void OnIFMSRPD0034(IFMSRPD0034 m)
        {
            if (DerivStates.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        private void OnIFMSRPD0038(IFMSRPD0038 m)
        {
            if (DerivStates.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        private void ONIFMSRPD0035(IFMSRPD0035 m)
        {
            if (DerivStates.TryGetValue(C.AsString(m.StandardCode), out var state))
                state.UpdateQuotes(m);
        }

        public void RequestA301S(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "A301S", this.Handle);
        }

        public void RequestB601S(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B601S", this.Handle);
        }

        public void RequestA301Q(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "A301Q", this.Handle);
        }

        public void RequestB601Q(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B601Q", this.Handle);
        }

        public void RequestA303S(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "A303S", this.Handle);
        }

        public void RequestB703S(string standardCode)
        {
            if (States.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B703S", this.Handle);
        }

        public void RequestG701F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "G701F", this.Handle);
        }

        public void RequestB601F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B601F", this.Handle);
        }

        public void RequestG702F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "G702F", this.Handle);
        }

        public void RequestB602F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B602F", this.Handle);
        }

        public void RequestG704F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "G704F", this.Handle);
        }

        public void RequestB604F(string standardCode)
        {
            if (DerivStates.TryGetValue(standardCode, out var state))
                SiseHelper.Regist(standardCode, "B604F", this.Handle);
        }

        private void OnReceivedData(Message m)
        {
            TR_HEADER header = (TR_HEADER)m.GetLParam(typeof(TR_HEADER));

            if (header.trgb[0] == '9')
                return;

            if (header.attr[0] != '2')
                return;

            var trCode = C.AsString(header.trcode);
            var ptr = m.LParam + Marshal.SizeOf(typeof(TR_HEADER));


            if (trCode == "Q80001")
                GetStockBalances(ptr);
            else if (trCode == "Q70001")
                GetStockLiveOrders(ptr);
            else if (trCode == "Q40001")
                GetKospiFuturesBalances(ptr);
            else if (trCode == "Q30003")
                GetKospiFuturesLiveOrders(ptr);
            else if (trCode == "Q46001")
                GetKosdaqFuturesBalances(ptr);
            else if (trCode == "Q36001")
                GetKosdaqFuturesLiveOrders(ptr);
            else if (trCode == "Q42001")
                GetStockFuturesBalances(ptr);
            else if (trCode == "Q32001")
                GetStockFuturesLiveOrders(ptr);
            else if (trCode == "Q90025")
                GetAccounts(ptr);
            else if (trCode == "Q90056")
                GetTheProhibited(ptr);
        }


        private void GetStockBalances(IntPtr ptr)
        {
            var _out = (OUT_Q80001)Marshal.PtrToStructure(ptr, typeof(OUT_Q80001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q80001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q80001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q80001_SUB));
                var standardCode = C.AsString(sub.expcode);
                var shortCode = C.AsString(sub.isu_cd).Trim();

                if (States.TryGetValue(standardCode, out var state))
                {
                    var fundCode = C.AsString(sub.fund_no);
                    var name = C.AsString(sub.isu_nm).Trim().Replace(" ", string.Empty);
                    var normalBalance = C.AsLong(sub.bk_qty);
                    var balanceAvailableToSell = C.AsLong(sub.sell_pos_qty);
                    var averageBuyPrice = C.AsLong(C.AsDouble(sub.bk_prc) / 100);
                    var borrowedBalance = C.AsLong(sub.loan_qty);

                    Console.WriteLine($"stock balance {fundCode} {standardCode} {name} {normalBalance} {balanceAvailableToSell} {averageBuyPrice} {borrowedBalance}");

                    if (!IsStrategyInitialized)
                    {
                        if (normalBalance > 0 || borrowedBalance > 0)
                        {
                            Balance balance = new Balance() { FundCode = fundCode, StandardCode = standardCode, ShortCode = shortCode };
                            StockBalances.Add(balance);
                        }
                    }
                    else
                    {
                        state.UpdateBalanceFromTops(normalBalance, balanceAvailableToSell, averageBuyPrice);
                        //FundBalanceAmount += normalBalance * averageBuyPrice;
                    }
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q80001_SUB));
            }

            FundBalanceAmountTextBox.Text = string.Format("{0:#,0}", FundBalanceAmount);
        }

        private void GetStockLiveOrders(IntPtr ptr)
        {
            var _out = (OUT_Q70001)Marshal.PtrToStructure(ptr, typeof(OUT_Q70001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q70001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q70001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q70001_SUB));
                var standardCode = C.AsString(sub.expcode);

                if (States.TryGetValue(standardCode, out var state))
                {
                    var shortCode = C.AsString(sub.isu_cd).Trim();
                    var name = C.AsString(sub.isu_nm).Trim().Replace(" ", string.Empty);
                    var fundCode = C.AsString(sub.fund_no);
                    var askBidType = C.AsString(sub.tr_cls) == "1" ? AskBidType.Ask : AskBidType.Bid;
                    var orderType = C.AsString(sub.ord_type) == "1" ? OrderType.Market : OrderType.Limit;
                    var orderPrice = C.AsLong(sub.ord_prc);
                    var orderQuantity = C.AsLong(sub.ord_qty);
                    var liveQuantity = C.AsLong(sub.rem_qty);
                    var orderId = C.AsLong(sub.ord_no);
                    var originalOrderId = C.AsLong(sub.org_ord_no);

                    var liveOrder = new LiveOrder(standardCode, shortCode, askBidType, orderType, OrderCondition.Normal,
                                                orderPrice, orderQuantity, liveQuantity,
                                                orderId, originalOrderId, C.AsLong(sub.tord_no), C.AsLong(sub.org_tord_no), C.AsString(sub.accnt_no), DateTime.Now);

                    Console.WriteLine($"{C.AsString(_out.next_key)} Stock LiveOrder {fundCode} {shortCode} {name} {askBidType} {orderPrice} {liveQuantity}/{orderQuantity}");

                    if (!IsStrategyInitialized)
                    {
                        LiveOrders.Add(liveOrder);
                        //LogWriter.Write($"# Total LiveOrders: {LiveOrders.Count}");
                    }
                    else
                    {
                        state.UpdateLiveOrders(liveOrder);
                    }
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q70001_SUB));
            }
        }

        private void GetKospiFuturesBalances(IntPtr ptr)
        {
            var _out = (OUT_Q40001)Marshal.PtrToStructure(ptr, typeof(OUT_Q40001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q40001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q40001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q40001_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var name = C.AsString(sub.kor_isu_nm).Trim();
                    var fundCode = C.AsString(sub.fund_no);
                    var askBidType = C.AsString(sub.tr_cls);
                    var normalBalance = askBidType == "1" ? -C.AsLong(sub.bk_qty) : C.AsLong(sub.bk_qty);
                    var averagePrice = C.AsString(sub.bk_prc).TrimStart('0');

                    if (averagePrice == "")
                        continue;

                    if (IsStrategyInitialized)
                        state.UpdateBalance(normalBalance, C.AsDouble(averagePrice.Substring(0, 5)) / 100);

                    Console.WriteLine($"KOSPI future balance {fundCode} {standardCode} {name} {askBidType} {normalBalance} {averagePrice}");
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q40001_SUB));
            }
        }

        private void GetKospiFuturesLiveOrders(IntPtr ptr)
        {
            var _out = (OUT_Q30003)Marshal.PtrToStructure(ptr, typeof(OUT_Q30003));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q30003));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q30003_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q30003_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var liveQuantity = C.AsLong(sub.rem_qty);

                    if (liveQuantity > 0)
                    {
                        var fundCode = C.AsString(sub.fund_no);
                        var shortCode = C.AsString(sub.isu_cd).Trim();
                        var name = C.AsString(sub.kor_isu_nm).Trim().Replace(" ", string.Empty);
                        var askBidType = C.AsString(sub.tr_cls) == "1" ? AskBidType.Ask : AskBidType.Bid;
                        var orderType = C.AsString(sub.ord_ty) == "1" ? OrderType.Market : OrderType.Limit;
                        var orderPrice = C.AsDouble(C.AsString(sub.ord_prc).TrimStart('0')) / 100;
                        var orderQuantity = C.AsLong(sub.ord_qty);
                        var orderId = C.AsLong(sub.ord_no);
                        var originalOrderId = C.AsLong(sub.org_ord_no);

                        var liveOrder = new DerivLiveOrder(standardCode, shortCode, askBidType, orderType, OrderCondition.Normal,
                                                orderPrice, orderQuantity, liveQuantity,
                                                orderId, originalOrderId, C.AsString(sub.accnt_no), DateTime.Now);

                        Console.WriteLine($"KOSPI future LiveOrder {fundCode} {shortCode} {name} {askBidType} {orderPrice} {liveQuantity}/{orderQuantity}");

                        if (!IsStrategyInitialized)
                            DerivLiveOrders.Add(liveOrder);
                        else
                            state.UpdateLiveOrders(liveOrder);
                    }
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q30003_SUB));
            }
        }

        private void GetKosdaqFuturesBalances(IntPtr ptr)
        {
            var _out = (OUT_Q46001)Marshal.PtrToStructure(ptr, typeof(OUT_Q46001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q46001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q46001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q46001_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var name = C.AsString(sub.kor_isu_nm).Trim();
                    var fundCode = C.AsString(sub.fund_no);
                    var askBidType = C.AsString(sub.tr_cls);
                    var normalBalance = askBidType == "1" ? -C.AsLong(sub.bk_qty) : C.AsLong(sub.bk_qty);
                    var averagePrice = C.AsString(sub.bk_prc).TrimStart('0');

                    if (averagePrice == "")
                        continue;

                    if (IsStrategyInitialized)
                        state.UpdateBalance(normalBalance, C.AsDouble(averagePrice.Substring(0, 6)) / 100);

                    Console.WriteLine($"KOSDAQ future balance {fundCode} {standardCode} {name} {askBidType} {normalBalance} {averagePrice}");
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q40001_SUB));
            }
        }

        private void GetKosdaqFuturesLiveOrders(IntPtr ptr)
        {
            var _out = (OUT_Q36001)Marshal.PtrToStructure(ptr, typeof(OUT_Q36001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q36001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q36001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q36001_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var liveQuantity = C.AsLong(sub.rem_qty);

                    if (liveQuantity > 0)
                    {
                        var fundCode = C.AsString(sub.fund_no);
                        var shortCode = C.AsString(sub.isu_cd).Trim();
                        var name = C.AsString(sub.kor_isu_nm).Trim().Replace(" ", string.Empty);
                        var askBidType = C.AsString(sub.tr_cls) == "1" ? AskBidType.Ask : AskBidType.Bid;
                        var orderType = C.AsString(sub.ord_ty) == "1" ? OrderType.Market : OrderType.Limit;
                        var orderPrice = C.AsDouble(C.AsString(sub.ord_prc).TrimStart('0')) / 100;
                        var orderQuantity = C.AsLong(sub.ord_qty);
                        var orderId = C.AsLong(sub.ord_no);
                        var originalOrderId = C.AsLong(sub.org_ord_no);

                        var liveOrder = new DerivLiveOrder(standardCode, shortCode, askBidType, orderType, OrderCondition.Normal,
                                                orderPrice, orderQuantity, liveQuantity,
                                                orderId, originalOrderId, C.AsString(sub.accnt_no), DateTime.Now);

                        Console.WriteLine($"KOSDAQ future LiveOrder {fundCode} {shortCode} {name} {askBidType} {orderPrice} {liveQuantity}/{orderQuantity}");

                        if (!IsStrategyInitialized)
                            DerivLiveOrders.Add(liveOrder);
                        else
                            state.UpdateLiveOrders(liveOrder);
                    }
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q36001_SUB));
            }
        }

        private void GetStockFuturesBalances(IntPtr ptr)
        {
            var _out = (OUT_Q42001)Marshal.PtrToStructure(ptr, typeof(OUT_Q42001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q42001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q42001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q42001_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var name = C.AsString(sub.kor_isu_nm).Trim();
                    var fundCode = C.AsString(sub.fund_no);
                    var askBidType = C.AsString(sub.tr_cls);
                    var normalBalance = askBidType == "1" ? -C.AsLong(sub.bk_qty) : C.AsLong(sub.bk_qty);
                    var averagePrice = C.AsString(sub.bk_prc).TrimStart('0');

                    if (averagePrice == "")
                        continue;

                    if (IsStrategyInitialized)
                        state.UpdateBalance(normalBalance, C.AsDouble(averagePrice));
                        Console.WriteLine($"STOCK futures UPdate balance {fundCode} {standardCode} {name} {askBidType} {normalBalance} {averagePrice}");

                    Console.WriteLine($"STOCK futures balance {fundCode} {standardCode} {name} {askBidType} {normalBalance} {averagePrice}");
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q42001_SUB));
            }
        }

        private void GetStockFuturesLiveOrders(IntPtr ptr)
        {
            var _out = (OUT_Q32001)Marshal.PtrToStructure(ptr, typeof(OUT_Q32001));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q32001));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q32001_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q32001_SUB));
                var standardCode = C.AsString(sub.isu_cd);

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    var liveQuantity = C.AsLong(sub.rem_qty);

                    if (liveQuantity > 0)
                    {
                        var fundCode = C.AsString(sub.fund_no);
                        var shortCode = C.AsString(sub.isu_cd).Trim();
                        var name = C.AsString(sub.kor_isu_nm).Trim().Replace(" ", string.Empty);
                        var askBidType = C.AsString(sub.tr_cls) == "1" ? AskBidType.Ask : AskBidType.Bid;
                        var orderType = C.AsString(sub.ord_ty) == "1" ? OrderType.Market : OrderType.Limit;
                        // 변경사항
                        var orderPrice = C.AsString(sub.ord_prc)== "000000000" ?  0 : C.AsDouble(C.AsString(sub.ord_prc).TrimStart('0'));
                        var orderQuantity = C.AsLong(sub.ord_qty);
                        var orderId = C.AsLong(sub.ord_no);
                        var originalOrderId = C.AsLong(sub.org_ord_no);

                        var liveOrder = new DerivLiveOrder(standardCode, shortCode, askBidType, orderType, OrderCondition.Normal,
                                                orderPrice, orderQuantity, liveQuantity,
                                                orderId, originalOrderId, C.AsString(sub.accnt_no), DateTime.Now);

                        Console.WriteLine($"STOCK futures LiveOrder {fundCode} {shortCode} {name} {askBidType} {orderPrice} {liveQuantity}/{orderQuantity}");

                        if (!IsStrategyInitialized)
                            DerivLiveOrders.Add(liveOrder);
                        else
                            state.UpdateLiveOrders(liveOrder);
                    }
                }

                ptr += Marshal.SizeOf(typeof(OUT_Q32001_SUB));
            }
        }

        private void GetAccounts(IntPtr ptr)
        {
            var _out = (OUT_Q90025)Marshal.PtrToStructure(ptr, typeof(OUT_Q90025));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q90025));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q90025_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q90025_SUB));
                FundCodes.Add(C.AsString(sub.fund_no).ToString());

                AlgoInfos[C.AsString(sub.fund_no).ToString()] = new AlgoInfo() { AlgoStrategyTypeCode = C.AsString(sub.algo_stgy_tp_cd),
                                                                                 TraderId = C.AsString(sub.trdr_id), 
                                                                                 OrderGroupNumber = C.AsString(sub.ord_grp_no), 
                                                                                 SmpCode = C.AsString(sub.smp_cd)};

                ptr += Marshal.SizeOf(typeof(OUT_Q90025_SUB));
            }
        }

        private void GetTheProhibited(IntPtr ptr)
        {
            var _out = (OUT_Q90056)Marshal.PtrToStructure(ptr, typeof(OUT_Q90056));
            var cnt = C.AsInt(_out.rcnt);

            if (cnt == 0)
                return;

            ptr += Marshal.SizeOf(typeof(OUT_Q90056));
            for (int i = 0; i < cnt; i++)
            {
                var sub = (OUT_Q90056_SUB)Marshal.PtrToStructure(ptr, typeof(OUT_Q90056_SUB));
                var shortCode = C.AsString(sub.isu_cd).Trim();

                var endYear = C.AsInt(C.AsString(sub.end_date).Substring(0, 4));
                var endMonth = C.AsInt(C.AsString(sub.end_date).Substring(4, 2));
                var endday = C.AsInt(C.AsString(sub.end_date).Substring(6, 2));
                var endHour = C.AsInt(C.AsString(sub.end_tm).Substring(0, 2));
                var endMinute = C.AsInt(C.AsString(sub.end_tm).Substring(2, 2));
                var endSecond = C.AsInt(C.AsString(sub.end_tm).Substring(4, 2));

                var endDateTime = new DateTime(endYear, endMonth, endday, endHour, endMinute, endSecond);

                // 매매제한 종료 종목 PASS
                if (DateTime.Now > endDateTime)
                {
                    ptr += Marshal.SizeOf(typeof(OUT_Q90056_SUB));
                    continue;
                }

                Prohibited.Add(shortCode);
                ptr += Marshal.SizeOf(typeof(OUT_Q90056_SUB));
            }
        }

        private void OnExecution(Message m)
        {
            STOCK_HEADER tmp = (STOCK_HEADER)m.GetLParam(typeof(STOCK_HEADER));
            var marketType = C.AsString(tmp.mkt_l_cls);
            
            if (marketType == "S")
            {
                var header = tmp;
                STOCK_EXECUTION execution = (STOCK_EXECUTION)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(STOCK_EXECUTION));

                if (States.TryGetValue(C.AsString(execution.code), out var state))
                {
                    var orderId = C.AsLong(execution.ord_no);
                    var tradingPrice = C.AsLong(execution.che_price);
                    var tradingVolume = C.AsLong(execution.che_qty);
                    var askBidType = C.AsString(execution.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid;

                    if (C.AsString(header.fund_no) == FundCode)
                        state.OnExecution(orderId, tradingPrice, tradingVolume);

                    if (LiveOrders.Exists(x => x.OrderId == orderId))
                    {
                        if (!state.LiveOrders.Any(x => x.OrderId == orderId))
                            LiveOrders.RemoveAll(x => x.OrderId == orderId);
                    }
                }
            }
            else if (marketType == "K" || marketType == "G")
            {
                DERIV_HEADER header = (DERIV_HEADER)m.GetLParam(typeof(DERIV_HEADER));
                DERIV_EXECUTION execution = (DERIV_EXECUTION)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(DERIV_EXECUTION));
                var standardCode = C.AsString(execution.code);
                var orderId = C.AsLong(execution.ord_no);
                var tradingPrice = C.AsDouble(execution.che_price);
                var tradingVolume = C.AsLong(execution.che_qty);
                var askBidType = C.AsString(execution.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid;

                if (DerivStates.TryGetValue(standardCode, out var state))
                {
                    if (C.AsString(header.fund_no) == FundCode)
                        state.OnExecution(orderId, tradingPrice, tradingVolume);

                    if (DerivLiveOrders.Exists(x => x.OrderId == orderId))
                    {
                        if (!state.LiveOrders.Any(x => x.OrderId == orderId))
                            DerivLiveOrders.RemoveAll(x => x.OrderId == orderId);
                    }
                }
            }
        }

        private void OnConfirm(Message m)
        {
            var productCode = m.GetLParam(typeof(char)).ToString(); // 주식 : T, 파생 : D

            // 주식 컨펌처리
            if (productCode == "T")
            {
                STOCK_HEADER header = (STOCK_HEADER)m.GetLParam(typeof(STOCK_HEADER));
                var dataType = C.AsString(header.ack_gubun);

                if (dataType == "H")
                {
                    STOCK_CONFIRM confirm = (STOCK_CONFIRM)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(STOCK_CONFIRM));

                    if (States.TryGetValue(C.AsString(confirm.code), out var state))
                    {
                        var orderCategoryCode = C.AsString(confirm.hogagb);

                        if (orderCategoryCode == "1" && C.AsString(confirm.ord_cond) == "0")
                        {
                            LiveOrder liveOrder = new LiveOrder(C.AsString(confirm.code),
                                                            C.AsString(header.isu_cd).Replace(" ", ""),
                                                            C.AsString(confirm.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid,
                                                            C.AsString(confirm.ord_type) == "1" ? OrderType.Market : OrderType.Limit,
                                                            C.AsString(confirm.ord_cond) == "0" ? OrderCondition.Normal : C.AsString(confirm.ord_cond) == "3" ? OrderCondition.IOC : OrderCondition.FOK,
                                                            C.AsLong(confirm.price),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.ord_no),
                                                            0,
                                                            C.AsLong(header.tord_no),
                                                            C.AsLong(header.org_tord_no),
                                                            C.AsString(confirm.gyejwa),
                                                            DateTime.Now);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(0, liveOrder);

                            LiveOrders.Add(liveOrder);
                        }
                        else if (orderCategoryCode == "2")
                        {
                            var originalOrderId = C.AsLong(confirm.org_ord_no);
                            LiveOrder liveOrder = new LiveOrder(C.AsString(confirm.code),
                                                            C.AsString(header.isu_cd).Replace(" ", ""),
                                                            C.AsString(confirm.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid,
                                                            C.AsString(confirm.ord_type) == "1" ? OrderType.Market : OrderType.Limit,
                                                            C.AsString(confirm.ord_cond) == "0" ? OrderCondition.Normal : C.AsString(confirm.ord_cond) == "3" ? OrderCondition.IOC : OrderCondition.FOK,
                                                            C.AsLong(confirm.price),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.ord_no),
                                                            C.AsLong(confirm.org_ord_no),
                                                            C.AsLong(header.tord_no),
                                                            C.AsLong(header.org_tord_no),
                                                            C.AsString(confirm.gyejwa),
                                                            DateTime.Now);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(originalOrderId, liveOrder);

                            LiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                            LiveOrders.Add(liveOrder);
                        }
                        else if (orderCategoryCode == "3")
                        {
                            var originalOrderId = C.AsLong(confirm.org_ord_no);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(originalOrderId, null);

                            LiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                        }
                    }
                }
                else if (dataType == "R" && C.AsString(header.fund_no) == FundCode)
                {
                    var reject = (STOCK_CONFIRM)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(STOCK_CONFIRM));
                    var rejectCode = C.AsString(header.res_code).Trim();
                    if (Rejects.TopsMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from TOPS2: {Rejects.TopsMessage[rejectCode]} {C.AsString(reject.code)}");
                    else if (Rejects.KrxMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from KRX: {Rejects.KrxMessage[rejectCode]} {C.AsString(reject.code)}");
                    else if (Rejects.InternalMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from internal: {Rejects.InternalMessage[rejectCode]} {C.AsString(reject.code)}");
                    else
                        LogWriter.Write($"OnConfirm unexpected reject message: {rejectCode} {C.AsString(reject.code)}");

                    if (States.TryGetValue(C.AsString(reject.code), out var state))
                    {
                        var orderCategoryCode = C.AsString(reject.hogagb);
                        var askBidType = C.AsString(reject.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid;

                        state.OnReject(orderCategoryCode, askBidType);
                    }

                    if (FundCode != "" && EmployeeId != "")
                        CommHelper.RequestQ80001(n_mKey, FundCode, EmployeeId);
                }
                else
                {
                    LogWriter.Write($"OnConfirm error message from other funds {C.AsString(header.fund_no)}");
                }
            }
            // 파생 컨펌처리
            else if (productCode == "D")
            {
                DERIV_HEADER header = (DERIV_HEADER)m.GetLParam(typeof(DERIV_HEADER));
                var dataType = C.AsString(header.ack_gubun);

                if (dataType == "H")
                {
                    DERIV_CONFIRM confirm = (DERIV_CONFIRM)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(DERIV_CONFIRM));

                    if (DerivStates.TryGetValue(C.AsString(confirm.code), out var state))
                    {
                        var orderCategoryCode = C.AsString(confirm.hogagb);

                        if (orderCategoryCode == "1" && C.AsString(confirm.ord_cond) == "0")
                        {
                            var liveOrder = new DerivLiveOrder(C.AsString(confirm.code),
                                                            C.AsString(confirm.code),
                                                            C.AsString(confirm.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid,
                                                            C.AsString(confirm.ord_type) == "1" ? OrderType.Market : OrderType.Limit,
                                                            C.AsString(confirm.ord_cond) == "0" ? OrderCondition.Normal : C.AsString(confirm.ord_cond) == "3" ? OrderCondition.IOC : OrderCondition.FOK,
                                                            C.AsDouble(confirm.price),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.ord_no),
                                                            0,
                                                            C.AsString(confirm.gyejwa),
                                                            DateTime.Now);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(0, liveOrder);

                            DerivLiveOrders.Add(liveOrder);
                        }
                        else if (orderCategoryCode == "2")
                        {
                            var originalOrderId = C.AsLong(confirm.org_ord_no);
                            var liveOrder = new DerivLiveOrder(C.AsString(confirm.code),
                                                            C.AsString(confirm.code),
                                                            C.AsString(confirm.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid,
                                                            C.AsString(confirm.ord_type) == "1" ? OrderType.Market : OrderType.Limit,
                                                            C.AsString(confirm.ord_cond) == "0" ? OrderCondition.Normal : C.AsString(confirm.ord_cond) == "3" ? OrderCondition.IOC : OrderCondition.FOK,
                                                            C.AsDouble(confirm.price),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.cnt),
                                                            C.AsLong(confirm.ord_no),
                                                            C.AsLong(confirm.org_ord_no),
                                                            C.AsString(confirm.gyejwa),
                                                            DateTime.Now);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(originalOrderId, liveOrder);

                            DerivLiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                            DerivLiveOrders.Add(liveOrder);
                        }
                        else if (orderCategoryCode == "3")
                        {
                            var originalOrderId = C.AsLong(confirm.org_ord_no);

                            if (C.AsString(header.fund_no) == FundCode)
                                state.OnConfirm(originalOrderId, null);

                            DerivLiveOrders.RemoveAll(x => x.OrderId == originalOrderId);
                        }
                    }
                }
                else if (dataType == "R" && C.AsString(header.fund_no) == FundCode)
                {
                    var reject = (DERIV_CONFIRM)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(DERIV_CONFIRM));
                    var rejectCode = C.AsString(header.res_code).Trim();
                    if (Rejects.TopsMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from TOPS2: {Rejects.TopsMessage[rejectCode]} {C.AsString(reject.code)}");
                    else if (Rejects.KrxMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from KRX: {Rejects.KrxMessage[rejectCode]} {C.AsString(reject.code)}");
                    else if (Rejects.InternalMessage.ContainsKey(rejectCode))
                        LogWriter.Write($"OnConfirm reject message from internal: {Rejects.InternalMessage[rejectCode]} {C.AsString(reject.code)}");
                    else
                        LogWriter.Write($"OnConfirm unexpected reject message: {rejectCode} {C.AsString(reject.code)}");

                    if (DerivStates.TryGetValue(C.AsString(reject.code), out var state))
                    {
                        var orderCategoryCode = C.AsString(reject.hogagb);
                        var askBidType = C.AsString(reject.mmgubun) == "1" ? AskBidType.Ask : AskBidType.Bid;

                        state.OnReject(orderCategoryCode, askBidType);
                    }
                }
                else
                {
                    LogWriter.Write($"OnConfirm error message from other funds {C.AsString(header.fund_no)}");
                }
            }
        }

        private void OnAck(Message m)
        {
            //TOPS_HEADER header = (TOPS_HEADER)m.GetLParam(typeof(TOPS_HEADER));
            //KRX_ORDER ack = (KRX_ORDER)Marshal.PtrToStructure(m.LParam + Marshal.SizeOf(header), typeof(KRX_ORDER));
        }

        public void MainLog(string log)
        {
            BeginInvoke(new Action(delegate ()
            {
                SystemLoggingBox.AppendText($"[{DateTime.Now.ToString("HH:mm:ss.fff")}] {log}\n");
                SystemLoggingBox.ScrollToCaret();
                LogWriter.Write(log);
            }));
        }

        public void ResetStrategyBox()
        {
            StrategyTextBox.Clear();
            FundCodeTextBox.Clear();
            IsStrategyInitialized = false;
            FundBalanceAmount = 0;
        }

        private bool ReadyToRunStrategy(string fundCode)
        {
            if (!InitSystem.Initialized)
            {
                MainLog("system should be running first");
                return false;
            }

            if ((DateTime.Now - InitSystem.Time).TotalSeconds < 5)
            {
                MainLog($"wait for system initialization ({5 - (int)(DateTime.Now - InitSystem.Time).TotalSeconds} sec left)");
                return false;
            }

            if (IsStrategyInitialized)
            {
                MainLog("strategy is already running");
                return false;
            }

            if (!FundCodes.Contains(fundCode))
            {
                MainLog("Check FUNDCODE, not in FundCodes from TOPS2");
                return false;
            }

            this.FundCode = fundCode;
            return true;
        }

        #region Strategy Buttons

        private void StockRsiReversionButton_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("9503"))
                return;

            StrategyTextBox.Text = "Stock Rsi Reversion";
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _stockRsiReversion.Show();
        }
        private void IndexFutureVoltyDailyButton_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("9990"))
                return;

            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "Index Future Volty V1";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _indexFutureVoltyV1.Show();
        }

        private void StockVoltyBreakLargeCapButton_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("9505"))
                return;

            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "Stock Volty Break";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();

            _stockVoltyBreak.Show();
        }

        private void StockVoltyBreakMidCapButton_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("9504"))
                return;

            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "Stock Volty Break Mid Cap";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();

            _stockVoltyBreakMidCap.Show();
        }



        private void StockFuturesPairRsi_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6900"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "StockFuturesPairRsi";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _stockFuturesPairRsi.Show();
        }

        private void StockFuturesPairStd_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6901"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "StockFuturesPairStd";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _stockFuturesPairStd.Show();
        }
        private void StockRsiSwing_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6902"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "StockRsiSwing";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _stockRsiSwing.Show();
        }
        private void StockFuturesBasis_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6903"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "StockFuturesBasis";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _stockFuturesBasis.Show();
        }

        private void IndexFuturesPairBreak_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6906"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "IndexFuturesPairBreak";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _indexFuturePairIntraBreak.Show();
        }

        private void IndexFuturesHLBreak_Click(object sender, EventArgs e)
        {
            if (!ReadyToRunStrategy("6904"))
                return;
            CommHelper.Set(EmployeeId, FundCode, AlgoInfos[FundCode]);
            StrategyTextBox.Text = "IndexFuturesHLBreak";
            FundCodeTextBox.Text = C.AsString(FundCode);

            OnRunningStrategy();
            _IndexFuturesHLBreak.Show();
        }
        #endregion


        private void OnRunningStrategy()
        {
            IsStrategyInitialized = true;

            foreach (var state in States.Values)
                state.Reset();

            foreach (var balance in StockBalances.Where(x => !x.FundCode.StartsWith("27") && !x.FundCode.StartsWith("9") && !x.FundCode.StartsWith("29") && !x.FundCode.StartsWith("69")))
            {
                if (States.ContainsKey(balance.StandardCode))
                {
                    if (StockBalances.Any(x => x.StandardCode == balance.StandardCode && (x.FundCode.StartsWith("27") || x.FundCode.StartsWith("9") || x.FundCode.StartsWith("29") || x.FundCode.StartsWith("69"))))
                        continue;

                    States.Remove(balance.StandardCode);
                    States.Remove(balance.ShortCode);
                }
            }

            CallRemoveStockRights();

            FundBalanceAmount = 0;
            FundBalanceAmountTextBox.Text = string.Format("{0:#,0}", FundBalanceAmount);

            // get stock balances
            CommHelper.RequestQ80001(n_mKey, FundCode, EmployeeId);

            // get stock futures balance 추가 했습니다!
            CommHelper.RequestQ42001(n_mKey, FundCode, EmployeeId);

            // get Stock live orders
            CommHelper.RequestQ70001(n_mKey, EmployeeId, FundCode);

            // get stock futures live orders 추가 했습니다!
            CommHelper.RequestQ32001(n_mKey, EmployeeId, FundCode);

            // get kospi future live orders
            CommHelper.RequestQ30003(n_mKey, EmployeeId, FundCode);

            // get kosdaq future live orders
            CommHelper.RequestQ36001(n_mKey, EmployeeId, FundCode);

            Indi_FundRegister.CreateControl();
            Indi_FundRegister.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivedFundRegistration);

            Indi_FundRegister.SetQueryName("REG_ACCT");
            Indi_FundRegister.SetSingleData(0, EmployeeId);
            Indi_FundRegister.SetSingleData(1, "3");
            Indi_FundRegister.SetSingleData(2, "");
            Indi_FundRegister.SetSingleData(3, "9999900" + FundCode);
            Indi_FundRegister.SetSingleData(4, "LONG SHORT 운용");

            var nRQID = Indi_FundRegister.RequestData();
        }

        public void UnRequestAll()
        {
            SiseHelper.ReleaseAll(this.Handle);
        }

        #region Kernels to strategies
        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {

            if (_stockRsiReversion.IsEnabled())
                _stockRsiReversion.UpdateQuotes(dataType, state);
            else if (_stockVoltyBreak.IsEnabled())
                _stockVoltyBreak.UpdateQuotes(dataType, state);
            else if (_stockVoltyBreakMidCap.IsEnabled())
                _stockVoltyBreakMidCap.UpdateQuotes(dataType, state);
            else if (_stockVoltyBreakMidCap.IsEnabled())
                _stockVoltyBreakMidCap.UpdateQuotes(dataType, state);
            else if (_stockFuturesPairRsi.IsEnabled())
                _stockFuturesPairRsi.UpdateQuotes(dataType, state);
            else if (_stockFuturesPairStd.IsEnabled())
                _stockFuturesPairStd.UpdateQuotes(dataType, state);
            else if (_stockRsiSwing.IsEnabled())
                _stockRsiSwing.UpdateQuotes(dataType, state);
            else if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.UpdateQuotes(dataType, state);
        }

        public void UpdateQuotes(RealTimeDataType dataType, DerivState state)
        {

            if (_stockFuturesPairRsi.IsEnabled())
                _stockFuturesPairRsi.UpdateQuotes(dataType, state);
            else if (_stockFuturesPairStd.IsEnabled())
                _stockFuturesPairStd.UpdateQuotes(dataType, state);
            else if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.UpdateQuotes(dataType, state);
            else if (_indexFuturePairIntraBreak.IsEnabled())
                _indexFuturePairIntraBreak.UpdateQuotes(dataType, state);
            else if (_IndexFuturesHLBreak.IsEnabled())
                _IndexFuturesHLBreak.UpdateQuotes(dataType, state);
        }

        public void OnConfirm(StockState state)
        {

            if (_stockRsiReversion.IsEnabled())
                _stockRsiReversion.OnConfirm(state);
            else if (_stockVoltyBreak.IsEnabled())
                _stockVoltyBreak.OnConfirm(state);
            else if (_stockVoltyBreakMidCap.IsEnabled())
                _stockVoltyBreakMidCap.OnConfirm(state);
            else if (_stockFuturesPairRsi.IsEnabled())
                _stockFuturesPairRsi.OnConfirm(state);
            else if (_stockFuturesPairStd.IsEnabled())
                _stockFuturesPairStd.OnConfirm(state);
            else if (_stockRsiSwing.IsEnabled())
                _stockRsiSwing.OnConfirm(state);
            else if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.OnConfirm(state);
        }

        public void OnConfirm(DerivState state)
        {

            if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.OnConfirm(state);
            else if (_indexFuturePairIntraBreak.IsEnabled())
                _indexFuturePairIntraBreak.OnConfirm(state);
            else if (_IndexFuturesHLBreak.IsEnabled())
                _IndexFuturesHLBreak.OnConfirm(state);
        }

        public void OnExecution(StockState state)
        {

            if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.OnExecution(state);
        }

        public void OnExecution(DerivState state)
        {

            if (_stockFuturesBasis.IsEnabled())
                _stockFuturesBasis.OnExecution(state);
        }

        #endregion

        #region Update SafetyParams
        private void UpdateSafetyParams()
        {
            var singleOrderAmountLimit = C.AsLong(SingleOrderAmountLimitTextBox.Text.Replace(",", ""));
            var singleAssetPositionLimit = C.AsLong(SingleAssetPositionLimitTextBox.Text.Replace(",", ""));
            var fundPositionLimit = C.AsLong(FundPositionLimitTextBox.Text.Replace(",", ""));
            var interval = C.AsLong(IntervalTextBox.Text);
            var orderNumberLimit = C.AsLong(OrderNumberLimitTextBox.Text);

            if (Safety.Update(singleOrderAmountLimit, singleAssetPositionLimit, fundPositionLimit, interval, orderNumberLimit))
                MainLog("Safety params are updated");
            else
                MainLog("Safety params are NOT updated, please check again");

            SingleOrderAmountLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleOrderAmountLimit);
            SingleAssetPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleAssetPositionLimit);
            FundPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.FundPositionLimit);
            IntervalTextBox.Text = C.AsString(Safety.Interval);
            OrderNumberLimitTextBox.Text = C.AsString(Safety.OrderNumberLimit);
        }

        private void SingleOrderAmountLimitTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Int64.TryParse(SingleOrderAmountLimitTextBox.Text.Replace(",", ""), out var result))
                    UpdateSafetyParams();
                else
                    SingleOrderAmountLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleOrderAmountLimit);
            }
            else if (e.KeyCode == Keys.Escape)
                SingleOrderAmountLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleOrderAmountLimit);
        }

        private void SingleAssetPositionLimitTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Int64.TryParse(SingleAssetPositionLimitTextBox.Text.Replace(",", ""), out var result))
                    UpdateSafetyParams();
                else
                    SingleAssetPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleAssetPositionLimit);
            }
            else if (e.KeyCode == Keys.Escape)
                SingleAssetPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.SingleAssetPositionLimit);
        }

        private void FundPositionLimit_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Int64.TryParse(FundPositionLimitTextBox.Text.Replace(",", ""), out var result))
                    UpdateSafetyParams();
                else
                    FundPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.FundPositionLimit);
            }
            else if (e.KeyCode == Keys.Escape)
                FundPositionLimitTextBox.Text = string.Format("{0:#,0}", Safety.FundPositionLimit);
        }

        private void IntervalTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Int64.TryParse(IntervalTextBox.Text, out var result))
                    UpdateSafetyParams();
                else
                    IntervalTextBox.Text = C.AsString(Safety.Interval);
            }
            else if (e.KeyCode == Keys.Escape)
                IntervalTextBox.Text = C.AsString(Safety.Interval);
        }

        private void OrderNumberLimitTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Int64.TryParse(OrderNumberLimitTextBox.Text, out var result))
                    UpdateSafetyParams();
                else
                    OrderNumberLimitTextBox.Text = C.AsString(Safety.OrderNumberLimit);
            }
            else if (e.KeyCode == Keys.Escape)
                OrderNumberLimitTextBox.Text = C.AsString(Safety.OrderNumberLimit);
        }
        #endregion
        
        #region Remove Stock Rights from States
        private void CallRemoveStockRights()
        {
            Indi_StockRightsReceiver.CreateControl();
            Indi_StockRightsReceiver.ReceiveData += Indi_StockRightsReceiver_ReceiveData;
            Thread IndiRequestThread = new Thread(() => RemoveStockRights());
            IndiRequestThread.Start();
        }

        private void RemoveStockRights()
        {
            this.isReady = false;
            string strToday = DateTime.Today.ToString("yyyyMMdd");
            Indi_StockRightsReceiver.SetQueryName("SCBA321Q1");
            Indi_StockRightsReceiver.SetSingleData(0, $"{strToday}");
            Indi_StockRightsReceiver.SetSingleData(1, "");
            Indi_StockRightsReceiver.SetSingleData(2, "");
            Indi_StockRightsReceiver.SetSingleData(3, "1");
            Indi_StockRightsReceiver.SetSingleData(4, "0");
            Indi_StockRightsReceiver.SetSingleData(5, "3");
            Indi_StockRightsReceiver.SetSingleData(6, "744");
            Indi_StockRightsReceiver.RequestData();

            while (true)
            {
                if (this.isReady == true)
                    break;
            }

            short nCnt = Indi_StockRightsReceiver.GetMultiRowCount();

            for (short i = 0; i < nCnt; i++)
            {
                if (C.AsInt(Indi_StockRightsReceiver.GetMultiData(i, 10).ToString()) <= 0) { continue; }
                
                string shortCode = Indi_StockRightsReceiver.GetMultiData(i, 3).ToString().Substring(1, 6);
                string standardCode = "";

                if (States.TryGetValue(shortCode, out var state))
                {
                    standardCode = state.StandardCode;
                    States.Remove(standardCode);
                    States.Remove(shortCode);
                }
            }
        }

        private void Indi_StockRightsReceiver_ReceiveData(object sender, AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEvent e)
        {
            this.isReady = true;
        }
        #endregion

        private void DisableTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DisableView.Rows.Clear();

                var issueCode = DisableTextBox.Text;
                if (Disables.Contains(issueCode))
                {
                    Disables.Remove(issueCode);
                    States[issueCode].Enable();
                }
                else if (States.TryGetValue(issueCode, out var state))
                {
                    Disables.Add(issueCode);
                    state.Disable();
                }
                else if (!States.Keys.Contains(issueCode))
                    Console.WriteLine($"{issueCode} is not in universe");

                if (Disables.Count > 0)
                {
                    for (var i = 0; i < Disables.Count; i++)
                        DisableView.Rows.Add(i + 1, Disables[i], States[Disables[i]].Name);
                }

                DisableTextBox.Clear();
            }
            else if (e.KeyCode == Keys.Escape)
                DisableTextBox.Clear();
        }

        private void DisableClearButton_Click(object sender, EventArgs e)
        {
            var _disables = Disables.ToList();
            
            Disables.Clear();
            DisableView.Rows.Clear();

            if (_disables.Count > 0)
            {
                foreach (var issueCode in _disables)
                    States[issueCode].Enable();
            }
        }

        private void Open9Close15RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (Open9Close15RadioButton.Checked)
            {
                MarketOpenTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                MarketCloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);

            }
            else if (Open10Close15RadioButton.Checked)
            {
                MarketOpenTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketCloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Open10Close16RadioButton.Checked)
            {
                MarketOpenTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketCloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
            }

            if (ClickedRunButton)
            {
                if (_stockRsiReversion.IsEnabled())
                    _stockRsiReversion.UpdateTimes();
                else if (_stockVoltyBreak.IsEnabled())
                    _stockVoltyBreak.UpdateTimes();
                else if (_stockVoltyBreakMidCap.IsEnabled())
                    _stockVoltyBreakMidCap.UpdateTimes();
            }
        }
    }
}
