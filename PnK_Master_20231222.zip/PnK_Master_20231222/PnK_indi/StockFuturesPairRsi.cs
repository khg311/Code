﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using AxGIExpertControl64Lib;
using TicTacTec.TA.Library;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PnK_indi
{
    public partial class StockFuturesPairRsi : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SubState> SubStates = new Dictionary<string, SubState>();
        private Dictionary<string, SpreadSubState> SpreadSubStates = new Dictionary<string, SpreadSubState>();
        private Dictionary<string, FuturesSubState> FuturesSubStates = new Dictionary<string, FuturesSubState>();

        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        //삼성전자_SK하이닉스, KB금융_하나금융지주, 한화솔루션_LG화학, SK텔레콤_KT ,현대차_현대위아 , 현대건설_현대제철, DB하이텍_동진쎄미켐 ,현대모비스_기아
        private List<string> PairUniverseList = new List<string>() { "005930_000660", "105560_086790", "009830_051910", "017670_030200", "005380_011210", "000720_004020", "000990_005290", "012330_000270" };
        private List<string> StockUniverseCode = new List<string>() { "005930", "000660", "105560", "086790", "009830", "051910", "017670", "030200", "005380", "011210", "000720", "004020", "000990", "005290", "012330","000270" };

        private List<double> PairCointList = new List<double>() { 1.1, 1, 1.1, 1, 1, 0.8, 1.2 , 0.8 };
        private List<double> TakeProfitAdjList = new List<double>() { 1, 1, 1, 1, 1, 1, 1 ,1};
        private List<double> LossCutAdjList = new List<double>() { 1, 1, 1, 1, 1, 1, 1, 1 };


        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;


        /// <summary>
        ///  tuple 변수로 상태 bool과 시간을 저장
        /// </summary>
        private (bool Status, DateTime Time) Calculate_Rsi_signal_tuple;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) EntryOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;
        private bool SetSpreadPriceSetBef_Flag = false;

        private new bool Enabled;

        public Thread SetPriceSetBef { get; private set; }
        public Thread Calculate_Rsi_Thread { get; private set; }

        public double sfutures_multiple = 10;

        private bool working_flag = true;

        // 형식에 맞게 파일 이름을 생성합니다.
        string filePath = "C:/Users/234046/Desktop/Logs/StockFuturesPairRsi/" + DateTime.Now.ToString("yyyy-MM-dd") + "_output.log";

        public StockFuturesPairRsi(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();
        }


        private void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
            }

            Calculate_Rsi_signal_tuple = (false, MarketOpeningTime.AddMinutes(5));

            MarketOpened = (false, MarketOpeningTime);


            ClosingPriceOrdered = (false, MarketClosingTime.AddMinutes(-20));
            EntryOrdered = (false, MarketClosingTime.AddMinutes(-60));

            OnClose = (false, MarketClosingTime.AddMinutes(10));
        }

        /// <summary>
        /// 선언한 인디객체에 이벤트 함수를 연결 
        /// </summary>
        private void InitializeIndiControls()
        {

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);
        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }

        public bool IsEnabled() => this.Enabled;

        public void OnConfirm(StockState state)
        {
        }

        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution)
            {   //SubStates 의 State에 StockState state가 어떻게 업데이트되는지 이해가 잘안감
                if (SubStates.TryGetValue(state.ShortCode, out SubState subState))
                {
                    subState.UpdatePrice();
                }
            }
        }

        public void UpdateQuotes(RealTimeDataType dataType, DerivState futuresState)
        {

        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("RunButton_Click");
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;
            InitSubStates();
            InitSpreadStates();
            SetUniverseStocks();
            InitFuturesStates();
            Enable();

            SetPriceSetBef = new Thread(() => SetPriceSetBefore());
            SetPriceSetBef.Start();
            Console.WriteLine("spread set start done");

            Console.WriteLine("ManageTimer before");
            ManageTimer.Set(5 * 1000);
            ManageTimer.Start(OnTimer);
        }

        private void InitSubStates()
        {
            foreach (var state in Main.States.Values)
            {
                // 주식 외 제외
                if (state.SecurityGroupId != SecurityGroupId.ST) { continue; }
                // 우선주 제외
                if (!state.ShortCode.EndsWith("0")) { continue; }
                // 락 종목 제외
                if (state.PriceAdjustment != PriceAdjustment.Normal
                    && state.PriceAdjustment != PriceAdjustment.ExDividend
                    && state.PriceAdjustment != PriceAdjustment.ExMidDividend) { continue; }
                // 스팩 제외
                if (state.Name.Contains("스팩")) { continue; }
                // 계열사 종목 제외
                if (state.Name.Contains("신한") || state.Name.Contains("제주은행")) { continue; }

                SubStates[state.ShortCode] = new SubState(state, _StrategyParams);



            }

            // 시세요청
            foreach (var subState in SubStates.Values)
            {
                var state = subState.State;

                if (state.MarketType == MarketType.Kospi)
                {
                    if (state.SecurityGroupId == SecurityGroupId.EF || state.SecurityGroupId == SecurityGroupId.EN)
                    {
                        Main.RequestA303S(state.StandardCode);
                        Main.RequestB703S(state.StandardCode);
                    }
                    else
                    {
                        Main.RequestA301S(state.StandardCode);
                        Main.RequestB601S(state.StandardCode);
                    }
                }
                else if (state.MarketType == MarketType.Kosdaq)
                {
                    Main.RequestA301Q(state.StandardCode);
                    Main.RequestB601Q(state.StandardCode);
                }
            }
        }

        private void InitFuturesStates()
        {
            foreach (var shortCode in StockUniverseCode)
            {

                var stockFuturesState = Main.DerivStates.Values.Where(x => x.UnderlyingAssetShortCode == shortCode &&
                    string.Compare(x.ExpiryDate, DateTime.Now.ToString("yyyyMMdd")) == 1).OrderBy(x => x.ExpiryDate).FirstOrDefault();

                if (stockFuturesState == null) { continue; }

                Main.RequestB604F(stockFuturesState.StandardCode);
                Main.RequestG704F(stockFuturesState.StandardCode);

                var futuresShortCode = stockFuturesState.ShortCode;

                FuturesSubStates[futuresShortCode] = new FuturesSubState(stockFuturesState, stockFuturesState.StandardCode, stockFuturesState.ShortCode, stockFuturesState.Name);


                //futuresShortCode를 SpreadSubState에 저장
                foreach (string pair in PairUniverseList)
                {
                    if (SpreadSubStates[pair].Pair1ShortCode == shortCode)
                    {
                        SpreadSubStates[pair].Pair1FuturesShortCode = futuresShortCode;

                    }
                    else if (SpreadSubStates[pair].Pair2ShortCode == shortCode)
                    {
                        SpreadSubStates[pair].Pair2FuturesShortCode = futuresShortCode;
                    }
                }
            }
        }
        /// <summary>
        /// spread state 객체 생성
        /// </summary>
        private void InitSpreadStates()
        {
            string filePath_states = @"C:\Users\234046\Desktop\States\StockFuturesPairRsi\SpreadSubStates.dat";
            if (File.Exists(filePath_states))
            {
                Console.WriteLine("SpreadSubState 데이터가 존재 합니다");
                using (FileStream fileStream = new FileStream(filePath_states, FileMode.Open))
                {
                    if (fileStream.Length > 0) // 데이터가 있는지 확인
                    {
                        BinaryFormatter binaryFormatter = new BinaryFormatter();
                        SpreadSubStates = (Dictionary<string, SpreadSubState>)binaryFormatter.Deserialize(fileStream);

                        foreach (string pair in PairUniverseList)
                        {
                            if (SpreadSubStates.ContainsKey(pair))
                            {
                                SpreadSubStates[pair].Params = _StrategyParams;

                            }
                            else
                            {
                                SpreadSubStates[pair] = new SpreadSubState(_StrategyParams);

                                string[] pairs = pair.Split('_');
                                SpreadSubStates[pair].Pair1ShortCode = pairs[0];
                                SpreadSubStates[pair].Pair2ShortCode = pairs[1];
                            }

                            if (Main.Prohibited.Contains(SpreadSubStates[pair].Pair1ShortCode))
                            {
                                SpreadSubStates[pair].Enabled = false;
                                Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair].Pair1ShortCode}입니다!");
                            }
                            else if (Main.Prohibited.Contains(SpreadSubStates[pair].Pair2ShortCode))
                            {
                                SpreadSubStates[pair].Enabled = false;
                                Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair].Pair2ShortCode}입니다!");
                            }

                        }

                    }
                    else
                    {
                        Console.WriteLine("SpreadSubState 데이터가 존재 하지만, 데이터가 비어있습니다");

                    }
                }
            }
            else
            {
                Console.WriteLine("SpreadSubState 데이터가 존재 하지 않습니다");
                foreach (string pair in PairUniverseList)
                {
                    SpreadSubStates[pair] = new SpreadSubState(_StrategyParams);

                    string[] pairs = pair.Split('_');
                    SpreadSubStates[pair].Pair1ShortCode = pairs[0];
                    SpreadSubStates[pair].Pair2ShortCode = pairs[1];

                    if (Main.Prohibited.Contains(pairs[0]))
                    {
                        SpreadSubStates[pair].Enabled = false;
                        Console.WriteLine($"거래금지 종목:{pairs[0]}입니다!");
                    }
                    else if (Main.Prohibited.Contains(pairs[1]))
                    {
                        SpreadSubStates[pair].Enabled = false;
                        Console.WriteLine($"거래금지 종목:{pairs[1]}입니다!");
                    }
                }
            }

        }


        /// <summary>
        /// pair에 해당하는 종목만 유니버스로 지정
        /// </summary>
        private void SetUniverseStocks()
        {
            Console.WriteLine("SetUniverseStocks");

            foreach (var subState in SubStates.Values.ToList())
            {
                var shortCode = subState.State.ShortCode;

                //페어 유니버스에 포함되지 않는 종목은 제거
                if (!StockUniverseCode.Contains(shortCode))
                {
                    if (subState.State.NormalBalance == 0)
                    {
                        SubStates.Remove(shortCode);
                        continue;
                    }
                }
                else
                {
                    Console.WriteLine($"shortCode : {shortCode} Name:{SubStates[shortCode].State.Name} ");
                }
            }
        }

        /// <summary>
        /// 장시작전 전일 까지의 종가데이터를 불러와 객체에 저장하는 함수
        /// </summary>
        private void SetPriceSetBefore()
        {


            foreach (var subState in SubStates.Values)
            {
                var shortCode = subState.State.ShortCode;
                string yesterday = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");

                Indi_StockChartControl.SetQueryName("TR_SCHART");
                Indi_StockChartControl.SetSingleData(0, shortCode);
                Indi_StockChartControl.SetSingleData(1, "D");
                Indi_StockChartControl.SetSingleData(2, "1");
                Indi_StockChartControl.SetSingleData(3, "00000000");
                Indi_StockChartControl.SetSingleData(4, yesterday);
                Indi_StockChartControl.SetSingleData(5, "500");
                Indi_StockChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_StockChart)
                        break;
                }

                this.IsMessageReceived_StockChart = false;

                var nCount = Indi_StockChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }

                if (subState.PriceSet.Count() > 0) { subState.PriceSet.Clear(); }

                double adj = 1.0d;
                for (short i = 0; i < nCount; i++)
                {
                    var _datetime = Indi_StockChartControl.GetMultiData(i, 0).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}";

                    var close = C.AsDouble(Indi_StockChartControl.GetMultiData(i, 5)) * adj;
                    subState.PriceSet.Add(close);
                    adj = adj * C.AsDouble(Indi_StockChartControl.GetMultiData(i, 6));

                }
                Console.WriteLine($"Set PriceSetUpdate , shortCode : {shortCode} Name:{SubStates[shortCode].State.Name} ");

            }

            SetSpreadSetBefore();
        }

        private void SetSpreadSetBefore()
        {
            int index_ = 0;
            foreach (string pair_key in SpreadSubStates.Keys)
            {
                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;
                List<double> pair1_priceset = SubStates[pair1_shortcode].PriceSet;
                List<double> pair2_priceset = SubStates[pair2_shortcode].PriceSet;

                SpreadSubStates[pair_key].cointvalue = PairCointList[index_];
                SpreadSubStates[pair_key].TakeProfitAdj = TakeProfitAdjList[index_];
                SpreadSubStates[pair_key].LossCutAdj = LossCutAdjList[index_];

                SpreadSubStates[pair_key].Pair1PriceSet = pair1_priceset;
                SpreadSubStates[pair_key].Pair2PriceSet = pair2_priceset;
                SpreadSubStates[pair_key].logSpreadSet = pair1_priceset.Zip(pair2_priceset, (x, y) => Math.Log(x) - SpreadSubStates[pair_key].cointvalue * Math.Log(y)).ToList();

                // 직전 봉까지를 활용한  rsi 계산
                SpreadSubStates[pair_key].CalculateRSI();

                var DerivState_pair1 = FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].DerivState;
                var DerivState_pair2 = FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].DerivState;

                string pair1_name = SubStates[pair1_shortcode].State.Name;
                string pair2_name = SubStates[pair2_shortcode].State.Name;

                if (DerivState_pair1.NormalBalance != 0 & DerivState_pair2.NormalBalance != 0)
                {
                    Console.WriteLine($"{pair_key} :존재함,{pair1_name},{DerivState_pair1.NormalBalance}계약,{pair2_name} {DerivState_pair2.NormalBalance}계약, ");

                    SpreadSubStates[pair_key].entry_today_signal = false;

                    SpreadSubStates[pair_key].first_entry_order_done = false;

                    SpreadSubStates[pair_key].exit_monitoring = true;

                    SpreadSubStates[pair_key].exit_today_signal = false;

                    //만약 포지션은 있는데 entry side 가 null이면 입력함
                    if (object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null))
                    {
                        if (DerivState_pair1.NormalBalance > 0 & DerivState_pair2.NormalBalance < 0)
                        {
                            SpreadSubStates[pair_key].entry_side = "long";
                        }
                        else if (DerivState_pair1.NormalBalance < 0 & DerivState_pair2.NormalBalance > 0)
                        {
                            SpreadSubStates[pair_key].entry_side = "short";
                        }
                    }

                    Console.WriteLine($"entry_side:{SpreadSubStates[pair_key].entry_side},entry_today_signal:{SpreadSubStates[pair_key].entry_today_signal},first_entry_order_done:{SpreadSubStates[pair_key].first_entry_order_done}");
                    Console.WriteLine($",exit_monitoring:{SpreadSubStates[pair_key].exit_monitoring},exit_today_signal:{SpreadSubStates[pair_key].exit_today_signal}");
                    Console.WriteLine($"");
                }



                index_++;
            }

            this.SetSpreadPriceSetBef_Flag = true;
        }
        private void OnTimer(object sender, EventArgs e)
        {

            //직전 날까지의 로그스프레드,RSI 업데이트 완료
            if (ClosingPriceOrdered.Time > DateTime.Now)
            {
                if (working_flag)
                {
                    if (this.SetSpreadPriceSetBef_Flag)
                    {

                        Calculate_Rsi_signal();


                        signal_entry_check_and_order();

                        signal_exit_check_and_order();
                    }


                }
            }
        }

        private void Calculate_Rsi_signal()
        {

            int cnt = 0;
            foreach (string pair_key in SpreadSubStates.Keys)
            {

                string pair1_shortcode = SpreadSubStates[pair_key].Pair1ShortCode;
                string pair2_shortcode = SpreadSubStates[pair_key].Pair2ShortCode;

                var DerivState_pair1 = FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].DerivState;
                var DerivState_pair2 = FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].DerivState;


                SpreadSubStates[pair_key].Pair1NowPrice = SubStates[pair1_shortcode].State.CurrentPrice;
                SpreadSubStates[pair_key].Pair2NowPrice = SubStates[pair2_shortcode].State.CurrentPrice;

                string pair1_name = SubStates[pair1_shortcode].State.Name;
                string pair2_name = SubStates[pair2_shortcode].State.Name;


                if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair1ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair1ShortCode}입니다!");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair1ShortCode}입니다!");
                        writer.WriteLine("");
                    }
                }
                else if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair2ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair2ShortCode}입니다!");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair2ShortCode}입니다!");
                        writer.WriteLine("");
                    }
                }

                if (cnt == 0)
                {
                    Console.WriteLine($"Calculate_Rsi_signal : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                    Console.WriteLine("");
                }
                cnt++;

                Console.WriteLine($"{pair_key}, {pair1_name}_{pair2_name}");

                if (DerivState_pair1.Quote10.Quote == null | DerivState_pair2.Quote10.Quote == null)
                {
                    Console.WriteLine("Calculate_Rsi_signal : Quote 데이터가 null 입니다");
                    Console.WriteLine("");
                    continue;
                }
                else if (!SpreadSubStates[pair_key].Enabled)
                {
                    Console.WriteLine("거래금지 종목이 포함된 페어입니다.");
                    SpreadSubStates[pair_key].Enabled = true;
                    Console.WriteLine("");
                    continue;
                }
                else if (DerivState_pair1.CurrentPrice == 0 | DerivState_pair2.CurrentPrice == 0)
                {
                    Console.WriteLine("DerivState의 CurrentPrice가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }
                else if (SpreadSubStates[pair_key].Pair1NowPrice == 0 | SpreadSubStates[pair_key].Pair2NowPrice == 0)
                {
                    Console.WriteLine("Stock State의 CurrentPrice가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }
                else if (C.AsLong(DerivState_pair1.Quote10.Quote[1].AskPrice) == 0 | C.AsLong(DerivState_pair1.Quote10.Quote[1].BidPrice) == 0 | C.AsLong(DerivState_pair2.Quote10.Quote[1].AskPrice) == 0 | C.AsLong(DerivState_pair2.Quote10.Quote[1].BidPrice) == 0)
                {
                    Console.WriteLine("Quote2호가값이 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }


                //entry 모니터링
                if (object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null) & !SpreadSubStates[pair_key].exit_monitoring)
                {
                    double past1_rsi = Math.Round(SpreadSubStates[pair_key].RSI_past_list[0], 2);

                    long entry_pair1_quantity = 0;
                    long entry_pair2_quantity = 0;


                    // Spread long 진입 이면 pair1 long, pair2 short
                    if (past1_rsi < 50)
                    {
                        SpreadSubStates[pair_key].Pair1NowEntryPrice = (double)C.AsLong(DerivState_pair1.Quote10.Quote[1].AskPrice);
                        SpreadSubStates[pair_key].Pair2NowEntryPrice = (double)C.AsLong(DerivState_pair2.Quote10.Quote[1].BidPrice);

                        entry_pair1_quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].AskQuantity);
                        entry_pair2_quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].BidQuantity);
                        Console.WriteLine($"pair1 long, pair2 short monitoring");

                    }// Spread short 진입 이면 pair1 long, pair2 short
                    else if (past1_rsi > 50)
                    {
                        SpreadSubStates[pair_key].Pair1NowEntryPrice = (double)C.AsLong(DerivState_pair1.Quote10.Quote[1].BidPrice);
                        SpreadSubStates[pair_key].Pair2NowEntryPrice = (double)C.AsLong(DerivState_pair2.Quote10.Quote[1].AskPrice);

                        entry_pair1_quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].BidQuantity);
                        entry_pair2_quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].AskQuantity);
                        Console.WriteLine($"pair1 short, pair2 long monitoring");
                    }

                    //진입 호가를 고려한 RSI 계산
                    SpreadSubStates[pair_key].CalNowRSI();

                    double now_rsi = Math.Round(SpreadSubStates[pair_key].RSI_now_value, 2);

                    double pair1_price_stock = SpreadSubStates[pair_key].Pair1NowPrice;
                    double pair2_price_stock = SpreadSubStates[pair_key].Pair2NowPrice;

                    double pair1_entryprice_now = SpreadSubStates[pair_key].Pair1NowEntryPrice;
                    double pair2_entryprice_now = SpreadSubStates[pair_key].Pair2NowEntryPrice;

                    double pair1_price_past = SpreadSubStates[pair_key].Pair1PriceSet[0];
                    double pair2_price_past = SpreadSubStates[pair_key].Pair2PriceSet[0];

                    double pair1_return = Math.Round(100 * (pair1_entryprice_now / pair1_price_past - 1), 2);
                    double pair2_return = Math.Round(100 * (pair2_entryprice_now / pair2_price_past - 1), 2);

                    double pair1_return_day20 = Math.Round(100 * (pair1_price_stock / SpreadSubStates[pair_key].Pair1PriceSet[20] - 1), 2);
                    double pair2_return_day20 = Math.Round(100 * (pair2_price_stock / SpreadSubStates[pair_key].Pair2PriceSet[20] - 1), 2);

                    double spread_now = Math.Round(Math.Log(pair1_entryprice_now) - SpreadSubStates[pair_key].cointvalue * Math.Log(pair2_entryprice_now), 3);
                    double spread_now_stock = Math.Round(Math.Log(pair1_price_stock) - SpreadSubStates[pair_key].cointvalue * Math.Log(pair2_price_stock), 3);

                    double spread_past = Math.Round(SpreadSubStates[pair_key].logSpreadSet[0], 3);
                    double spread_all_average = Math.Round(SpreadSubStates[pair_key].logSpreadSet.Average(), 3);


                    double available_order_amount = Math.Min(pair1_entryprice_now * entry_pair1_quantity * 0.5, pair2_entryprice_now * entry_pair2_quantity * 0.5) * sfutures_multiple / (10000 * 10000);

                    double bidaskspread_basis = Math.Round(100 * 100 * Math.Abs(spread_now - spread_now_stock), 0);

                    // spraed long진입 체크 

                    bool div_pattern_flag = pair1_return_day20 > 10 | pair2_return_day20 > 10;
                    bool hoga_amount_flag = available_order_amount > 0.2;
                    bool bidaskbasis_flag = bidaskspread_basis < 100;

                    bool long_entry_flag = (spread_now_stock < spread_past) &
                                           (SpreadSubStates[pair_key].RSI_now_value < SpreadSubStates[pair_key].Params.OverSold) &
                                           (spread_now_stock < spread_all_average) &
                                           (!div_pattern_flag) &
                                           hoga_amount_flag &
                                           bidaskbasis_flag;

                    //spread short 진입 체크
                    bool short_entry_flag = (spread_now_stock > spread_past) &
                                            (SpreadSubStates[pair_key].RSI_now_value > SpreadSubStates[pair_key].Params.OverBought) &
                                            (spread_now_stock > spread_all_average) &
                                            (!div_pattern_flag) &
                                            hoga_amount_flag &
                                            bidaskbasis_flag;


                    double target_amount = SpreadSubStates[pair_key].Params.OrderAmount;

                    double Max_Amount_by_Quantity = Math.Min(SpreadSubStates[pair_key].Pair1NowEntryPrice * 2000 * sfutures_multiple, SpreadSubStates[pair_key].Pair2NowEntryPrice * 2000 * sfutures_multiple);

                    target_amount = Math.Min(target_amount, Max_Amount_by_Quantity);

                    if (EntryOrdered.Time > DateTime.Now)
                    {
                        target_amount = target_amount * 0.5;
                    }

                    // spread long 진입 pair1 long, pair2 short

                    Console.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowEntryPrice},pair1_return:{pair1_return}%,pair1_return_day20:{pair1_return_day20}%");
                    Console.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowEntryPrice},pair2_return:{pair2_return}%,pair2_return_day20:{pair2_return_day20}%");
                    Console.WriteLine($"spread_now:{spread_now},spread_now_stock:{spread_now_stock},spread_past:{spread_past},spread_all_average:{spread_all_average}");
                    Console.WriteLine($"spread_change_daily: {Math.Round(100 * (spread_now_stock - spread_past), 2)}%,bid-ask spread: {bidaskspread_basis} BP , {Math.Round(available_order_amount, 2)}억");
                    Console.WriteLine($"RSI_now:{now_rsi},RSI_past:{past1_rsi}");


                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"Calculate_Rsi_signal : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                        writer.WriteLine($"{pair_key}, {pair1_name}_{pair2_name}");
                        writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowEntryPrice},pair1_return:{pair1_return}%,pair1_return_day20:{pair1_return_day20}%");
                        writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowEntryPrice},pair2_return:{pair2_return}%,pair2_return_day20:{pair2_return_day20}%");
                        writer.WriteLine($"spread_now:{spread_now},spread_now_stock:{spread_now_stock},spread_past:{spread_past},spread_all_average:{spread_all_average}");
                        writer.WriteLine($"spread_change_daily: {Math.Round(100 * (spread_now_stock - spread_past), 2)}%,bid-ask spread: {bidaskspread_basis} BP , {Math.Round(available_order_amount, 2)}억");
                        writer.WriteLine($"RSI_now:{now_rsi},RSI_past:{past1_rsi}");
                        writer.WriteLine("");
                    }

                    if (TradeOffButton.Checked)
                    {
                        Console.WriteLine("TradeOffButton.Checked");
                        continue;
                    }
                    else if (EntryOffButton.Checked)
                    {
                        Console.WriteLine("EntryOffButton.Checked");
                        continue;
                    }

                    Console.WriteLine("");

                    if (long_entry_flag)
                    {

                        SpreadSubStates[pair_key].entry_today_signal = true;
                        SpreadSubStates[pair_key].entry_side = "long";

                        //진입해야될 수량 계산
                        SpreadSubStates[pair_key].Pair1TargetOrderQuantity = (long)Math.Round(target_amount / SpreadSubStates[pair_key].Pair1NowEntryPrice / sfutures_multiple);
                        SpreadSubStates[pair_key].Pair2TargetOrderQuantity = (long)Math.Round(target_amount / SpreadSubStates[pair_key].Pair2NowEntryPrice / sfutures_multiple);

                        Console.WriteLine($"Entry long signal {pair_key},target_amount : {target_amount}");
                        Console.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 long ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 short ");
                        Save_spreadsubstates();


                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"Entry long signal {pair_key},target_amount : {target_amount}");
                            writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 long ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 short ");
                            writer.WriteLine("");
                        }
                    }
                    else if (short_entry_flag)
                    {

                        SpreadSubStates[pair_key].entry_today_signal = true;
                        SpreadSubStates[pair_key].entry_side = "short";

                        //진입해야될 수량 계산
                        SpreadSubStates[pair_key].Pair1TargetOrderQuantity = (long)Math.Round(target_amount / SpreadSubStates[pair_key].Pair1NowEntryPrice / sfutures_multiple);
                        SpreadSubStates[pair_key].Pair2TargetOrderQuantity = (long)Math.Round(target_amount / SpreadSubStates[pair_key].Pair2NowEntryPrice / sfutures_multiple);

                        Console.WriteLine($"Entry short signal {pair_key},target_amount : {target_amount}");
                        Console.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 short ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 long ");
                        Save_spreadsubstates();


                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"Entry short signal {pair_key},target_amount : {target_amount}");
                            writer.WriteLine($"{pair1_name}:{SpreadSubStates[pair_key].Pair1TargetOrderQuantity}계약 short ,{pair2_name}:{SpreadSubStates[pair_key].Pair2TargetOrderQuantity}계약 long ");
                            writer.WriteLine("");
                        }
                    }
                }

                //exit 모니터링
                if (!object.ReferenceEquals(SpreadSubStates[pair_key].entry_side, null) & SpreadSubStates[pair_key].exit_monitoring)
                {
                    double total_amount = DerivState_pair1.AveragePrice * Math.Abs(DerivState_pair1.NormalBalance) + DerivState_pair2.AveragePrice * Math.Abs(DerivState_pair2.NormalBalance);

                    double pair1_ratio = DerivState_pair1.AveragePrice * Math.Abs(DerivState_pair1.NormalBalance) / total_amount;
                    double pair2_ratio = DerivState_pair2.AveragePrice * Math.Abs(DerivState_pair2.NormalBalance) / total_amount;

                    double pair1_return_percent = 0;
                    double pair2_return_percent = 0;


                    if ((DerivState_pair1.NormalBalance != 0 & DerivState_pair1.AveragePrice == 0) | (DerivState_pair2.NormalBalance != 0 & DerivState_pair2.AveragePrice == 0))
                    {
                        Console.WriteLine("AveragePrice가 0 입니다");
                        Console.WriteLine("");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine("AveragePrice가 0 입니다");
                            writer.WriteLine("");
                        }
                        continue;
                    }

                    if (DerivState_pair1.NormalBalance == 0 & DerivState_pair2.NormalBalance == 0)
                    {
                        Console.WriteLine("pair1.NormalBalance=0 & pair2.NormalBalance=0");
                        SpreadSubStates[pair_key].exit_today_signal = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine("pair1.NormalBalance=0 & pair2.NormalBalance=0");
                            writer.WriteLine("");
                        }
                        continue;
                    }
                    else if (DerivState_pair1.NormalBalance == 0 | DerivState_pair2.NormalBalance == 0)
                    {   // 한쪽만 체결되거나, 한쪽이 전부다 exit한 상황 : Force Exit 필요!
                        Console.WriteLine($"pair1.NormalBalance:{DerivState_pair1.NormalBalance} & pair2.NormalBalance:{DerivState_pair2.NormalBalance}");
                        Console.WriteLine("pair1, pair2 unbalance!!");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"pair1.NormalBalance:{DerivState_pair1.NormalBalance} & pair2.NormalBalance:{DerivState_pair2.NormalBalance}");
                            writer.WriteLine("pair1, pair2 unbalance!!");
                            writer.WriteLine("");
                        }

                        SpreadSubStates[pair_key].exit_today_signal = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;
                        continue;
                    }

                    // Spread long 진입 이면 ,short exit  , pair1 short, pair2 long
                    if (DerivState_pair1.NormalBalance > 0 & DerivState_pair2.NormalBalance < 0 & SpreadSubStates[pair_key].entry_side == "long")
                    {
                        SpreadSubStates[pair_key].Pair1NowExitPrice = (double)C.AsLong(DerivState_pair1.Quote10.Quote[1].BidPrice);
                        SpreadSubStates[pair_key].Pair2NowExitPrice = (double)C.AsLong(DerivState_pair2.Quote10.Quote[1].AskPrice);
                        //spread long기준
                        pair1_return_percent = (SpreadSubStates[pair_key].Pair1NowExitPrice - DerivState_pair1.AveragePrice) / DerivState_pair1.AveragePrice;
                        pair2_return_percent = (DerivState_pair2.AveragePrice - SpreadSubStates[pair_key].Pair2NowExitPrice) / DerivState_pair2.AveragePrice;

                    }// Spread short 진입 이면 ,long exit , pair1 long, pair2 short
                    else if (DerivState_pair1.NormalBalance < 0 & DerivState_pair2.NormalBalance > 0 & SpreadSubStates[pair_key].entry_side == "short")
                    {
                        SpreadSubStates[pair_key].Pair1NowExitPrice = (double)C.AsLong(DerivState_pair1.Quote10.Quote[1].AskPrice);
                        SpreadSubStates[pair_key].Pair2NowExitPrice = (double)C.AsLong(DerivState_pair2.Quote10.Quote[1].BidPrice);

                        //spread short 기준
                        pair1_return_percent = (DerivState_pair1.AveragePrice - SpreadSubStates[pair_key].Pair1NowExitPrice) / DerivState_pair1.AveragePrice;
                        pair2_return_percent = (SpreadSubStates[pair_key].Pair2NowExitPrice - DerivState_pair2.AveragePrice) / DerivState_pair2.AveragePrice;

                    }

                    double expected_return = (pair1_return_percent * pair1_ratio + pair2_return_percent * pair2_ratio);

                    // spraed long 청산 체크 
                    bool Profit_flag = expected_return > SpreadSubStates[pair_key].Params.TargetRate * SpreadSubStates[pair_key].TakeProfitAdj;
                    bool Losscut_flag = expected_return < SpreadSubStates[pair_key].Params.LossCutRate * SpreadSubStates[pair_key].LossCutAdj;

                    SpreadSubStates[pair_key].CalNowRSI();
                    double now_rsi = Math.Round(SpreadSubStates[pair_key].RSI_now_value, 2);

                    Console.WriteLine($"pair1_exit_price:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair2_exit_price:{SpreadSubStates[pair_key].Pair2NowExitPrice}");
                    Console.WriteLine($"expected_return:{Math.Round(100 * expected_return, 2)}%,pair1_ratio:{Math.Round(pair1_ratio, 2)},pair2_ratio:{Math.Round(pair2_ratio, 2)},now_rsi:{now_rsi}");
                    Console.WriteLine($"Profit_flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.TargetRate * SpreadSubStates[pair_key].TakeProfitAdj, 2)}%,Loss_Flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.LossCutRate * SpreadSubStates[pair_key].LossCutAdj, 2)}%");
                    Console.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair1_avg_price:{DerivState_pair1.AveragePrice},pair1_return_percent:{Math.Round(100 * pair1_return_percent, 2)}%");
                    Console.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowExitPrice},pair2_avg_price:{DerivState_pair2.AveragePrice},pair2_return_percent:{Math.Round(100 * pair2_return_percent, 2)}%");


                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"pair1_exit_price:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair2_exit_price:{SpreadSubStates[pair_key].Pair2NowExitPrice}");
                        writer.WriteLine($"expected_return:{Math.Round(100 * expected_return, 2)}%,pair1_ratio:{Math.Round(pair1_ratio, 2)},pair2_ratio:{Math.Round(pair2_ratio, 2)},now_rsi:{now_rsi}");
                        writer.WriteLine($"Profit_flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.TargetRate * SpreadSubStates[pair_key].TakeProfitAdj, 2)}%,Loss_Flag:{Math.Round(100 * SpreadSubStates[pair_key].Params.LossCutRate * SpreadSubStates[pair_key].LossCutAdj, 2)}%");
                        writer.WriteLine($"pair1_price_now:{SpreadSubStates[pair_key].Pair1NowExitPrice},pair1_avg_price:{DerivState_pair1.AveragePrice},pair1_return_percent:{Math.Round(100 * pair1_return_percent, 2)}%");
                        writer.WriteLine($"pair2_price_now:{SpreadSubStates[pair_key].Pair2NowExitPrice},pair2_avg_price:{DerivState_pair2.AveragePrice},pair2_return_percent:{Math.Round(100 * pair2_return_percent, 2)}%");
                        writer.WriteLine("");
                    }


                    Console.WriteLine("");

                    if (TradeOffButton.Checked) { continue; }

                    if (Profit_flag | Losscut_flag)
                    {
                        SpreadSubStates[pair_key].exit_today_signal = true;
                        SpreadSubStates[pair_key].exit_monitoring = false;

                        if (Profit_flag)
                        {
                            Console.WriteLine($"Exit Profit Take!! {pair_key}");


                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Profit Take!! {pair_key}");
                                writer.WriteLine("");
                            }
                        }
                        else if (Losscut_flag)
                        {
                            Console.WriteLine($"Exit  Loss cut!! {pair_key}");


                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Loss cut!! {pair_key}");
                                writer.WriteLine("");
                            }
                        }



                        Save_spreadsubstates();

                    }

                }

            }
            Console.WriteLine("");
            //Console.WriteLine("");
        }

        private void signal_entry_check_and_order()
        {
            foreach (string pair_key in SpreadSubStates.Keys)
            {


                var DerivState_pair1 = FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].DerivState;
                var DerivState_pair2 = FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].DerivState;


                if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair1ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair1ShortCode}입니다!");
                }
                else if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair2ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair2ShortCode}입니다!");
                }
                else if (EntryOffButton.Checked) { continue; }


                //미체결된 주문 여부 확인

                if (DerivState_pair1.LiveOrders.Count != 0 | DerivState_pair2.LiveOrders.Count != 0)
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시

                    // 미체결 비율 체크하는 로직 필요

                    double unfilled_ratio_pair1 = DerivState_pair1.LiveOrders.Count / (SpreadSubStates[pair_key].Pair1RecentOrderQuantity);
                    double unfilled_ratio_pair2 = DerivState_pair2.LiveOrders.Count / (SpreadSubStates[pair_key].Pair2RecentOrderQuantity);

                    if (unfilled_ratio_pair1 > 0.5 | unfilled_ratio_pair2 > 0.5)
                    {
                        Console.WriteLine($"pair1.LiveOrders.Count:{DerivState_pair1.LiveOrders.Count},pair1_recentorder.count:{SpreadSubStates[pair_key].Pair1RecentOrderQuantity}");
                        Console.WriteLine($"pair2.LiveOrders.Count:{DerivState_pair2.LiveOrders.Count},pair2_recentorder.count:{SpreadSubStates[pair_key].Pair2RecentOrderQuantity}");
                        Console.WriteLine("미체결률이 50%가 넘음");
                        continue;

                    }
                    else
                    {// 주문취소
                        DerivState_pair1.CancelOrders(DerivState_pair1.LiveOrders[0].AskBidType);
                        DerivState_pair2.CancelOrders(DerivState_pair2.LiveOrders[0].AskBidType);
                    }
                }

                //
                long Pair1TargetOrderQuantity = SpreadSubStates[pair_key].Pair1TargetOrderQuantity;
                long Pair2TargetOrderQuantity = SpreadSubStates[pair_key].Pair2TargetOrderQuantity;

                //event loop 직전 Quantity
                long NowQuantity_pair1 = FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].NowQuantity;
                long NowQuantity_pair2 = FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].NowQuantity;

                // 현재 Quantity
                long Real_NowQuantity_pair1 = (long)Math.Abs(DerivState_pair1.NormalBalance);
                long Real_NowQuantity_pair2 = (long)Math.Abs(DerivState_pair2.NormalBalance);

                //double target_amount = SpreadSubStates[pair_key].Params.OrderAmount;
                //bool target_amount_complete = Math.Abs((target_amount - Real_NowAmount_pair1) / Real_NowAmount_pair1) < 0.1 & Math.Abs((target_amount - Real_NowAmount_pair2) / Real_NowAmount_pair2) < 0.1;

                bool target_quantity_complete = (Real_NowQuantity_pair1 == SpreadSubStates[pair_key].Pair1TargetOrderQuantity) & (Real_NowQuantity_pair2 == SpreadSubStates[pair_key].Pair2TargetOrderQuantity);

                if (!SpreadSubStates[pair_key].entry_today_signal)
                {   //entry_today_signal이 존재할시만 주문
                    continue;
                }
                else if (DerivState_pair1.Quote10.Quote == null | DerivState_pair2.Quote10.Quote == null)
                {
                    Console.WriteLine("signal_entry_check : Quote 데이터가 null 입니다");
                    continue;
                }
                else if (!SpreadSubStates[pair_key].Enabled)
                {
                    Console.WriteLine("거래금지 종목이 포함된 페어입니다.");
                    Console.WriteLine("");
                    continue;
                }

                Console.WriteLine($"Entry Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");


                //entry long
                double pair1Ask2Price = C.AsLong(DerivState_pair1.Quote10.Quote[1].AskPrice);
                long pair1Ask2Quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].AskQuantity);
                double pair1Ask4Price = C.AsLong(DerivState_pair1.Quote10.Quote[3].AskPrice);

                double pair2Bid2Price = C.AsLong(DerivState_pair2.Quote10.Quote[1].BidPrice);
                long pair2Bid2Quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].BidQuantity);
                double pair2Bid4Price = C.AsLong(DerivState_pair2.Quote10.Quote[3].BidPrice);

                //entry short
                double pair1Bid2Price = C.AsLong(DerivState_pair1.Quote10.Quote[1].BidPrice);
                long pair1Bid2Quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].BidQuantity);
                double pair1Bid4Price = C.AsLong(DerivState_pair1.Quote10.Quote[3].BidPrice);

                double pair2Ask2Price = C.AsLong(DerivState_pair2.Quote10.Quote[1].AskPrice);
                long pair2Ask2Quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].AskQuantity);
                double pair2Ask4Price = C.AsLong(DerivState_pair2.Quote10.Quote[3].AskPrice);

                long MaxAmountPerOrder = SpreadSubStates[pair_key].Params.MaxAmountPerOrder;


                // bid ask spread 및 베이시스체크
                double pair1_price_stock = SpreadSubStates[pair_key].Pair1NowPrice;
                double pair2_price_stock = SpreadSubStates[pair_key].Pair2NowPrice;
                double spread_now_stock = Math.Round(Math.Log(pair1_price_stock) - SpreadSubStates[pair_key].cointvalue * Math.Log(pair2_price_stock), 3);

                double spread_now = 0;

                if (SpreadSubStates[pair_key].entry_side == "long")
                {
                    spread_now = Math.Round(Math.Log(pair1Ask2Price) - SpreadSubStates[pair_key].cointvalue * Math.Log(pair2Bid2Price), 3);
                }
                else if (SpreadSubStates[pair_key].entry_side == "short")
                {
                    spread_now = Math.Round(Math.Log(pair1Bid2Price) - SpreadSubStates[pair_key].cointvalue * Math.Log(pair2Ask2Price), 3);
                }
                double bid_ask_spread = Math.Round(100 * 100 * Math.Abs(spread_now - spread_now_stock), 0);

                if (bid_ask_spread > 100)
                {

                    Console.WriteLine($"{pair_key} bid ask spread가 {bid_ask_spread} 이므로 진입 금지");
                    Console.WriteLine("");

                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                    {
                        writer.WriteLine($"{pair_key} bid ask spread가 {bid_ask_spread} 이므로 진입 금지");
                        writer.WriteLine("");
                    }
                    continue;
                }

                if (pair1Ask2Price == 0 | pair1Ask4Price == 0 | pair1Bid2Price == 0 | pair1Bid4Price == 0 | pair2Ask2Price == 0 | pair2Ask4Price == 0 | pair2Bid2Price == 0 | pair2Bid4Price == 0)
                {
                    Console.WriteLine("pair1,2 Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }

                MaxAmountPerOrder = 25000000;//,2500만원씩 주문넣기


                double Max_Amount_by_Quantity = Math.Min(pair1_price_stock * 95 * sfutures_multiple, pair2_price_stock * 95 * sfutures_multiple);
                MaxAmountPerOrder = Math.Min(MaxAmountPerOrder, (long)Max_Amount_by_Quantity);

                //오늘 처음 entry order , 첫번째 주문을 내지 않은 조건에서 실행됌.
                if (!SpreadSubStates[pair_key].first_entry_order_done)
                {
                    // spread long 진입 pair1 long, pair2 short
                    if (SpreadSubStates[pair_key].entry_side == "long")
                    {
                        double available_order_amount = Math.Min(pair1Ask2Price * pair1Ask2Quantity * 0.5, pair2Bid2Price * pair2Bid2Quantity * 0.5) * sfutures_multiple;
                        available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                        long pair1_order_quantity = Math.Min(Pair1TargetOrderQuantity, (long)Math.Round(available_order_amount / pair1Ask2Price / sfutures_multiple));
                        long pair2_order_quantity = Math.Min(Pair2TargetOrderQuantity, (long)Math.Round(available_order_amount / pair2Bid2Price / sfutures_multiple));


                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1Ask2Price > 1000000000 | pair2Bid2Price > 1000000000) { continue; }
                        else if (pair1_order_quantity > 99 | pair2_order_quantity > 99)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }



                        //Main.MainLog($"Entry Order long {pair_key}");
                        //Main.MainLog($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");
                        //Main.MainLog($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");

                        Console.WriteLine($"First Entry Order long {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");


                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order long {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 long: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 short: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState_pair1.NewOrder(AskBidType.Bid, pair1Ask4Price, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Ask, pair2Bid4Price, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;


                    }// spread short 진입 pair1 short, pair2 long
                    else if (SpreadSubStates[pair_key].entry_side == "short")
                    {
                        double available_order_amount = Math.Min(pair1Bid2Price * pair1Bid2Quantity * 0.5, pair2Ask2Price * pair2Ask2Quantity * 0.5) * sfutures_multiple;
                        available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                        long pair1_order_quantity = Math.Min(Pair1TargetOrderQuantity, (long)Math.Round(available_order_amount / pair1Bid2Price / sfutures_multiple));
                        long pair2_order_quantity = Math.Min(Pair2TargetOrderQuantity, (long)Math.Round(available_order_amount / pair2Ask2Price / sfutures_multiple));

                        if (pair1_order_quantity <= 0 | pair2_order_quantity <= 0) { continue; }
                        else if (pair1Ask2Price > 1000000000 | pair1Ask2Price > 1000000000) { continue; }
                        else if (pair1_order_quantity > 99 | pair2_order_quantity > 99)
                        {
                            Console.WriteLine($"pair_order_quantity 제한개수 초과");
                            continue;
                        }

                        if (TradeOffButton.Checked) { continue; }

                        //Main.MainLog($"Entry Order short {pair_key}");
                        //Main.MainLog($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Bid2Price: {pair1Bid2Price} pair1_order_quantity:{pair1_order_quantity}");
                        //Main.MainLog($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Ask2Price: {pair2Ask2Price} pair2_order_quantity:{pair2_order_quantity}");


                        Console.WriteLine($"First Entry Order short {pair_key}");
                        Console.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Bid2Price: {pair1Bid2Price} pair1_order_quantity:{pair1_order_quantity}");
                        Console.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Ask2Price: {pair2Ask2Price} pair2_order_quantity:{pair2_order_quantity}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {

                            writer.WriteLine($"First Entry Order short {pair_key}");
                            writer.WriteLine($"Send NewOrder entry pair1 short: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Bid2Price: {pair1Bid2Price} pair1_order_quantity:{pair1_order_quantity}");
                            writer.WriteLine($"Send NewOrder entry pair2 long: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Ask2Price: {pair2Ask2Price} pair2_order_quantity:{pair2_order_quantity}");

                            writer.WriteLine("");
                        }

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        DerivState_pair1.NewOrder(AskBidType.Ask, pair1Bid4Price, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        DerivState_pair2.NewOrder(AskBidType.Bid, pair2Ask4Price, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;


                    }

                    //주문을 냈으므로 True로 변환 , 다음 loop에선 들어가지 않음
                    SpreadSubStates[pair_key].first_entry_order_done = true;
                    Save_spreadsubstates();
                    Console.WriteLine("");
                }
                else // order entry이후 order check, 미체결 및  재진입 여부 판단 
                {

                    if (!target_quantity_complete) //미체결이 없을시 & target_quantity에서 현재 quantity 를 뺀금액만큼 추가주문
                    {

                        //time event 직전 Quantity와 차이가 있을때 체결이 되었다 가정
                        if (NowQuantity_pair1 != Real_NowQuantity_pair1 | NowQuantity_pair2 != Real_NowQuantity_pair2)
                        {
                            Console.WriteLine($"Pair1TargetOrderQuantity:{Pair1TargetOrderQuantity} , Real_NowQuantity_pair1 {Real_NowQuantity_pair1}");
                            Console.WriteLine($"Pair2TargetOrderQuantity:{Pair2TargetOrderQuantity} , Real_NowQuantity_pair2 {Real_NowQuantity_pair2}");

                            // 현재 balance로 amount 업데이트
                            FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].NowQuantity = Real_NowQuantity_pair1;
                            FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].NowQuantity = Real_NowQuantity_pair2;

                            //재주문을 내야하는 quantity를 계산함
                            long reentry_order_quantity_pair1 = SpreadSubStates[pair_key].Pair1TargetOrderQuantity - Real_NowQuantity_pair1;
                            long reentry_order_quantity_pair2 = SpreadSubStates[pair_key].Pair2TargetOrderQuantity - Real_NowQuantity_pair2;


                            if (SpreadSubStates[pair_key].entry_side == "long")
                            {
                                double available_order_amount = Math.Min(pair1Ask2Price * pair1Ask2Quantity * 0.5, pair2Bid2Price * pair2Bid2Quantity * 0.5) * sfutures_multiple;
                                available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, (long)Math.Round(available_order_amount / pair1Ask2Price / sfutures_multiple));
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, (long)Math.Round(available_order_amount / pair2Bid2Price / sfutures_multiple));


                                Console.WriteLine($"Entry reentry Order long {pair_key}");


                                //Main.LogWriter.Write($"Entry reentry Order long {pair_key}");
                                //Main.LogWriter.Write($"Send Reentry NewOrder pair1: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1Ask2Price: {pair1Ask2Price}");
                                //Main.LogWriter.Write($"Send Reentry NewOrder pair2: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2Bid2Price: {pair2Bid2Price}");


                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 99 | reentry_order_quantity_pair2 > 99)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1Ask2Price: {pair1Ask2Price}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 long: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1Ask2Price: {pair1Ask2Price}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Bid, pair1Ask4Price, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;


                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 99 | reentry_order_quantity_pair2 > 99)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2Bid2Price: {pair2Bid2Price}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 short: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2Bid2Price: {pair2Bid2Price}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair2.NewOrder(AskBidType.Ask, pair2Bid4Price, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;


                                }
                            }
                            else if (SpreadSubStates[pair_key].entry_side == "short")
                            {

                                double available_order_amount = Math.Min(pair1Bid2Price * pair1Bid2Quantity * 0.5, pair2Ask2Price * pair2Ask2Quantity * 0.5);
                                available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                                //available_order_amount = 1000000 //100만원씩 주문넣기
                                //체결량에 따라서 pair1, pair2의 주문해야할 금액이 다를 수 있음

                                reentry_order_quantity_pair1 = Math.Min(reentry_order_quantity_pair1, (long)Math.Round(available_order_amount / pair1Bid2Price / sfutures_multiple));
                                reentry_order_quantity_pair2 = Math.Min(reentry_order_quantity_pair2, (long)Math.Round(available_order_amount / pair2Ask2Price / sfutures_multiple));



                                Console.WriteLine($"Entry reentry Order short {pair_key}");


                                //if (reentry_order_quantity_pair1 <= 0 | pair1Ask2Price <= 0) { return; }
                                //else if (reentry_order_quantity_pair2 <= 0 | pair1Ask2Price <= 0) { return; }

                                if (reentry_order_quantity_pair1 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 99 | reentry_order_quantity_pair2 > 99)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }

                                    Console.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1Ask2Price: {pair1Ask2Price}");

                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair1 short: {DerivState_pair1.ShortCode} reentry order_amount:{reentry_order_quantity_pair1} pair1Ask2Price: {pair1Ask2Price}");
                                        writer.WriteLine("");
                                    }

                                    DerivState_pair1.NewOrder(AskBidType.Ask, pair1Bid4Price, reentry_order_quantity_pair1, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = reentry_order_quantity_pair1;



                                }
                                if (reentry_order_quantity_pair2 > 0)
                                {
                                    if (TradeOffButton.Checked) { continue; }
                                    else if (reentry_order_quantity_pair1 > 99 | reentry_order_quantity_pair2 > 99)
                                    {
                                        Console.WriteLine($"pair_order_quantity 제한개수 초과");
                                        continue;
                                    }
                                    Console.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2Bid2Price: {pair2Bid2Price}");


                                    using (StreamWriter writer = new StreamWriter(filePath, append: true))
                                    {
                                        writer.WriteLine($"Send Reentry NewOrder pair2 long: {DerivState_pair2.ShortCode} reentry order_amount:{reentry_order_quantity_pair2} pair2Bid2Price: {pair2Bid2Price}");
                                        writer.WriteLine("");
                                    }
                                    DerivState_pair2.NewOrder(AskBidType.Bid, pair2Ask4Price, reentry_order_quantity_pair2, OrderType.Limit, OrderCondition.Normal);
                                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = reentry_order_quantity_pair2;

                                }
                            }
                            Save_spreadsubstates();
                            Console.WriteLine("");
                        }


                    }
                    else
                    {
                        //Console.WriteLine("이미 target_amount를 채웠습니다");
                        SpreadSubStates[pair_key].exit_monitoring = true;

                        // 진입 주문 함수에 들어오지 못하게 하는 flag
                        SpreadSubStates[pair_key].entry_today_signal = false;

                        //exit에선 현재 잔고를 기반으로 target order quanity가 정해지므로 초기화함
                        SpreadSubStates[pair_key].Pair1TargetOrderQuantity = 0;
                        SpreadSubStates[pair_key].Pair2TargetOrderQuantity = 0;

                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = 0;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = 0;
                        Save_spreadsubstates();

                        Console.WriteLine($"target_quantity_order_complete {pair_key}");

                        using (StreamWriter writer = new StreamWriter(filePath, append: true))
                        {
                            writer.WriteLine($"target_quantity_order_complete {pair_key}");
                            writer.WriteLine("");
                        }
                    }

                }

            }

        }

        private void signal_exit_check_and_order()
        {
            foreach (string pair_key in SpreadSubStates.Keys)
            {

                if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair1ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair1ShortCode}입니다!");
                }
                else if (Main.Prohibited.Contains(SpreadSubStates[pair_key].Pair2ShortCode))
                {
                    SpreadSubStates[pair_key].Enabled = false;
                    Console.WriteLine($"거래금지 종목:{SpreadSubStates[pair_key].Pair2ShortCode}입니다!");
                }

                var DerivState_pair1 = FuturesSubStates[SpreadSubStates[pair_key].Pair1FuturesShortCode].DerivState;
                var DerivState_pair2 = FuturesSubStates[SpreadSubStates[pair_key].Pair2FuturesShortCode].DerivState;

                //미체결된 주문 여부 확인

                if (DerivState_pair1.LiveOrders.Count != 0 | DerivState_pair2.LiveOrders.Count != 0)
                {//페어 둘중 적어도 하나가 미체결 주문이 존재할시

                    // 미체결 비율 체크하는 로직 필요

                    //최근 주문량으로 변경해야함
                    double unfilled_ratio_pair1 = DerivState_pair1.LiveOrders.Count / SpreadSubStates[pair_key].Pair1RecentOrderQuantity;
                    double unfilled_ratio_pair2 = DerivState_pair1.LiveOrders.Count / SpreadSubStates[pair_key].Pair2RecentOrderQuantity;

                    if (unfilled_ratio_pair1 > 0.5 | unfilled_ratio_pair2 > 0.5)
                    {
                        Console.WriteLine("미체결률이 50%가 넘음");
                        continue;

                    }
                    else
                    {// 주문취소
                        if (TradeOffButton.Checked) { continue; }
                        DerivState_pair1.CancelOrders(DerivState_pair1.LiveOrders[0].AskBidType);
                        DerivState_pair2.CancelOrders(DerivState_pair2.LiveOrders[0].AskBidType);
                    }
                }

                // 현재 Quantity
                long Real_NowQuantity_pair1 = (long)Math.Abs(DerivState_pair1.NormalBalance);
                long Real_NowQuantity_pair2 = (long)Math.Abs(DerivState_pair2.NormalBalance);


                bool target_quantity_complete = (Real_NowQuantity_pair1 == 0) & (Real_NowQuantity_pair2 == 0);

                if (DerivState_pair1.Quote10.Quote == null | DerivState_pair2.Quote10.Quote == null)
                {
                    Console.WriteLine("Quote 데이터가 null 입니다");
                    continue;
                }
                else if (!SpreadSubStates[pair_key].exit_today_signal)
                {   //exit_today_signal true 시만 주문
                    continue;
                }
                else if (!SpreadSubStates[pair_key].Enabled)
                {
                    Console.WriteLine("거래금지 종목이 포함된 페어입니다.");
                    Console.WriteLine("");
                    continue;
                }


                Console.WriteLine($"Exit Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                Console.WriteLine("");


                using (StreamWriter writer = new StreamWriter(filePath, append: true))
                {

                    writer.WriteLine($"Exit Check and Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                    writer.WriteLine("");
                }

                //entry long ,exit short
                double pair1Ask2Price = C.AsLong(DerivState_pair1.Quote10.Quote[1].AskPrice);
                double pair1Ask4Price = C.AsLong(DerivState_pair1.Quote10.Quote[3].AskPrice);
                long pair1Ask2Quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].AskQuantity);


                double pair2Bid2Price = C.AsLong(DerivState_pair2.Quote10.Quote[1].BidPrice);
                double pair2Bid4Price = C.AsLong(DerivState_pair2.Quote10.Quote[3].BidPrice);
                long pair2Bid2Quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].BidQuantity);

                //entry short ,exit long
                double pair1Bid2Price = C.AsLong(DerivState_pair1.Quote10.Quote[1].BidPrice);
                double pair1Bid4Price = C.AsLong(DerivState_pair1.Quote10.Quote[3].BidPrice);
                long pair1Bid2Quantity = C.AsLong(DerivState_pair1.Quote10.Quote[0].BidQuantity) + C.AsLong(DerivState_pair1.Quote10.Quote[1].BidQuantity);

                double pair2Ask2Price = C.AsLong(DerivState_pair2.Quote10.Quote[1].AskPrice);
                double pair2Ask4Price = C.AsLong(DerivState_pair2.Quote10.Quote[3].AskPrice);
                long pair2Ask2Quantity = C.AsLong(DerivState_pair2.Quote10.Quote[0].AskQuantity) + C.AsLong(DerivState_pair2.Quote10.Quote[1].AskQuantity);

                long MaxAmountPerOrder = SpreadSubStates[pair_key].Params.MaxAmountPerOrder;

                MaxAmountPerOrder = 25000000;//,2500만원씩 주문넣기

                double Max_Amount_by_Quantity = Math.Min(pair1Ask2Price * 95 * sfutures_multiple, pair2Bid2Price * 95 * sfutures_multiple);
                MaxAmountPerOrder = Math.Min(MaxAmountPerOrder, (long)Max_Amount_by_Quantity);

                if (pair1Ask2Price == 0 | pair1Ask4Price == 0 | pair1Bid2Price == 0 | pair1Bid4Price == 0 | pair2Ask2Price == 0 | pair2Ask4Price == 0 | pair2Bid2Price == 0 | pair2Bid4Price == 0)
                {
                    Console.WriteLine("pair1,2 Bid,Ask Price중 무언가가 0 입니다.");
                    Console.WriteLine("");
                    continue;
                }

                //exit order
                //exit signal 발생시 현재 호가 잔량 만큼이 최대주문
                if (!target_quantity_complete)
                {

                    // spread long 진입 pair1 long, pair2 short
                    if (SpreadSubStates[pair_key].entry_side == "short")
                    {
                        double available_order_amount = Math.Min(pair1Ask2Price * pair1Ask2Quantity * 0.5 * sfutures_multiple, pair2Bid2Price * pair2Bid2Quantity * 0.5 * sfutures_multiple);
                        available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                        long pair1_order_quantity = Math.Min(Real_NowQuantity_pair1, (long)Math.Round(available_order_amount / pair1Ask2Price / sfutures_multiple));
                        long pair2_order_quantity = Math.Min(Real_NowQuantity_pair2, (long)Math.Round(available_order_amount / pair2Bid2Price / sfutures_multiple));


                        if (pair1_order_quantity >= 100 | pair2_order_quantity >= 100)
                        {
                            Console.WriteLine($"pair1_order_quantity 100계약 초과");
                            continue;
                        }
                        //Main.LogWriter.Write($"Entry Order long {pair_key}");
                        //Main.LogWriter.Write($"Send NewOrder exit pair1: {DerivState_pair1.ShortCode} order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");
                        //Main.LogWriter.Write($"Send NewOrder exit pair2: {DerivState_pair2.ShortCode} order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"Exit Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")},pair1_order_quantity:{pair1_order_quantity},pair2_order_quantity:{pair2_order_quantity}");

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        if (pair1_order_quantity > 0)
                        {
                            Console.WriteLine($"Send NewOrder exit pair1 long: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Order short {pair_key}");
                                writer.WriteLine($"Send NewOrder exit pair1 long: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair1_order_quantity:{pair1_order_quantity}");
                                writer.WriteLine("");
                            }

                            DerivState_pair1.NewOrder(AskBidType.Bid, pair1Ask4Price, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);

                        }

                        if (pair2_order_quantity > 0)
                        {
                            Console.WriteLine($"Send NewOrder exit pair2 short: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Order short {pair_key}");
                                writer.WriteLine($"Send NewOrder exit pair2 short: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair2_order_quantity:{pair2_order_quantity}");
                                writer.WriteLine("");
                            }

                            DerivState_pair2.NewOrder(AskBidType.Ask, pair2Bid4Price, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        }

                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;

                    }// spread short 진입 pair1 short, pair2 long
                    else if (SpreadSubStates[pair_key].entry_side == "long")
                    {
                        double available_order_amount = Math.Min(pair1Bid2Price * pair1Bid2Quantity * 0.5 * sfutures_multiple, pair2Ask2Price * pair2Ask2Quantity * 0.5 * sfutures_multiple);
                        available_order_amount = Math.Min(MaxAmountPerOrder, available_order_amount);

                        long pair1_order_quantity = Math.Min(Real_NowQuantity_pair1, (long)Math.Round(available_order_amount / pair1Bid2Price / sfutures_multiple));
                        long pair2_order_quantity = Math.Min(Real_NowQuantity_pair2, (long)Math.Round(available_order_amount / pair2Ask2Price / sfutures_multiple));

                        if (pair1_order_quantity >= 100 | pair2_order_quantity >= 100)
                        {
                            Console.WriteLine($"pair1_order_quantity 100계약 초과");
                            continue;
                        }

                        //Main.LogWriter.Write($"Entry Order long {pair_key}");
                        //Main.LogWriter.Write($"Send NewOrder exit pair1: {DerivState_pair1.ShortCode} order_amount:{available_order_amount} pair1Bid2Price: {pair1Bid2Price} pair1_order_quantity:{pair1_order_quantity}");
                        //Main.LogWriter.Write($"Send NewOrder exit pair2: {DerivState_pair2.ShortCode} order_amount:{available_order_amount} pair2Ask2Price: {pair2Ask2Price} pair2_order_quantity:{pair2_order_quantity}");

                        if (TradeOffButton.Checked) { continue; }


                        Console.WriteLine($"Exit Order : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")},pair1_order_quantity:{pair1_order_quantity},pair2_order_quantity:{pair2_order_quantity}");

                        //AskBidType.Bid: long , AskBidType.Ask: short 
                        if (pair1_order_quantity > 0)
                        {
                            Console.WriteLine($"Send NewOrder exit pair1 short: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair1_order_quantity:{pair1_order_quantity}");

                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Order long {pair_key}");
                                writer.WriteLine($"Send NewOrder exit pair1 short: {DerivState_pair1.ShortCode} available_order_amount:{available_order_amount} pair2Bid2Price: {pair2Bid2Price} pair1_order_quantity:{pair1_order_quantity}");
                                writer.WriteLine("");
                            }

                            DerivState_pair1.NewOrder(AskBidType.Ask, pair1Bid4Price, pair1_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        }

                        if (pair2_order_quantity > 0)
                        {
                            Console.WriteLine($"Send NewOrder exit pair2 long: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair2_order_quantity:{pair2_order_quantity}");


                            using (StreamWriter writer = new StreamWriter(filePath, append: true))
                            {
                                writer.WriteLine($"Exit Order long {pair_key}");
                                writer.WriteLine($"Send NewOrder exit pair2 long: {DerivState_pair2.ShortCode} available_order_amount:{available_order_amount} pair1Ask2Price: {pair1Ask2Price} pair2_order_quantity:{pair2_order_quantity}");
                                writer.WriteLine("");
                            }

                            DerivState_pair2.NewOrder(AskBidType.Bid, pair2Ask4Price, pair2_order_quantity, OrderType.Limit, OrderCondition.Normal);
                        }


                        SpreadSubStates[pair_key].Pair1RecentOrderQuantity = pair1_order_quantity;
                        SpreadSubStates[pair_key].Pair2RecentOrderQuantity = pair2_order_quantity;

                    }

                    //한번 exit주문을 낸 이후엔 다시 exit monitoring 돌게함

                    SpreadSubStates[pair_key].exit_monitoring = true;
                    SpreadSubStates[pair_key].exit_today_signal = false;
                    Save_spreadsubstates();
                }
                else // 
                {

                    Console.WriteLine($"All Complete Exit {pair_key}");
                    //변수 초기화
                    SpreadSubStates[pair_key].entry_today_signal = false;
                    SpreadSubStates[pair_key].exit_today_signal = false;

                    SpreadSubStates[pair_key].first_entry_order_done = false;

                    //SpreadSubStates[pair_key].entry_monitoring = true;
                    SpreadSubStates[pair_key].exit_monitoring = false;

                    SpreadSubStates[pair_key].entry_side = null;

                    SpreadSubStates[pair_key].Pair1RecentOrderQuantity = 0;
                    SpreadSubStates[pair_key].Pair2RecentOrderQuantity = 0;

                    SpreadSubStates.Remove(pair_key);

                    Save_spreadsubstates();

                }
            }
        }



        private void Save_spreadsubstates()
        {
            // Person 클래스 직렬화하여 C:\Users\234046\Desktop\States\StockFuturesPairRsi 경로에 저장 (관리자 권한 필요)
            string filePath = @"C:\Users\234046\Desktop\States\StockFuturesPairRsi\SpreadSubStates.dat";
            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, SpreadSubStates);
            }
            Console.WriteLine("딕셔너리 Spread Sub State Class Update Complete");
        }

        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsDouble(OverSoldBox.Text),
                C.AsDouble(OverBoughtBox.Text),
                C.AsInt(RSIPeriodBox.Text),
                C.AsDouble(TargetRateBox.Text) / 100,
                C.AsDouble(LossCutRateBox.Text) / 100,
                C.AsLong(MaxNotionalAmountBox.Text) * 100_000_000,
                C.AsLong(C.AsDouble(MaxAmountPerOrderBox.Text) * 100_000_000),
                C.AsLong(C.AsDouble(OrderAmountBox.Text) * 10000)
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }


        public void Enable() { this.Enabled = true; }

        private class SubState
        {
            public StockState State;
            public StrategyParams Params;
            public TypeConverter C = new TypeConverter();
            public long PreviousDayMarketCap;
            public int Rank;
            public int Pyramiding;

            public bool Enabled;

            public long NextPyramidingPrice;
            public List<double> PriceSet = new List<double>();
            public List<double> uSet = new List<double>();
            public List<double> dSet = new List<double>();
            public List<double> auSet = new List<double>();
            public List<double> adSet = new List<double>();

            public List<double> RSI = new List<double>();

            public DateTime LastBuyDate { get; internal set; } = new DateTime();

            public void Enable() { this.Enabled = true; }
            public bool IsAble() => this.Enabled;
            public void Disable() { this.Enabled = false; }


            public SubState(StockState state, StrategyParams strategyParams)
            {
                this.State = state;
                this.Params = strategyParams;
                this.PreviousDayMarketCap = State.PreviousDayPrice * State.OutstandingShares;

                var bookValue = State.NormalBalance * State.AverageBuyPrice;
            }


            public void UpdatePrice()
            {
                if (PriceSet.Count() > Params.RSIPeriod && this.IsAble())
                {
                    PriceSet[0] = State.CurrentPrice;
                    //UpdateRSI();
                }
            }

        }

        private class FuturesSubState
        {
            public string StandardCode { get; private set; }
            public string ShortCode { get; private set; }
            public string Name { get; private set; }
            public DerivState DerivState { get; private set; }

            public long NowQuantity = 0;
            public long remainQuantity;

            public FuturesSubState(DerivState deriveState, string standardCode, string shortCode, string name)
            {
                this.DerivState = deriveState;
                this.StandardCode = standardCode;
                this.ShortCode = shortCode;
                this.Name = name;
            }
        }

        [Serializable]
        class SpreadSubState
        {

            public StrategyParams Params;

            public List<double> Pair1PriceSet = new List<double>();
            public List<double> Pair2PriceSet = new List<double>();
            public List<double> logSpreadSet = new List<double>();


            public string Pair1ShortCode;
            public string Pair2ShortCode;

            public string Pair1FuturesShortCode;
            public string Pair2FuturesShortCode;

            public double Pair1NowPrice;
            public double Pair2NowPrice;

            public double Pair1NowEntryPrice;
            public double Pair2NowEntryPrice;

            public double Pair1NowExitPrice;
            public double Pair2NowExitPrice;

            public long Pair1TargetOrderQuantity;
            public long Pair2TargetOrderQuantity;

            public long Pair1RecentOrderQuantity;
            public long Pair2RecentOrderQuantity;

            public double cointvalue;
            public double TakeProfitAdj;
            public double LossCutAdj;
            public double RSI_now_value;

            public List<double> uSet = new List<double>();
            public List<double> dSet = new List<double>();

            public List<double> auSet = new List<double>();
            public List<double> adSet = new List<double>();

            public List<double> RSI_past_list = new List<double>();

            public bool HasPendingRequest = false;
            public string entry_side = null;

            // entry exit signal 발생 flag
            public bool entry_today_signal = false;
            public bool exit_today_signal = false;

            //entry exit signal 이후 첫주문이 나갔는지 여부
            public bool first_entry_order_done = false;

            //exit 모니터링 여부 flag
            public bool exit_monitoring = false;

            public bool Enabled = true;


            public SpreadSubState(StrategyParams strategyParams)
            {
                this.Params = strategyParams;
            }


            public void CalNowRSI()
            {
                //var now_spread = Math.Log(Pair1NowEntryPrice) - cointvalue * Math.Log(Pair2NowEntryPrice);
                var now_spread = Math.Log(Pair1NowPrice) - cointvalue * Math.Log(Pair2NowPrice);
                var delta = now_spread - logSpreadSet[0];

                var u = (delta + Math.Abs(delta)) / 2;
                var d = Math.Abs((delta - Math.Abs(delta)) / 2);

                //uSet[0] = u;
                //dSet[0] = d;

                var au = (u + auSet[0] * (Params.RSIPeriod - 1)) / Params.RSIPeriod;
                var ad = (d + adSet[0] * (Params.RSIPeriod - 1)) / Params.RSIPeriod;

                //auSet[0] = au;
                //adSet[0] = ad;

                var rsi = au / (au + ad) * 100;

                RSI_now_value = rsi;
            }

            public void CalculateRSI()
            {
                uSet = new List<double>();
                dSet = new List<double>();
                RSI_past_list = new List<double>();

                var priceCount = logSpreadSet.Count();

                for (int i = 0; i < priceCount - 1; i++)
                {
                    var delta = logSpreadSet.ElementAt(i) - logSpreadSet.ElementAt(i + 1);

                    var u = (delta + Math.Abs(delta)) / 2;
                    var d = Math.Abs((delta - Math.Abs(delta)) / 2);

                    uSet.Insert(0, u);
                    dSet.Insert(0, d);
                }

                for (int i = 0; i < uSet.Count(); i++)
                {
                    if (i < Params.RSIPeriod)
                    {
                        RSI_past_list.Insert(0, 100.0);
                    }
                    else if (i == Params.RSIPeriod)
                    {
                        var au = uSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        var ad = dSet.ToList().GetRange(0, Params.RSIPeriod).Average();
                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI_past_list.Insert(0, rsi);
                    }
                    else
                    {
                        var u = uSet.ToList()[i];
                        var d = dSet.ToList()[i];

                        var au = (u + auSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;
                        var ad = (d + adSet.First() * (Params.RSIPeriod - 1)) / Params.RSIPeriod;

                        auSet.Insert(0, au);
                        adSet.Insert(0, ad);

                        var rsi = au / (au + ad) * 100;
                        RSI_past_list.Insert(0, rsi);
                    }
                }
                //this.Enable();
            }
        }

        private class SpreadFillBalance
        {

            public int holding;
            public int entry_count;
            public string entry_side;

            public string Pair1ShortCode;
            public string Pair2ShortCode;

            public string Pair1FuturesShortCode;
            public string Pair2FuturesShortCode;

            public double Pair1EntryPrice;
            public double Pair2EntryPrice;

            public List<string> entry_date_list = new List<string>();
        }

        [Serializable]
        internal class StrategyParams
        {
            public double OverSold { get; private set; }
            public double OverBought { get; private set; }
            public int RSIPeriod { get; private set; }

            public double TargetRate { get; private set; }
            public double LossCutRate { get; private set; }
            public long MaxNotionalAmount { get; private set; }
            public long MaxAmountPerOrder { get; private set; }
            public long OrderAmount { get; private set; }
            public void StartegyParams()
            {
            }
            private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
            private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

            public bool Update(double overSold,
                               double overBought,
                               int rsiPeriod,
                               double targetRate,
                               double losscutRate,
                               long maxNotionalAmount,
                               long maxAmountPerOrder,
                               long OrderAmount)
            {
                if (!DoubleGreaterThan(overSold, 0.0) || !DoubleGreaterThan(overBought, 0.0) || !DoubleGreaterThan(targetRate, 0.0))
                    return false;

                if (!DoubleLessThan(losscutRate, 0.0))
                    return false;

                if (DoubleGreaterThan(overSold, overBought) || DoubleGreaterThan(losscutRate, targetRate))
                    return false;

                if (maxAmountPerOrder <= 0 || rsiPeriod <= 0)
                    return false;

                this.OverSold = overSold;
                this.OverBought = overBought;
                this.RSIPeriod = rsiPeriod;

                this.TargetRate = targetRate;
                this.LossCutRate = losscutRate;

                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxAmountPerOrder = maxAmountPerOrder;
                this.OrderAmount = OrderAmount;


                return true;
            }
        }


        private void PauseButton_Click(object sender, EventArgs e)
        {
            working_flag = false;
        }

        private void ResumeButton_Click(object sender, EventArgs e)
        {
            working_flag = true;
        }
    }
}