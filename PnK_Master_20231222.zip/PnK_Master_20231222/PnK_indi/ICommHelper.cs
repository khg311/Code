﻿using System;
using System.Runtime.InteropServices;
using System.Net.NetworkInformation;

namespace PnK_indi
{
    public class ICommHelper
    {
        #region CommLib dll functions
        [DllImport("CommLib.dll", EntryPoint = "InitComm")]
        public static extern bool _initComm(IntPtr hParent, string lpszSvrIp);

        [DllImport("CommLib.dll", EntryPoint = "InitCommLogin")]
        public static extern bool _initCommLogin(IntPtr hParent, string lpszSvrIp);

        [DllImport("CommLib.dll", EntryPoint = "ReleaseComm")]
        public static extern void _releaseComm();

        [DllImport("CommLib.dll", EntryPoint = "AddHwnd")]
        public static extern int _addHwnd(IntPtr hWnd, string lpszCaption);

        [DllImport("CommLib.dll", EntryPoint = "DelHwnd")]
        public static extern void _delHwnd(int nCommKey);

        [DllImport("CommLib.dll", EntryPoint = "SetLocalIP")]
        public static extern void _setLocalIP(string lpszLocalIP);

        [DllImport("CommLib.dll", EntryPoint = "GetLocalIP")]
        public static extern IntPtr _getLocalIP();

        [DllImport("CommLib.dll", EntryPoint = "RequestData")]
        public static extern int _requestData(int nCommKey, string lpszTR, string lpszInput, int nLen, string lpszSvr = " ", string lpszDist = "  ");

        [DllImport("CommLib.dll", EntryPoint = "RegistAccount")]
        public static extern int _registAccount(string lpszInput, int nLen);

        [DllImport("CommLib.dll", EntryPoint = "RegistReal")]
        public static extern int _registReal(string lpszKey, IntPtr lpArg);

        [DllImport("CommLib.dll", EntryPoint = "ReleaseReal")]
        public static extern int _releaseReal(int nRealKey);

        [DllImport("CommLib.dll", EntryPoint = "RequestVersion")]
        public static extern int _requestVersion(int nCommKey, string lpszTR, string lpszInput, int nLen);

        [DllImport("CommLib.dll", EntryPoint = "SendKospiFOOrder")]
        public static extern int _sendKospiFOOrder(int nCommKey, string lpszOrder, int nLen);

        [DllImport("CommLib.dll", EntryPoint = "SendStockOrder")]
        public static extern int _sendStockOrder(int nCommKey, string lpszOrder, int nLen);

        [DllImport("CommLib.dll", EntryPoint = "WriteLog")]
        public static extern void _writeLog(string lpszLog);

        [DllImport("CommLib.dll", EntryPoint = "RunFTPSender")]
        public static extern void _runFTPSender(string lpszPath);

        [DllImport("CommLib.dll", EntryPoint = "SetLoginId")]
        public static extern void _setLoginId(string lpszLoginId);
        #endregion

        private readonly MainWindow Main;

        private Safety Safety => Main.Safety;
        public string EmployeeId { get; private set; }
        public string FundCode { get; private set; }
        public string AccountNumber { get; private set; }
        public string IpAddress { get; private set; }
        public string MacAddress { get; private set; }
        public string Today { get; private set; }

        // 차세대 신규
        public string AlgoStrategyTypeCode { get; set; }
        public string TraderId { get; set; }
        public string OrderGroupNumber { get; set; }
        public string SmpCode { get; set; }

        public ICommHelper(MainWindow main)
        {
            this.Main = main;
            Today = DateTime.Now.ToString("yyyyMMdd");
            this.IpAddress = GetIpAddress();
            this.MacAddress = GetMacAddress();
        }

        public void Set(string employeeId, string fundCode, AlgoInfo algoInfo)
        {
            this.EmployeeId = employeeId;
            this.FundCode = fundCode;
            this.AccountNumber = "09999900" + this.FundCode;

            // 차세대 신규
            this.AlgoStrategyTypeCode = algoInfo.AlgoStrategyTypeCode;
            this.TraderId = algoInfo.TraderId;
            this.OrderGroupNumber = algoInfo.OrderGroupNumber;
            this.SmpCode = algoInfo.SmpCode;
        }

        private string GetIpAddress()
        {
            var ip = "";
            string[] _splited = Marshal.PtrToStringAnsi(GetLocalIP()).Split('.');
            foreach (var _s in _splited)
                ip += (Convert.ToInt32(_s)).ToString("D3");

            return ip;
        }

        private string GetMacAddress() => NetworkInterface.GetAllNetworkInterfaces()[0].GetPhysicalAddress().ToString();

        #region using dll functions
        public bool InitComm(IntPtr hParent, string lpszSvrIp) => _initComm(hParent, lpszSvrIp);

        public bool InitCommLogin(IntPtr hParent, string lpszSvrIp) => _initCommLogin(hParent, lpszSvrIp);

        public void ReleaseComm() => _releaseComm();

        public int AddHwnd(IntPtr hWnd, string lpszCaption) => _addHwnd(hWnd, lpszCaption);

        public void DellHwnd(int nCommKey) => _delHwnd(nCommKey);

        public void SetLocalIP(string lpszLocalIP) => _setLocalIP(lpszLocalIP);

        public IntPtr GetLocalIP() => _getLocalIP();

        public int RequestData(int nCommKey, string lpszTR, string lpszInput, int nLen) => _requestData(nCommKey, lpszTR, lpszInput, nLen);

        public int RegistAccount(string lpszInput, int nLen) => _registAccount(lpszInput, nLen);

        public int RegistReal(string lpszKey, IntPtr lpArg) => _registReal(lpszKey, lpArg);

        public int ReleaseReal(int nRealKey) => _releaseReal(nRealKey);

        public int RequestVersion(int nCommKey, string lpszTR, string lpszInput, int nLen) => _requestVersion(nCommKey, lpszTR, lpszInput, nLen);

        public int SendKospiFOOrder(int nCommKey, string lpszOrder, int nLen) => _sendKospiFOOrder(nCommKey, lpszOrder, nLen);

        public int SendStockOrder(int nCommKey, string lpszOrder, int nLen) => _sendStockOrder(nCommKey, lpszOrder, nLen);

        public void WriteLog(string lpszLog) => _writeLog(lpszLog);

        public void RunFTPSender(string lpszPath) => _runFTPSender(lpszPath);

        public void SetLoginId(string lpszLoginId) => _setLoginId(lpszLoginId);
        #endregion

        public void RequestQ30003(int n_mKey, string loginId, string fundCode)
        {
            IN_Q30003 in_Q30003;
            in_Q30003.login_id = loginId.ToCharArray();
            in_Q30003.fund_no = fundCode.ToCharArray();
            in_Q30003.isu_gb = "1".ToCharArray();
            in_Q30003.tr_gb = "0".ToCharArray();
            in_Q30003.che_gb = "0".ToCharArray();
            in_Q30003.next_key = "9999999999".PadRight(18).ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q30003));
            Marshal.StructureToPtr(in_Q30003, ptr, false);

            RequestData(n_mKey, "Q30003", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q30003)), Marshal.SizeOf(in_Q30003));
        }

        public void RequestQ32001(int n_mKey, string loginId, string fundCode)
        {
            IN_Q32001 in_Q32001;
            in_Q32001.login_id = loginId.ToCharArray();
            in_Q32001.fund_no = fundCode.ToCharArray();
            in_Q32001.isu_gb = "1".ToCharArray();
            in_Q32001.tr_gb = "0".ToCharArray();
            in_Q32001.che_gb = "0".ToCharArray();
            in_Q32001.isu_cd = "ALL     ".ToCharArray();
            in_Q32001.next_key = "9999999999".PadRight(18).ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q32001));
            Marshal.StructureToPtr(in_Q32001, ptr, false);

            RequestData(n_mKey, "Q32001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q32001)), Marshal.SizeOf(in_Q32001));
        }

        public void RequestQ36001(int n_mKey, string loginId, string fundCode)
        {
            IN_Q36001 in_Q36001;
            in_Q36001.login_id = loginId.ToCharArray();
            in_Q36001.fund_no = fundCode.ToCharArray();
            in_Q36001.isu_gb = "1".ToCharArray();
            in_Q36001.tr_gb = "0".ToCharArray();
            in_Q36001.che_gb = "0".ToCharArray();
            in_Q36001.next_key = "9999999999".PadRight(18).ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q36001));
            Marshal.StructureToPtr(in_Q36001, ptr, false);

            RequestData(n_mKey, "Q36001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q36001)), Marshal.SizeOf(in_Q36001));
        }

        public void RequestQ40001(int n_mKey, string fundCode, string loginId)
        {
            IN_Q40001 in_Q40001;
            in_Q40001.fund_no = fundCode.ToCharArray();
            in_Q40001.login_id = loginId.ToCharArray();
            in_Q40001.isu_gb = "0".ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q40001));
            Marshal.StructureToPtr(in_Q40001, ptr, false);

            RequestData(n_mKey, "Q40001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q40001)), Marshal.SizeOf(in_Q40001));
        }

        public void RequestQ42001(int n_mKey, string fundCode, string loginId)
        {
            IN_Q42001 in_Q42001;
            in_Q42001.fund_no = fundCode.ToCharArray();
            in_Q42001.login_id = loginId.ToCharArray();
            in_Q42001.isu_gb = "0".ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q42001));
            Marshal.StructureToPtr(in_Q42001, ptr, false);

            RequestData(n_mKey, "Q42001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q42001)), Marshal.SizeOf(in_Q42001));
        }

        public void RequestQ46001(int n_mKey, string fundCode, string loginId)
        {
            IN_Q46001 in_Q46001;
            in_Q46001.fund_no = fundCode.ToCharArray();
            in_Q46001.login_id = loginId.ToCharArray();
            in_Q46001.isu_gb = "0".ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q46001));
            Marshal.StructureToPtr(in_Q46001, ptr, false);

            RequestData(n_mKey, "Q46001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q46001)), Marshal.SizeOf(in_Q46001));
        }

        public void RequestQ70001(int n_mKey, string loginId, string fundCode)
        {
            IN_Q70001 in_Q70001;
            in_Q70001.login_id = loginId.ToCharArray();
            in_Q70001.fund_no = fundCode.ToCharArray();
            in_Q70001.che_gb = "1".ToCharArray();
            in_Q70001.meme_gb = "0".ToCharArray();
            in_Q70001.isu_cd = "AAAAAAAA".PadRight(8).ToCharArray();
            in_Q70001.next_key = "AAAAAAAAAAAAAAAAAA".PadRight(18).ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q70001));
            Marshal.StructureToPtr(in_Q70001, ptr, false);

            RequestData(n_mKey, "Q70001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q70001)), Marshal.SizeOf(in_Q70001));
        }

        public void RequestQ80001(int n_mKey, string fundCode, string loginId)
        {
            IN_Q80001 in_Q80001;
            in_Q80001.fund_no = fundCode.ToCharArray();
            in_Q80001.login_id = loginId.ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q80001));
            Marshal.StructureToPtr(in_Q80001, ptr, false);

            RequestData(n_mKey, "Q80001", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q80001)), Marshal.SizeOf(in_Q80001));
        }

        public void RequestQ90025(int n_mKey, string loginId)
        {
            IN_Q90025 in_Q90025;
            in_Q90025.login_id = loginId.ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q90025));
            Marshal.StructureToPtr(in_Q90025, ptr, false);

            RequestData(n_mKey, "Q90025", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q90025)), Marshal.SizeOf(in_Q90025));
        }

        public void RequestQ90056(int n_mKey)
        {
            IN_Q90056 in_Q90056;
            in_Q90056.dummy = " ".ToCharArray();
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(in_Q90056));
            Marshal.StructureToPtr(in_Q90056, ptr, false);

            RequestData(n_mKey, "Q90056", Marshal.PtrToStringAnsi(ptr, Marshal.SizeOf(in_Q90056)), Marshal.SizeOf(in_Q90056));
        }

        public int NewOrder(Order order)
        {
            if (order.Quantity <= 0)
                return -1;


            if (Safety.CheckCrossTrade(order))
            {
                Main.LogWriter.Write("cross trade is detected");
                return -1;
            }

            if (Safety.CheckLimits(order))
            {
                Main.LogWriter.Write("check the limit to send new order");
                return -1;
            }

            var state = Main.States[order.StandardCode];

            STOCK_ORDER_PACKET packet = new STOCK_ORDER_PACKET();

            packet.header.tr_code = "TATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = "S".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(5).ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.isu_cd = order.ShortCode.PadRight(8).ToCharArray();
            packet.header.secu_grpid = state.SecurityGroupId.ToString().ToCharArray();
            packet.header.ord_gb = " ".ToCharArray();
            packet.header.loan_cls = "N".ToCharArray();
            packet.header.tord_no = "0000000000".ToCharArray();
            packet.header.org_tord_no = "".PadRight(10).ToCharArray();
            packet.header.shtsl_cls = "N".ToCharArray();
            packet.header.shtsl_flg = "0".ToCharArray();
            packet.header.org_ord_prc = "".PadRight(7).ToCharArray();
            packet.header.filler = "  ".ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10001".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "0000000000".ToCharArray();
            packet.krxOrder.org_ord_no = "".PadRight(10).ToCharArray();
            packet.krxOrder.code = order.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)order.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "1".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();
            packet.krxOrder.cnt = order.Quantity.ToString("D10").ToCharArray();
            packet.krxOrder.price = order.Price.ToString("D11").ToCharArray();
            packet.krxOrder.ord_type = ((char)order.OrderType).ToString().ToCharArray();
            packet.krxOrder.ord_cond = ((char)order.OrderCondition).ToString().ToCharArray();
            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "0".PadRight(5).ToCharArray();
            packet.krxOrder.stock_trade_code = "0".ToCharArray();
            packet.krxOrder.medo_type_code = "00".ToCharArray();
            packet.krxOrder.singb = "10".ToCharArray();
            packet.krxOrder.witak = "30".ToCharArray();
            packet.krxOrder.witakcomp_num = "".PadRight(5).ToCharArray();
            packet.krxOrder.pt_type_code = "31".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "".PadRight(12).ToCharArray();
            packet.krxOrder.gyejwa_type_code = "00".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "00".ToCharArray();
            packet.krxOrder.kukga = "410".ToCharArray();
            packet.krxOrder.tocode = "1000".ToCharArray();
            packet.krxOrder.foreign = "00".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = "".PadRight(9).ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_code = AlgoStrategyTypeCode.ToCharArray();
            packet.krxOrder.trdr_id = TraderId.ToCharArray();
            packet.krxOrder.ord_grp_no = OrderGroupNumber.ToCharArray();
            packet.krxOrder.smp_cd = SmpCode.ToCharArray();

            STOCKORDER_HOIWON hoiwon = new STOCKORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = " ".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.ord_no = "         ".ToCharArray();
            hoiwon.emp_no = EmployeeId.ToCharArray();
            hoiwon.mkt_cls = ((char)state.MarketType).ToString().ToCharArray();
            hoiwon.filler2 = "   ".ToCharArray();
            hoiwon.loan_cls = packet.header.loan_cls;
            hoiwon.filler3 = "                    ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            Main.LogWriter.Write($"NewOrder {order.ShortCode} {order.AskBidType} {order.Quantity} @ {order.Price}");
            return SendStockOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }

        public int NewOrder(Order order, bool checkCrossTrade)
        {
            if (order.Quantity <= 0)
                return -1;


            if (checkCrossTrade && Safety.CheckCrossTrade(order))
            {
                Main.LogWriter.Write("cross trade is detected");
                return -1;
            }

            if (Safety.CheckLimits(order))
            {
                Main.LogWriter.Write("check the limit to send new order");
                return -1;
            }

            var state = Main.States[order.StandardCode];

            STOCK_ORDER_PACKET packet = new STOCK_ORDER_PACKET();

            packet.header.tr_code = "TATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = "S".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(5).ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.isu_cd = order.ShortCode.PadRight(8).ToCharArray();
            packet.header.secu_grpid = state.SecurityGroupId.ToString().ToCharArray();
            packet.header.ord_gb = " ".ToCharArray();
            packet.header.loan_cls = "N".ToCharArray();
            packet.header.tord_no = "0000000000".ToCharArray();
            packet.header.org_tord_no = "".PadRight(10).ToCharArray();
            packet.header.shtsl_cls = "N".ToCharArray();
            packet.header.shtsl_flg = "0".ToCharArray();
            packet.header.org_ord_prc = "".PadRight(7).ToCharArray();
            packet.header.filler = "  ".ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10001".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "0000000000".ToCharArray();
            packet.krxOrder.org_ord_no = "".PadRight(10).ToCharArray();
            packet.krxOrder.code = order.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)order.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "1".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();
            packet.krxOrder.cnt = order.Quantity.ToString("D10").ToCharArray();
            packet.krxOrder.price = order.Price.ToString("D11").ToCharArray();
            packet.krxOrder.ord_type = ((char)order.OrderType).ToString().ToCharArray();
            packet.krxOrder.ord_cond = ((char)order.OrderCondition).ToString().ToCharArray();
            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "0".PadRight(5).ToCharArray();
            packet.krxOrder.stock_trade_code = "0".ToCharArray();
            packet.krxOrder.medo_type_code = "00".ToCharArray();
            packet.krxOrder.singb = "10".ToCharArray();
            packet.krxOrder.witak = "30".ToCharArray();
            packet.krxOrder.witakcomp_num = "".PadRight(5).ToCharArray();
            packet.krxOrder.pt_type_code = "31".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "".PadRight(12).ToCharArray();
            packet.krxOrder.gyejwa_type_code = "00".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "00".ToCharArray();
            packet.krxOrder.kukga = "410".ToCharArray();
            packet.krxOrder.tocode = "1000".ToCharArray();
            packet.krxOrder.foreign = "00".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = "".PadRight(9).ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_code = AlgoStrategyTypeCode.ToCharArray();
            packet.krxOrder.trdr_id = TraderId.ToCharArray();
            packet.krxOrder.ord_grp_no = OrderGroupNumber.ToCharArray();
            packet.krxOrder.smp_cd = SmpCode.ToCharArray();

            STOCKORDER_HOIWON hoiwon = new STOCKORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = " ".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.ord_no = "         ".ToCharArray();
            hoiwon.emp_no = EmployeeId.ToCharArray();
            hoiwon.mkt_cls = ((char)state.MarketType).ToString().ToCharArray();
            hoiwon.filler2 = "   ".ToCharArray();
            hoiwon.loan_cls = packet.header.loan_cls;
            hoiwon.filler3 = "                    ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            Main.LogWriter.Write($"NewOrder {order.ShortCode} {order.AskBidType} {order.Quantity} @ {order.Price}");
            return SendStockOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }

        public int AmendOrder(LiveOrder liveOrder, long price)
        {
            if (price <= 0)
                return -1;

            if (Safety.CheckCrossTrade(new Order(liveOrder.StandardCode, liveOrder.ShortCode, liveOrder.AskBidType, price, liveOrder.LiveQuantity, liveOrder.OrderType, liveOrder.OrderCondition)))
            {
                Main.LogWriter.Write("cross trade is detected");
                return -1;
            }

            if (Safety.CheckOrderNumberLimit())
                return -1;

            var state = Main.States[liveOrder.StandardCode];
            STOCK_ORDER_PACKET packet = new STOCK_ORDER_PACKET();

            packet.header.tr_code = "TATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = "S".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(5).ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.isu_cd = liveOrder.ShortCode.PadRight(8).ToCharArray();
            packet.header.secu_grpid = state.SecurityGroupId.ToString().ToCharArray();
            packet.header.ord_gb = " ".ToCharArray();
            packet.header.loan_cls = "N".ToCharArray();
            packet.header.tord_no = "0000000000".ToCharArray();
            packet.header.org_tord_no = liveOrder.TOrderId.ToString("D10").ToCharArray();
            packet.header.shtsl_cls = "N".ToCharArray();
            packet.header.shtsl_flg = "0".ToCharArray();
            packet.header.org_ord_prc = liveOrder.Price.ToString("D7").ToCharArray();
            packet.header.filler = "  ".ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10002".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "0000000000".ToCharArray();
            packet.krxOrder.org_ord_no = liveOrder.OrderId.ToString("D10").ToCharArray();
            packet.krxOrder.code = liveOrder.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)liveOrder.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "2".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();
            packet.krxOrder.cnt = liveOrder.LiveQuantity.ToString("D10").ToCharArray();
            packet.krxOrder.price = price.ToString("D11").ToCharArray();
            packet.krxOrder.ord_type = ((char)liveOrder.OrderType).ToString().ToCharArray();
            packet.krxOrder.ord_cond = ((char)liveOrder.OrderCondition).ToString().ToCharArray();
            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "0".PadRight(5).ToCharArray();
            packet.krxOrder.stock_trade_code = "0".ToCharArray();
            packet.krxOrder.medo_type_code = "00".ToCharArray();
            packet.krxOrder.singb = "10".ToCharArray();
            packet.krxOrder.witak = "30".ToCharArray();
            packet.krxOrder.witakcomp_num = "     ".ToCharArray();
            packet.krxOrder.pt_type_code = "31".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "            ".ToCharArray();
            packet.krxOrder.gyejwa_type_code = "00".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "00".ToCharArray();
            packet.krxOrder.kukga = "410".ToCharArray();
            packet.krxOrder.tocode = "1000".ToCharArray();
            packet.krxOrder.foreign = "00".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = "".PadRight(9).ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_code = " ".ToCharArray();
            packet.krxOrder.trdr_id = "      ".ToCharArray();
            packet.krxOrder.ord_grp_no = "  ".ToCharArray();
            packet.krxOrder.smp_cd = " ".ToCharArray();

            STOCKORDER_HOIWON hoiwon = new STOCKORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = " ".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.ord_no = "         ".ToCharArray();
            hoiwon.emp_no = EmployeeId.ToCharArray();
            hoiwon.mkt_cls = ((char)state.MarketType).ToString().ToCharArray();
            hoiwon.filler2 = "   ".ToCharArray();
            hoiwon.loan_cls = packet.header.loan_cls;
            hoiwon.filler3 = "                    ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            return SendStockOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }

        public int CancelOrder(LiveOrder liveOrder)
        {
            var state = Main.States[liveOrder.StandardCode];
            STOCK_ORDER_PACKET packet = new STOCK_ORDER_PACKET();

            packet.header.tr_code = "TATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = "S".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(5).ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.isu_cd = liveOrder.ShortCode.PadRight(8).ToCharArray();
            packet.header.secu_grpid = state.SecurityGroupId.ToString().ToCharArray();
            packet.header.ord_gb = " ".ToCharArray();
            packet.header.loan_cls = "N".ToCharArray();
            packet.header.tord_no = "".PadRight(10).ToCharArray();
            packet.header.org_tord_no = liveOrder.TOrderId.ToString("D10").ToCharArray();
            packet.header.shtsl_cls = "N".ToCharArray();
            packet.header.shtsl_flg = "0".ToCharArray();
            packet.header.org_ord_prc = liveOrder.Price.ToString("D7").ToCharArray();
            packet.header.filler = "  ".ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10003".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "0000000000".ToCharArray();
            packet.krxOrder.org_ord_no = liveOrder.OrderId.ToString("D10").ToCharArray();
            packet.krxOrder.code = liveOrder.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)liveOrder.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "3".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();
            packet.krxOrder.cnt = liveOrder.LiveQuantity.ToString("D10").ToCharArray();
            packet.krxOrder.price = liveOrder.Price.ToString("D11").ToCharArray();
            packet.krxOrder.ord_type = ((char)liveOrder.OrderType).ToString().ToCharArray();
            packet.krxOrder.ord_cond = ((char)liveOrder.OrderCondition).ToString().ToCharArray();
            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "0".PadRight(5).ToCharArray();
            packet.krxOrder.stock_trade_code = "0".ToCharArray();
            packet.krxOrder.medo_type_code = "00".ToCharArray();
            packet.krxOrder.singb = "10".ToCharArray();
            packet.krxOrder.witak = "30".ToCharArray();
            packet.krxOrder.witakcomp_num = "     ".ToCharArray();
            packet.krxOrder.pt_type_code = "31".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "            ".ToCharArray();
            packet.krxOrder.gyejwa_type_code = "00".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "00".ToCharArray();
            packet.krxOrder.kukga = "410".ToCharArray();
            packet.krxOrder.tocode = "1000".ToCharArray();
            packet.krxOrder.foreign = "00".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = DateTime.Now.ToString("HHmmssfff").ToCharArray();
            //packet.krxOrder.ord_declare_gb = "0".ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_code = " ".ToCharArray();
            packet.krxOrder.trdr_id = "      ".ToCharArray();
            packet.krxOrder.ord_grp_no = "  ".ToCharArray();
            packet.krxOrder.smp_cd = " ".ToCharArray();

            STOCKORDER_HOIWON hoiwon = new STOCKORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = " ".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.ord_no = "         ".ToCharArray();
            hoiwon.emp_no = EmployeeId.ToCharArray();
            hoiwon.mkt_cls = ((char)state.MarketType).ToString().ToCharArray();
            hoiwon.filler2 = "   ".ToCharArray();
            hoiwon.loan_cls = packet.header.loan_cls;
            hoiwon.filler3 = "                    ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            return SendStockOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }

        public int NewOrder(DerivOrder order)
        {
            if (order.Quantity <= 0 )
                return -1;

            if (Safety.CheckCrossTrade(order))
            {
                Main.LogWriter.Write("cross trade is detected");
                return -1;
            }

            if (Safety.CheckLimits(order))
            {
                Main.LogWriter.Write("check the limit to send new order");
                return -1;
            }

            DERIV_ORDER_PACKET packet = new DERIV_ORDER_PACKET();

            packet.header.tr_code = "DATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = " ".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(4).ToCharArray();
            packet.header.org_ord_prc = "00000000000".ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.mkt_kind = " ".ToCharArray();
            packet.header.mkt_offset = " ".ToCharArray();
            packet.header.resord_gb = " ".ToCharArray();
            packet.header.unfair_chk_yn = "Y".ToCharArray();
            packet.header.nego_ord_gb = " ".ToCharArray();
            packet.header.filler = "".PadRight(13).ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10001".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "".PadRight(11).ToCharArray();
            packet.krxOrder.org_ord_no = "".PadRight(11).ToCharArray();
            packet.krxOrder.code = order.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)order.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "1".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();

            packet.krxOrder.cnt = order.Quantity.ToString("D10").ToCharArray();
            if (order.StandardCode.StartsWith("KR4101") || order.StandardCode.StartsWith("KR4106"))
                packet.krxOrder.price = order.Price.ToString("00000000.00").ToCharArray();
            else
                packet.krxOrder.price = ((long)order.Price).ToString("D11").ToCharArray();
            packet.krxOrder.ord_type = ((char)order.OrderType).ToString().ToCharArray();
            packet.krxOrder.ord_cond = ((char)order.OrderCondition).ToString().ToCharArray();

            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "0".PadRight(5).ToCharArray();

            packet.krxOrder.stock_trade_code = "0".ToCharArray();
            packet.krxOrder.medo_type_code = "00".ToCharArray();
            packet.krxOrder.singb = "10".ToCharArray();
            packet.krxOrder.witak = "31".ToCharArray();
            packet.krxOrder.witakcomp_num = "     ".ToCharArray();
            packet.krxOrder.pt_type_code = "00".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "            ".ToCharArray();

            packet.krxOrder.gyejwa_type_code = "41".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "11".ToCharArray();
            packet.krxOrder.kukga = "410".ToCharArray();
            packet.krxOrder.tocode = "1000".ToCharArray();
            packet.krxOrder.foreign = "00".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = "".PadRight(9).ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_cd = AlgoStrategyTypeCode.ToCharArray();
            packet.krxOrder.trdr_id = TraderId.ToCharArray();
            packet.krxOrder.ord_grp_no = OrderGroupNumber.ToCharArray();
            packet.krxOrder.smp_cd = SmpCode.ToCharArray();

            DERIVORDER_HOIWON hoiwon = new DERIVORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = "3".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.filler2 = "         ".ToCharArray();
            hoiwon.login_id = EmployeeId.ToCharArray();
            hoiwon.client_idx = "     ".ToCharArray();
            hoiwon.auto_order = " ".ToCharArray();
            hoiwon.filler3 = "                   ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            Main.LogWriter.Write(($"NewOrder {order.StandardCode} {order.AskBidType} {order.Quantity} @ {order.Price}"));
            return SendKospiFOOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }

        public int CancelOrder(DerivLiveOrder liveOrder)
        {
            DERIV_ORDER_PACKET packet = new DERIV_ORDER_PACKET();

            packet.header.tr_code = "DATA".ToCharArray();
            packet.header.ack_gubun = " ".ToCharArray();
            packet.header.seq_no = "000000000".ToCharArray();
            packet.header.emp_no = EmployeeId.ToCharArray();
            packet.header.fund_no = FundCode.ToCharArray();
            packet.header.mkt_l_cls = " ".ToCharArray();
            packet.header.com_gb = "1".ToCharArray();
            packet.header.res_code = "".PadRight(4).ToCharArray();
            packet.header.org_ord_prc = "".PadRight(11).ToCharArray();
            packet.header.mysvr_gb = " ".ToCharArray();
            packet.header.mkt_kind = " ".ToCharArray();
            packet.header.mkt_offset = " ".ToCharArray();
            packet.header.resord_gb = " ".ToCharArray();
            packet.header.unfair_chk_yn = "Y".ToCharArray();
            packet.header.nego_ord_gb = " ".ToCharArray();
            packet.header.filler = " ".PadRight(13).ToCharArray();

            packet.krxOrder.hseq = "00000000000".ToCharArray();
            packet.krxOrder.trans_code = "TCHODR10003".ToCharArray();
            packet.krxOrder.board_id = "G1".ToCharArray();
            packet.krxOrder.memberno = "00002".ToCharArray();
            packet.krxOrder.bpno = "00999".ToCharArray();
            packet.krxOrder.ord_no = "".PadRight(10).ToCharArray();
            packet.krxOrder.org_ord_no = liveOrder.OrderId.ToString().PadRight(10).ToCharArray();
            packet.krxOrder.code = liveOrder.StandardCode.ToCharArray();
            packet.krxOrder.mmgubun = ((char)liveOrder.AskBidType).ToString().ToCharArray();
            packet.krxOrder.hogagb = "3".ToCharArray();
            packet.krxOrder.gyejwa = AccountNumber.ToCharArray();

            packet.krxOrder.cnt = liveOrder.OrderQuantity.ToString("D10").ToCharArray();
            if (liveOrder.StandardCode.StartsWith("KR4101") || liveOrder.StandardCode.StartsWith("KR4106"))
                packet.krxOrder.price = "00000000.00".ToCharArray();
            else
                packet.krxOrder.price = "00000000000".ToCharArray();
            packet.krxOrder.ord_type = " ".ToCharArray();
            packet.krxOrder.ord_cond = " ".ToCharArray();

            packet.krxOrder.market_ord_num = "0".ToCharArray();
            packet.krxOrder.stock_state_id = "".PadRight(5).ToCharArray();

            packet.krxOrder.stock_trade_code = " ".ToCharArray();
            packet.krxOrder.medo_type_code = "  ".ToCharArray();
            packet.krxOrder.singb = "  ".ToCharArray();
            packet.krxOrder.witak = "  ".ToCharArray();
            packet.krxOrder.witakcomp_num = "     ".ToCharArray();
            packet.krxOrder.pt_type_code = "00".ToCharArray();
            packet.krxOrder.sub_stock_gyejwa = "            ".ToCharArray();

            packet.krxOrder.gyejwa_type_code = "  ".ToCharArray();
            packet.krxOrder.gyejwa_margin_cod = "  ".ToCharArray();
            packet.krxOrder.kukga = "   ".ToCharArray();
            packet.krxOrder.tocode = "    ".ToCharArray();
            packet.krxOrder.foreign = "  ".ToCharArray();
            packet.krxOrder.meache_gb = "1".ToCharArray();
            packet.krxOrder.term_no = IpAddress.ToCharArray();
            packet.krxOrder.mac_addr = MacAddress.ToCharArray();
            packet.krxOrder.ord_date = Today.ToCharArray();
            packet.krxOrder.ord_time = "".PadRight(9).ToCharArray();

            // 차세대 항목
            packet.krxOrder.me_grp_no = "00".ToCharArray();
            packet.krxOrder.min_trdvol = "0000000000".ToCharArray();
            packet.krxOrder.algo_stgy_tp_cd = " ".ToCharArray();
            packet.krxOrder.trdr_id = "      ".ToCharArray();
            packet.krxOrder.ord_grp_no = "  ".ToCharArray();
            packet.krxOrder.smp_cd = " ".ToCharArray();

            DERIVORDER_HOIWON hoiwon = new DERIVORDER_HOIWON();
            hoiwon.fep_org = "         ".ToCharArray();
            hoiwon.market_flag = "3".ToCharArray();
            hoiwon.channel_flag = "  ".ToCharArray();
            hoiwon.system_flag = "  ".ToCharArray();
            hoiwon.filler1 = "      ".ToCharArray();
            hoiwon.filler2 = "         ".ToCharArray();
            hoiwon.login_id = "      ".ToCharArray();
            hoiwon.client_idx = "     ".ToCharArray();
            hoiwon.auto_order = " ".ToCharArray();
            hoiwon.filler3 = "                   ".ToCharArray();
            packet.krxOrder.hoiwon = hoiwon;

            var ptrOrder = Marshal.AllocHGlobal(Marshal.SizeOf(packet));
            Marshal.StructureToPtr(packet, ptrOrder, false);

            Main.LogWriter.Write(($"CancelOrder {liveOrder.ShortCode} {liveOrder.AskBidType} {liveOrder.Price} @ {liveOrder.OrderQuantity} {liveOrder.LiveQuantity}"));
            return SendKospiFOOrder(Main.n_mKey, Marshal.PtrToStringAnsi(ptrOrder, Marshal.SizeOf(packet)), Marshal.SizeOf(packet));
        }
    }
}
