﻿
namespace PnK_indi
{
    partial class MainWindow
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.StartWorkerButton = new System.Windows.Forms.Button();
            this.EmployeeIdLabel = new System.Windows.Forms.Label();
            this.EmployeeIdTextBox = new System.Windows.Forms.TextBox();
            this.SystemLoggingBox = new System.Windows.Forms.RichTextBox();
            this.StrategyLabel = new System.Windows.Forms.Label();
            this.StrategyTextBox = new System.Windows.Forms.TextBox();
            this.SafetyLabel = new System.Windows.Forms.Label();
            this.SingleOrderAmountLimitTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SingleAssetPositionLimitTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FundPositionLimitTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.IntervalTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.OrderNumberLimitTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.FundBalanceAmountTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.FundCodeTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.DisableClearButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.DisableTextBox = new System.Windows.Forms.TextBox();
            this.DisableView = new System.Windows.Forms.DataGridView();
            this.MarketInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.Open10Close16RadioButton = new System.Windows.Forms.RadioButton();
            this.Open10Close15RadioButton = new System.Windows.Forms.RadioButton();
            this.Open9Close15RadioButton = new System.Windows.Forms.RadioButton();
            this.StockFuturesPairRsi = new System.Windows.Forms.Button();
            this.StockFuturesPairStd = new System.Windows.Forms.Button();
            this.StockRsiSwing = new System.Windows.Forms.Button();
            this.StockFuturesBasis = new System.Windows.Forms.Button();
            this.IndexFuturesPairBreak = new System.Windows.Forms.Button();
            this.IndexFuturesHLBreak = new System.Windows.Forms.Button();
            this.StockVoltyBreakMidCapButton = new System.Windows.Forms.Button();
            this.StockVoltyBreakLargeCapButton = new System.Windows.Forms.Button();
            this.IndexFutureVoltyDailyButton = new System.Windows.Forms.Button();
            this.StockRsiReversionButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DisableView)).BeginInit();
            this.MarketInfoGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // StartWorkerButton
            // 
            this.StartWorkerButton.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StartWorkerButton.Location = new System.Drawing.Point(12, 12);
            this.StartWorkerButton.Name = "StartWorkerButton";
            this.StartWorkerButton.Size = new System.Drawing.Size(243, 22);
            this.StartWorkerButton.TabIndex = 0;
            this.StartWorkerButton.Text = "RUN";
            this.StartWorkerButton.UseVisualStyleBackColor = true;
            this.StartWorkerButton.Click += new System.EventHandler(this.StartWorkerButton_Click);
            // 
            // EmployeeIdLabel
            // 
            this.EmployeeIdLabel.AutoSize = true;
            this.EmployeeIdLabel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.EmployeeIdLabel.Location = new System.Drawing.Point(15, 48);
            this.EmployeeIdLabel.Name = "EmployeeIdLabel";
            this.EmployeeIdLabel.Size = new System.Drawing.Size(88, 12);
            this.EmployeeIdLabel.TabIndex = 4;
            this.EmployeeIdLabel.Text = "Employee ID";
            // 
            // EmployeeIdTextBox
            // 
            this.EmployeeIdTextBox.Location = new System.Drawing.Point(110, 44);
            this.EmployeeIdTextBox.Name = "EmployeeIdTextBox";
            this.EmployeeIdTextBox.ReadOnly = true;
            this.EmployeeIdTextBox.Size = new System.Drawing.Size(207, 21);
            this.EmployeeIdTextBox.TabIndex = 5;
            this.EmployeeIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SystemLoggingBox
            // 
            this.SystemLoggingBox.Location = new System.Drawing.Point(12, 126);
            this.SystemLoggingBox.Name = "SystemLoggingBox";
            this.SystemLoggingBox.Size = new System.Drawing.Size(504, 325);
            this.SystemLoggingBox.TabIndex = 6;
            this.SystemLoggingBox.Text = "";
            // 
            // StrategyLabel
            // 
            this.StrategyLabel.AutoSize = true;
            this.StrategyLabel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StrategyLabel.Location = new System.Drawing.Point(28, 77);
            this.StrategyLabel.Name = "StrategyLabel";
            this.StrategyLabel.Size = new System.Drawing.Size(59, 12);
            this.StrategyLabel.TabIndex = 10;
            this.StrategyLabel.Text = "Strategy";
            // 
            // StrategyTextBox
            // 
            this.StrategyTextBox.Location = new System.Drawing.Point(110, 72);
            this.StrategyTextBox.Name = "StrategyTextBox";
            this.StrategyTextBox.ReadOnly = true;
            this.StrategyTextBox.Size = new System.Drawing.Size(207, 21);
            this.StrategyTextBox.TabIndex = 11;
            this.StrategyTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SafetyLabel
            // 
            this.SafetyLabel.AutoSize = true;
            this.SafetyLabel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SafetyLabel.Location = new System.Drawing.Point(536, 267);
            this.SafetyLabel.Name = "SafetyLabel";
            this.SafetyLabel.Size = new System.Drawing.Size(61, 16);
            this.SafetyLabel.TabIndex = 15;
            this.SafetyLabel.Text = "Safeties";
            // 
            // SingleOrderAmountLimitTextBox
            // 
            this.SingleOrderAmountLimitTextBox.Location = new System.Drawing.Point(640, 295);
            this.SingleOrderAmountLimitTextBox.Name = "SingleOrderAmountLimitTextBox";
            this.SingleOrderAmountLimitTextBox.Size = new System.Drawing.Size(128, 21);
            this.SingleOrderAmountLimitTextBox.TabIndex = 17;
            this.SingleOrderAmountLimitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SingleOrderAmountLimitTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SingleOrderAmountLimitTextBox_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(534, 298);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 14);
            this.label1.TabIndex = 16;
            this.label1.Text = "1회 주문금액 한도";
            // 
            // SingleAssetPositionLimitTextBox
            // 
            this.SingleAssetPositionLimitTextBox.Location = new System.Drawing.Point(640, 322);
            this.SingleAssetPositionLimitTextBox.Name = "SingleAssetPositionLimitTextBox";
            this.SingleAssetPositionLimitTextBox.Size = new System.Drawing.Size(128, 21);
            this.SingleAssetPositionLimitTextBox.TabIndex = 19;
            this.SingleAssetPositionLimitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SingleAssetPositionLimitTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SingleAssetPositionLimitTextBox_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(534, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 14);
            this.label2.TabIndex = 18;
            this.label2.Text = "종목당 포지션 한도";
            // 
            // FundPositionLimitTextBox
            // 
            this.FundPositionLimitTextBox.Location = new System.Drawing.Point(640, 349);
            this.FundPositionLimitTextBox.Name = "FundPositionLimitTextBox";
            this.FundPositionLimitTextBox.Size = new System.Drawing.Size(128, 21);
            this.FundPositionLimitTextBox.TabIndex = 21;
            this.FundPositionLimitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.FundPositionLimitTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FundPositionLimit_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(534, 352);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 14);
            this.label3.TabIndex = 20;
            this.label3.Text = "펀드 포지션 한도";
            // 
            // IntervalTextBox
            // 
            this.IntervalTextBox.Location = new System.Drawing.Point(640, 376);
            this.IntervalTextBox.Name = "IntervalTextBox";
            this.IntervalTextBox.Size = new System.Drawing.Size(128, 21);
            this.IntervalTextBox.TabIndex = 23;
            this.IntervalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.IntervalTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.IntervalTextBox_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(534, 379);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 14);
            this.label4.TabIndex = 22;
            this.label4.Text = "Interval (s)";
            // 
            // OrderNumberLimitTextBox
            // 
            this.OrderNumberLimitTextBox.Location = new System.Drawing.Point(640, 403);
            this.OrderNumberLimitTextBox.Name = "OrderNumberLimitTextBox";
            this.OrderNumberLimitTextBox.Size = new System.Drawing.Size(128, 21);
            this.OrderNumberLimitTextBox.TabIndex = 25;
            this.OrderNumberLimitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.OrderNumberLimitTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OrderNumberLimitTextBox_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(534, 406);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 14);
            this.label5.TabIndex = 24;
            this.label5.Text = "Interval당 주문횟수";
            // 
            // FundBalanceAmountTextBox
            // 
            this.FundBalanceAmountTextBox.Location = new System.Drawing.Point(638, 226);
            this.FundBalanceAmountTextBox.Name = "FundBalanceAmountTextBox";
            this.FundBalanceAmountTextBox.Size = new System.Drawing.Size(128, 21);
            this.FundBalanceAmountTextBox.TabIndex = 27;
            this.FundBalanceAmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(575, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 14);
            this.label6.TabIndex = 26;
            this.label6.Text = "펀드 포지션";
            // 
            // FundCodeTextBox
            // 
            this.FundCodeTextBox.Location = new System.Drawing.Point(110, 99);
            this.FundCodeTextBox.Name = "FundCodeTextBox";
            this.FundCodeTextBox.ReadOnly = true;
            this.FundCodeTextBox.Size = new System.Drawing.Size(207, 21);
            this.FundCodeTextBox.TabIndex = 29;
            this.FundCodeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(20, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 12);
            this.label7.TabIndex = 28;
            this.label7.Text = "Fund Code";
            // 
            // DisableClearButton
            // 
            this.DisableClearButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisableClearButton.ForeColor = System.Drawing.Color.Red;
            this.DisableClearButton.Location = new System.Drawing.Point(1205, 18);
            this.DisableClearButton.Name = "DisableClearButton";
            this.DisableClearButton.Size = new System.Drawing.Size(71, 23);
            this.DisableClearButton.TabIndex = 115;
            this.DisableClearButton.Text = "CLEAR";
            this.DisableClearButton.UseVisualStyleBackColor = true;
            this.DisableClearButton.Click += new System.EventHandler(this.DisableClearButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1025, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 14);
            this.label10.TabIndex = 114;
            this.label10.Text = "Disabled";
            // 
            // DisableTextBox
            // 
            this.DisableTextBox.Location = new System.Drawing.Point(1085, 20);
            this.DisableTextBox.Name = "DisableTextBox";
            this.DisableTextBox.Size = new System.Drawing.Size(100, 21);
            this.DisableTextBox.TabIndex = 113;
            this.DisableTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.DisableTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DisableTextBox_KeyDown);
            // 
            // DisableView
            // 
            this.DisableView.AllowUserToAddRows = false;
            this.DisableView.AllowUserToDeleteRows = false;
            this.DisableView.AllowUserToResizeRows = false;
            this.DisableView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DisableView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DisableView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DisableView.Location = new System.Drawing.Point(1028, 48);
            this.DisableView.Name = "DisableView";
            this.DisableView.ReadOnly = true;
            this.DisableView.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.DisableView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DisableView.RowTemplate.Height = 23;
            this.DisableView.Size = new System.Drawing.Size(248, 396);
            this.DisableView.TabIndex = 112;
            // 
            // MarketInfoGroupBox
            // 
            this.MarketInfoGroupBox.Controls.Add(this.Open10Close16RadioButton);
            this.MarketInfoGroupBox.Controls.Add(this.Open10Close15RadioButton);
            this.MarketInfoGroupBox.Controls.Add(this.Open9Close15RadioButton);
            this.MarketInfoGroupBox.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarketInfoGroupBox.Location = new System.Drawing.Point(12, 457);
            this.MarketInfoGroupBox.Name = "MarketInfoGroupBox";
            this.MarketInfoGroupBox.Size = new System.Drawing.Size(384, 42);
            this.MarketInfoGroupBox.TabIndex = 119;
            this.MarketInfoGroupBox.TabStop = false;
            this.MarketInfoGroupBox.Text = "Market Info";
            // 
            // Open10Close16RadioButton
            // 
            this.Open10Close16RadioButton.AutoSize = true;
            this.Open10Close16RadioButton.Location = new System.Drawing.Point(259, 18);
            this.Open10Close16RadioButton.Name = "Open10Close16RadioButton";
            this.Open10Close16RadioButton.Size = new System.Drawing.Size(110, 18);
            this.Open10Close16RadioButton.TabIndex = 2;
            this.Open10Close16RadioButton.TabStop = true;
            this.Open10Close16RadioButton.Text = "10:00 - 16:30";
            this.Open10Close16RadioButton.UseVisualStyleBackColor = true;
            this.Open10Close16RadioButton.CheckedChanged += new System.EventHandler(this.Open9Close15RadioButton_CheckedChanged);
            // 
            // Open10Close15RadioButton
            // 
            this.Open10Close15RadioButton.AutoSize = true;
            this.Open10Close15RadioButton.Location = new System.Drawing.Point(139, 18);
            this.Open10Close15RadioButton.Name = "Open10Close15RadioButton";
            this.Open10Close15RadioButton.Size = new System.Drawing.Size(110, 18);
            this.Open10Close15RadioButton.TabIndex = 1;
            this.Open10Close15RadioButton.TabStop = true;
            this.Open10Close15RadioButton.Text = "10:00 - 15:30";
            this.Open10Close15RadioButton.UseVisualStyleBackColor = true;
            this.Open10Close15RadioButton.CheckedChanged += new System.EventHandler(this.Open9Close15RadioButton_CheckedChanged);
            // 
            // Open9Close15RadioButton
            // 
            this.Open9Close15RadioButton.AutoSize = true;
            this.Open9Close15RadioButton.Location = new System.Drawing.Point(19, 18);
            this.Open9Close15RadioButton.Name = "Open9Close15RadioButton";
            this.Open9Close15RadioButton.Size = new System.Drawing.Size(110, 18);
            this.Open9Close15RadioButton.TabIndex = 0;
            this.Open9Close15RadioButton.TabStop = true;
            this.Open9Close15RadioButton.Text = "09:00 - 15:30";
            this.Open9Close15RadioButton.UseVisualStyleBackColor = true;
            this.Open9Close15RadioButton.CheckedChanged += new System.EventHandler(this.Open9Close15RadioButton_CheckedChanged);
            // 
            // StockFuturesPairRsi
            // 
            this.StockFuturesPairRsi.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StockFuturesPairRsi.Location = new System.Drawing.Point(779, 12);
            this.StockFuturesPairRsi.Name = "StockFuturesPairRsi";
            this.StockFuturesPairRsi.Size = new System.Drawing.Size(227, 31);
            this.StockFuturesPairRsi.TabIndex = 120;
            this.StockFuturesPairRsi.Text = "Stock Futures Pair Rsi (6900)";
            this.StockFuturesPairRsi.UseVisualStyleBackColor = true;
            this.StockFuturesPairRsi.Click += new System.EventHandler(this.StockFuturesPairRsi_Click);
            // 
            // StockFuturesPairStd
            // 
            this.StockFuturesPairStd.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StockFuturesPairStd.Location = new System.Drawing.Point(779, 58);
            this.StockFuturesPairStd.Name = "StockFuturesPairStd";
            this.StockFuturesPairStd.Size = new System.Drawing.Size(227, 31);
            this.StockFuturesPairStd.TabIndex = 121;
            this.StockFuturesPairStd.Text = "Stock Futures Pair Std (6901)";
            this.StockFuturesPairStd.UseVisualStyleBackColor = true;
            this.StockFuturesPairStd.Click += new System.EventHandler(this.StockFuturesPairStd_Click);
            // 
            // StockRsiSwing
            // 
            this.StockRsiSwing.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StockRsiSwing.Location = new System.Drawing.Point(779, 104);
            this.StockRsiSwing.Name = "StockRsiSwing";
            this.StockRsiSwing.Size = new System.Drawing.Size(227, 31);
            this.StockRsiSwing.TabIndex = 122;
            this.StockRsiSwing.Text = "Stock Rsi Swing (6902)";
            this.StockRsiSwing.UseVisualStyleBackColor = true;
            this.StockRsiSwing.Click += new System.EventHandler(this.StockRsiSwing_Click);
            // 
            // StockFuturesBasis
            // 
            this.StockFuturesBasis.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.StockFuturesBasis.Location = new System.Drawing.Point(779, 156);
            this.StockFuturesBasis.Name = "StockFuturesBasis";
            this.StockFuturesBasis.Size = new System.Drawing.Size(227, 31);
            this.StockFuturesBasis.TabIndex = 123;
            this.StockFuturesBasis.Text = "Stock Futures Basis (6903)";
            this.StockFuturesBasis.UseVisualStyleBackColor = true;
            this.StockFuturesBasis.Click += new System.EventHandler(this.StockFuturesBasis_Click);
            // 
            // IndexFuturesPairBreak
            // 
            this.IndexFuturesPairBreak.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.IndexFuturesPairBreak.Location = new System.Drawing.Point(779, 202);
            this.IndexFuturesPairBreak.Name = "IndexFuturesPairBreak";
            this.IndexFuturesPairBreak.Size = new System.Drawing.Size(227, 31);
            this.IndexFuturesPairBreak.TabIndex = 124;
            this.IndexFuturesPairBreak.Text = "Index Futures Pair Break (6906)";
            this.IndexFuturesPairBreak.UseVisualStyleBackColor = true;
            this.IndexFuturesPairBreak.Click += new System.EventHandler(this.IndexFuturesPairBreak_Click);
            // 
            // IndexFuturesHLBreak
            // 
            this.IndexFuturesHLBreak.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.IndexFuturesHLBreak.Location = new System.Drawing.Point(779, 254);
            this.IndexFuturesHLBreak.Name = "IndexFuturesHLBreak";
            this.IndexFuturesHLBreak.Size = new System.Drawing.Size(227, 31);
            this.IndexFuturesHLBreak.TabIndex = 125;
            this.IndexFuturesHLBreak.Text = "Index Futures HLBreak (6907)";
            this.IndexFuturesHLBreak.UseVisualStyleBackColor = true;
            this.IndexFuturesHLBreak.Click += new System.EventHandler(this.IndexFuturesHLBreak_Click);
            // 
            // StockVoltyBreakMidCapButton
            // 
            this.StockVoltyBreakMidCapButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StockVoltyBreakMidCapButton.Location = new System.Drawing.Point(537, 124);
            this.StockVoltyBreakMidCapButton.Name = "StockVoltyBreakMidCapButton";
            this.StockVoltyBreakMidCapButton.Size = new System.Drawing.Size(227, 31);
            this.StockVoltyBreakMidCapButton.TabIndex = 130;
            this.StockVoltyBreakMidCapButton.Text = "Stock Volty Break Mid Cap";
            this.StockVoltyBreakMidCapButton.UseVisualStyleBackColor = true;
            this.StockVoltyBreakMidCapButton.Click += new System.EventHandler(this.StockVoltyBreakMidCapButton_Click);
            // 
            // StockVoltyBreakLargeCapButton
            // 
            this.StockVoltyBreakLargeCapButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StockVoltyBreakLargeCapButton.Location = new System.Drawing.Point(537, 87);
            this.StockVoltyBreakLargeCapButton.Name = "StockVoltyBreakLargeCapButton";
            this.StockVoltyBreakLargeCapButton.Size = new System.Drawing.Size(227, 31);
            this.StockVoltyBreakLargeCapButton.TabIndex = 129;
            this.StockVoltyBreakLargeCapButton.Text = "Stock Volty Break Large Cap";
            this.StockVoltyBreakLargeCapButton.UseVisualStyleBackColor = true;
            this.StockVoltyBreakLargeCapButton.Click += new System.EventHandler(this.StockVoltyBreakLargeCapButton_Click);
            // 
            // IndexFutureVoltyDailyButton
            // 
            this.IndexFutureVoltyDailyButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IndexFutureVoltyDailyButton.Location = new System.Drawing.Point(537, 50);
            this.IndexFutureVoltyDailyButton.Name = "IndexFutureVoltyDailyButton";
            this.IndexFutureVoltyDailyButton.Size = new System.Drawing.Size(227, 31);
            this.IndexFutureVoltyDailyButton.TabIndex = 128;
            this.IndexFutureVoltyDailyButton.Text = "Volty Index";
            this.IndexFutureVoltyDailyButton.UseVisualStyleBackColor = true;
            this.IndexFutureVoltyDailyButton.Click += new System.EventHandler(this.IndexFutureVoltyDailyButton_Click);
            // 
            // StockRsiReversionButton
            // 
            this.StockRsiReversionButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StockRsiReversionButton.Location = new System.Drawing.Point(537, 13);
            this.StockRsiReversionButton.Name = "StockRsiReversionButton";
            this.StockRsiReversionButton.Size = new System.Drawing.Size(227, 31);
            this.StockRsiReversionButton.TabIndex = 127;
            this.StockRsiReversionButton.Text = "Stock Rsi Reversion";
            this.StockRsiReversionButton.UseVisualStyleBackColor = true;
            this.StockRsiReversionButton.Click += new System.EventHandler(this.StockRsiReversionButton_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1287, 524);
            this.Controls.Add(this.StockVoltyBreakMidCapButton);
            this.Controls.Add(this.StockVoltyBreakLargeCapButton);
            this.Controls.Add(this.IndexFutureVoltyDailyButton);
            this.Controls.Add(this.StockRsiReversionButton);
            this.Controls.Add(this.IndexFuturesHLBreak);
            this.Controls.Add(this.IndexFuturesPairBreak);
            this.Controls.Add(this.StockFuturesBasis);
            this.Controls.Add(this.StockRsiSwing);
            this.Controls.Add(this.StockFuturesPairStd);
            this.Controls.Add(this.StockFuturesPairRsi);
            this.Controls.Add(this.MarketInfoGroupBox);
            this.Controls.Add(this.DisableClearButton);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.DisableTextBox);
            this.Controls.Add(this.DisableView);
            this.Controls.Add(this.FundCodeTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.FundBalanceAmountTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.OrderNumberLimitTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.IntervalTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.FundPositionLimitTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SingleAssetPositionLimitTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SingleOrderAmountLimitTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SafetyLabel);
            this.Controls.Add(this.StrategyTextBox);
            this.Controls.Add(this.StrategyLabel);
            this.Controls.Add(this.SystemLoggingBox);
            this.Controls.Add(this.EmployeeIdTextBox);
            this.Controls.Add(this.EmployeeIdLabel);
            this.Controls.Add(this.StartWorkerButton);
            this.Name = "MainWindow";
            this.Text = "Main";
            ((System.ComponentModel.ISupportInitialize)(this.DisableView)).EndInit();
            this.MarketInfoGroupBox.ResumeLayout(false);
            this.MarketInfoGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartWorkerButton;
        private System.Windows.Forms.Label EmployeeIdLabel;
        private System.Windows.Forms.TextBox EmployeeIdTextBox;
        private System.Windows.Forms.RichTextBox SystemLoggingBox;
        private System.Windows.Forms.Label StrategyLabel;
        private System.Windows.Forms.TextBox StrategyTextBox;
        private System.Windows.Forms.Label SafetyLabel;
        private System.Windows.Forms.TextBox SingleOrderAmountLimitTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SingleAssetPositionLimitTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox FundPositionLimitTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox IntervalTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox OrderNumberLimitTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox FundBalanceAmountTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox FundCodeTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button DisableClearButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox DisableTextBox;
        private System.Windows.Forms.DataGridView DisableView;
        private System.Windows.Forms.GroupBox MarketInfoGroupBox;
        public System.Windows.Forms.RadioButton Open10Close16RadioButton;
        public System.Windows.Forms.RadioButton Open10Close15RadioButton;
        public System.Windows.Forms.RadioButton Open9Close15RadioButton;
        private System.Windows.Forms.Button StockFuturesPairRsi;
        private System.Windows.Forms.Button StockFuturesPairStd;
        private System.Windows.Forms.Button StockRsiSwing;
        private System.Windows.Forms.Button StockFuturesBasis;
        private System.Windows.Forms.Button IndexFuturesPairBreak;
        private System.Windows.Forms.Button IndexFuturesHLBreak;
        private System.Windows.Forms.Button StockVoltyBreakMidCapButton;
        private System.Windows.Forms.Button StockVoltyBreakLargeCapButton;
        private System.Windows.Forms.Button IndexFutureVoltyDailyButton;
        private System.Windows.Forms.Button StockRsiReversionButton;
    }
}

