﻿using System;
using System.Runtime.InteropServices;

namespace PnK_indi
{
    public struct REGIST_SISE_INFO
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = LENGTH.STANDARD_CODE_LEN)]
        public char[] StandardCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] PacketType;

        public int PacketTypeLength;
        
        public IntPtr hWnd;
        
        public int nPriority;
    }

    public struct COPYDATASTRUCT
    {
        public IntPtr dwData;

        public IntPtr cbData;

        public IntPtr lpData;
    }

    public class ISiseHelper
    {
        #region SiseLinkLib.dll functions
        [DllImport("SiseLinkLib.dll", EntryPoint = "ExitOK")]
        public static extern void _exitOK();

        [DllImport("SiseLinkLib.dll", EntryPoint = "SetSiseHwnd")]
        public static extern bool _setSiseHwnd(IntPtr hWnd);

        [DllImport("SiseLinkLib.dll", EntryPoint = "GetSiseHwnd")]
        public static extern IntPtr _getSiseHwnd();

        [DllImport("SiseLinkLib.dll", EntryPoint = "RunSise")]
        public static extern void _runSise(string lpszEXE, bool isReCreate);

        [DllImport("SiseLinkLib.dll", EntryPoint = "ConnectSise")]
        public static extern void _connectSise(string lpszSvrIp);

        [DllImport("SiseLinkLib.dll", EntryPoint = "ExitSise")]
        public static extern void _exitSise();

        [DllImport("SiseLinkLib.dll", EntryPoint = "Regist")]
        public static extern void _regist(IntPtr pArg);

        [DllImport("SiseLinkLib.dll", EntryPoint = "Release")]
        public static extern void _release(IntPtr pArg);

        [DllImport("SiseLinkLib.dll", EntryPoint = "ReleaseAll")]
        public static extern void _releaseAll(IntPtr pArg);

        [DllImport("SiseLinkLib.dll", EntryPoint = "RegistCaption")]
        public static extern void _registCaption(IntPtr hWnd, string lpszCaption);

        [DllImport("SiseLinkLib.dll", EntryPoint = "ReleaseCaption")]
        public static extern void _releaseCaption(IntPtr hWnd);
        #endregion

        public ISiseHelper()
        {

        }

        ~ISiseHelper()
        {

        }

        public void ExitOK() => _exitOK();

        public bool SetSiseHwnd(IntPtr hWnd) => _setSiseHwnd(hWnd);

        public IntPtr GetSiseHwnd() => _getSiseHwnd();

        public void RunSise(string lpszEXE, bool isReCreate) => _runSise(lpszEXE, isReCreate);

        public void ConnectSise(string lpszSvrIp) => _connectSise(lpszSvrIp);

        public void ExitSise() => _exitSise();

        public void Regist(IntPtr pArg) => _regist(pArg);

        public void Regist(string standardCode, string packetType, IntPtr hWnd)
        {
            REGIST_SISE_INFO info;
            info.StandardCode = standardCode.PadRight(12).ToCharArray();
            info.PacketType = packetType.ToCharArray();
            info.PacketTypeLength = packetType.Length;
            info.hWnd = hWnd;
            info.nPriority = 1;

            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(info));
            Marshal.StructureToPtr(info, ptr, false);

            _regist(ptr);
        }

        public void Release(IntPtr pArg) => _release(pArg);

        public void Release(string standardCode, string packetType, IntPtr hWnd)
        {
            REGIST_SISE_INFO info;
            info.StandardCode = standardCode.PadRight(12).ToCharArray();
            info.PacketType = packetType.ToCharArray();
            info.PacketTypeLength = packetType.Length;
            info.hWnd = hWnd;
            info.nPriority = 53;

            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(info));
            Marshal.StructureToPtr(info, ptr, false);

            _release(ptr);
        }

        //public void ReleaseAll(IntPtr pArg) => _releaseAll(pArg);

        public void ReleaseAll(IntPtr hWnd)
        {
            REGIST_SISE_INFO info;
            info.StandardCode = "            ".ToCharArray();
            info.PacketType = "     ".ToCharArray();
            info.PacketTypeLength = info.PacketType.Length;
            info.hWnd = hWnd;
            info.nPriority = 53;

            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(info));
            Marshal.StructureToPtr(info, ptr, false);

            _releaseAll(ptr);
        }

        public void RegistCaption(IntPtr hWnd, string lpszCaption) => _registCaption(hWnd, lpszCaption);

        public void ReleaseCaption(IntPtr hWnd) => _releaseCaption(hWnd);


    }
}
