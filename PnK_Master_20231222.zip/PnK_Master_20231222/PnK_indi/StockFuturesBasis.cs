﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using AxGIExpertControl64Lib;
using TicTacTec.TA.Library;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace PnK_indi
{
    public partial class StockFuturesBasis : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer ManageTimer = new Timer();

        private Dictionary<string, SubState> SubStates = new Dictionary<string, SubState>();
        private Dictionary<string, SpreadSubState> SpreadSubStates = new Dictionary<string, SpreadSubState>();
        private Dictionary<string, FuturesSubState> FuturesSubStates = new Dictionary<string, FuturesSubState>();

        private StrategyParams _StrategyParams = new StrategyParams();

        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 Indi_StockFuturesChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private List<string> StockFuturesUniverseCode = new List<string>();


        private DateTime MarketOpeningTime;
        private DateTime MarketClosingTime;


        /// <summary>
        ///  tuple 변수로 상태 bool과 시간을 저장
        /// </summary>
        private (bool Status, DateTime Time) Calculate_Rsi_signal_tuple;
        private (bool Status, DateTime Time) OpeningPriceOrdered;
        private (bool Status, DateTime Time) MarketOpened;
        private (bool Status, DateTime Time) RsiCalculated;
        private (bool Status, DateTime Time) PreClosingOrdered;
        private (bool Status, DateTime Time) ClosingPriceOrdered;
        private (bool Status, DateTime Time) EntryOrdered;
        private (bool Status, DateTime Time) OnClose;

        private bool IsMessageReceived_StockChart = false;
        private bool IsMessageReceived_StockFuturesChart = false;

        private bool filterSpreadUniBefore_Flag = false;

        private bool SetsfUniverseSetBefore_Flag = false;

        private new bool Enabled;

        public Thread SetPriceSetBef { get; private set; }
        public Thread SetsfUniverseSetBef { get; private set; }
        public Thread Calculate_Rsi_Thread { get; private set; }

        public long sfutures_multiple = 10;

        private bool working_flag = true;

        public bool Position_limit_flag = false;


        // 형식에 맞게 파일 이름을 생성합니다.
        string filePath = "C:/Users/234046/Desktop/Logs/StockFuturesBasis/" + DateTime.Now.ToString("yyyy-MM-dd") + "_output.log";

        public StockFuturesBasis(MainWindow main)
        {
            this.Main = main;
            InitializeComponent();

            UpdateTimes();
            InitializeIndiControls();

            SetsfUniverseSetBef = new Thread(() => SetsfUniverseSetBefore());
            SetsfUniverseSetBef.Start();
        }


        private void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                MarketOpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                MarketClosingTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
            }

            Calculate_Rsi_signal_tuple = (false, MarketOpeningTime.AddMinutes(5));

            //OpeningPriceOrdered = (false, MarketOpeningTime.AddSeconds(-60));
            MarketOpened = (false, MarketOpeningTime);

            //RsiCalculated = (false, MarketClosingTime.AddMinutes(-15));
            //PreClosingOrdered = (false, MarketClosingTime.AddMinutes(-13));

            ClosingPriceOrdered = (false, MarketClosingTime.AddMinutes(-20));
            EntryOrdered = (false, MarketClosingTime.AddMinutes(-60));

            OnClose = (false, MarketClosingTime.AddMinutes(10));
        }

        /// <summary>
        /// 선언한 인디객체에 이벤트 함수를 연결 
        /// </summary>
        private void InitializeIndiControls()
        {

            Indi_StockChartControl.CreateControl();
            Indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockChartControl_ReceiveData);

            Indi_StockFuturesChartControl.CreateControl();
            Indi_StockFuturesChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_StockFuturesChartControl_ReceiveData);
        }

        private void Indi_StockChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockChart = true;
        }
        private void Indi_StockFuturesChartControl_ReceiveData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            IsMessageReceived_StockFuturesChart = true;
        }

        public bool IsEnabled() => this.Enabled;

        public void OnConfirm(StockState state)
        {

        }

        public void OnConfirm(DerivState state)
        {

        }

        public void OnExecution(StockState state)
        {

        }

        public void OnExecution(DerivState state)
        {


        }
        public void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (dataType == RealTimeDataType.Execution & this.filterSpreadUniBefore_Flag)
            {   //SubStates 의 State에 StockState state가 어떻게 업데이트되는지 이해가 잘안감
                if (SubStates.TryGetValue(state.ShortCode, out SubState subState))
                {

                    long futures_nowbalance=0;
                    long stock_nowbalance=0;

                    string Name = subState.State.Name;
                    string ShortCode = subState.State.ShortCode;

                    var stockFuturesState = FuturesSubStates.Values.Where(x => x.DerivState.UnderlyingAssetShortCode == state.ShortCode).FirstOrDefault();
                 
                    futures_nowbalance = Math.Abs(stockFuturesState.DerivState.NormalBalance);
                    stock_nowbalance = Math.Abs(subState.State.NormalBalance);
                    

                    if (stockFuturesState.DerivState.Quote == null | subState.State.Quote == null )
                    {

                    }else if (stockFuturesState.DerivState.Quote[0].BidPrice == null | subState.State.Quote[0].AskPrice == null)
                    {

                    }
                    else if ((futures_nowbalance * sfutures_multiple) != (stock_nowbalance))
                    {
                        Console.WriteLine($"{Name}. 아직 주식과 주식선물의 델타가 맞지않습니다, futures_nowbalance:{futures_nowbalance},stock_nowbalance:{stock_nowbalance} : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                    }
                    else if (Main.Prohibited.Contains(ShortCode))
                    {

                    }
                    else if (C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice) == 0 | C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice) == 0 | C.AsLong(subState.State.Quote[0].AskPrice) == 0 | C.AsLong(subState.State.Quote[0].BidPrice) == 0)
                    {

                    }
                    else if (C.AsLong(stockFuturesState.DerivState.Quote[1].BidPrice) == 0 | C.AsLong(stockFuturesState.DerivState.Quote[1].AskPrice) == 0 | C.AsLong(subState.State.Quote[1].AskPrice) == 0 | C.AsLong(subState.State.Quote[1].BidPrice) == 0)
                    {

                    }
                    else if (TradeOffButton.Checked | ClosingPriceOrdered.Time < DateTime.Now)
                    {

                    }
                    else
                    {
                        long entry_sfutures_bid = C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice);
                        long entry_stocks_ask = C.AsLong(subState.State.Quote[0].AskPrice);
                        long entry_stocks_bid = C.AsLong(subState.State.Quote[0].BidPrice);
                        double stock_bidask_spread = 100 * 100 * (entry_stocks_ask - entry_stocks_bid) / entry_stocks_bid;

                        long entry_sfutures_bidamount = sfutures_multiple * C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice) * C.AsLong(stockFuturesState.DerivState.Quote[0].BidQuantity);
                        long entry_stocks_askamount = C.AsLong(subState.State.Quote[0].AskPrice) * C.AsLong(subState.State.Quote[0].AskQuantity);
                        double entry_amount = Math.Min(entry_sfutures_bidamount, entry_stocks_askamount);


                        long entry_sfutures_bid_next1 = (long)stockFuturesState.DerivState.PriceHelper.GetNextPriceBelowTicks((double)entry_stocks_bid,1);
                        long entry_stocks_ask_next1 = subState.State.PriceHelper.GetNextPriceAboveTicks(entry_stocks_ask,1);
                        double entry_basis_bp_bidask_next1 = 100 * 100 * (entry_sfutures_bid_next1 - entry_stocks_ask_next1) / entry_stocks_ask_next1;


                        double entry_basis_bp = 100 * 100 * (entry_sfutures_bid - entry_stocks_ask) / entry_stocks_ask;

                        long entry_quantity = 20;

                        entry_quantity = Math.Min(entry_quantity, C.AsLong(stockFuturesState.DerivState.Quote[0].BidQuantity));
                        entry_quantity = Math.Min(entry_quantity, (long)(C.AsLong(subState.State.Quote[0].AskQuantity) / sfutures_multiple));


                        long entry_basis_cutoff = SubStates[ShortCode].Params.EntryBasis;


                        if ((entry_basis_bp >= entry_basis_cutoff) & (entry_quantity > 0) & (SpreadSubStates[ShortCode].entry_universe))
                        {

                            // 이미 선물 Entry 주문을 했으면 다시 재주문을 하지 않음
                            if (SpreadSubStates[ShortCode].EntryFuturesOrderSend)
                            {

                            }
                            else if (EntryOffButton.Checked)
                            {

                            }else if (futures_nowbalance > 500)
                            {

                            }else if (Position_limit_flag)
                            {

                            }
                            else
                            {
                                SpreadSubStates[ShortCode].EntryFuturesOrderSend = true;

                                SpreadSubStates[ShortCode].OrderRecentTime = DateTime.Now;
                                SpreadSubStates[ShortCode].RecentFuturesQuantity = futures_nowbalance;
                                SpreadSubStates[ShortCode].RecentStockQuantity = stock_nowbalance;

                                SpreadSubStates[ShortCode].EntryFuturesSignalPrice = entry_sfutures_bid;
                                SpreadSubStates[ShortCode].EntryStocksSignalPrice = entry_stocks_ask;

                                double Futures_before_change = 100 * 100 * (SpreadSubStates[ShortCode].EntryFuturesSignalPrice - SpreadSubStates[ShortCode].EntryFuturesPrePrice) / SpreadSubStates[ShortCode].EntryFuturesPrePrice;
                                double stock_before_change = 100 * 100 * (SpreadSubStates[ShortCode].EntryStocksSignalPrice - SpreadSubStates[ShortCode].EntryStocksPrePrice) / SpreadSubStates[ShortCode].EntryStocksPrePrice;

                                Console.WriteLine($"NewOrder : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                                Console.WriteLine($"Name:{Name}, entry_basis_bp:{Math.Round(entry_basis_bp)}BP ,entry_amount:{Math.Round(entry_amount / 10000, 2)}만원");
                                Console.WriteLine($"Name:{Name}, Fprice:{entry_sfutures_bid},Sprice:{entry_stocks_ask}");
                                Console.WriteLine($"Name:{Name}, F_change:{Math.Round(Futures_before_change)}BP, S_change:{Math.Round(stock_before_change)}BP,stock_bidask_bp:{Math.Round(stock_bidask_spread)}BP, ");
                                Console.WriteLine("");

                                stockFuturesState.DerivState.NewOrder(AskBidType.Ask, entry_sfutures_bid_next1, entry_quantity, OrderType.Limit, OrderCondition.Normal);
                                subState.State.NewOrder(AskBidType.Bid, entry_stocks_ask_next1, entry_quantity * sfutures_multiple, OrderType.Limit, OrderCondition.Normal);

                                SpreadSubStates[ShortCode].FuturesEntryOrderQuantity = entry_quantity;
                                SpreadSubStates[ShortCode].StockEntryOrderQuantity = entry_quantity * sfutures_multiple;
                            }

                        }//entry_basis_bp 가 10 이하에선 exit만 관찰
                        else if (entry_basis_bp < 0)
                        {

                            if (futures_nowbalance != 0 & sfutures_multiple != 0)
                            {
                                if ((futures_nowbalance * sfutures_multiple) == (stock_nowbalance))
                                {

                                    double sfutres_avg_p = stockFuturesState.DerivState.AveragePrice;
                                    double stocks_avg_p = subState.State.AverageBuyPrice;

                                    long exit_sfutures_ask = C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice);
                                    long exit_sfutures_ask_next1 = (long)stockFuturesState.DerivState.PriceHelper.GetNextPriceAboveTicks((double)exit_sfutures_ask,1);


                                    long exit_stocks_bid = C.AsLong(subState.State.Quote[0].BidPrice);
                                    long exit_stocks_bid_next1 = subState.State.PriceHelper.GetNextPriceBelowTicks(exit_stocks_bid,1);

                                    long exit_sfutures_askamount = sfutures_multiple * C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice) * C.AsLong(stockFuturesState.DerivState.Quote[0].AskQuantity);
                                    long exit_stocks_bidamount = C.AsLong(subState.State.Quote[0].BidPrice) * C.AsLong(subState.State.Quote[0].BidQuantity);
                                    double exit_amount = Math.Min(exit_sfutures_askamount, exit_stocks_bidamount);

                                    double exit_basis_bp = 100 * 100 * (exit_sfutures_ask_next1 - exit_stocks_bid_next1) / exit_stocks_bid_next1;

                                    double expect_return_f = (sfutres_avg_p - exit_sfutures_ask_next1) / sfutres_avg_p - 0.01 * 0.01;
                                    //double expect_return_s = (exit_stocks_bid_next1 - stocks_avg_p) / stocks_avg_p - 0.01 * 0.2;
                                    double expect_return_s = (exit_stocks_bid - stocks_avg_p) / stocks_avg_p - 0.01 * 0.2;

                                    double total_return = 100 * 100 * (expect_return_f + expect_return_s);

                                    long exit_quantity_futures = (long)((exit_amount / exit_sfutures_ask) / sfutures_multiple);

                                    exit_quantity_futures = 100;

                                    exit_quantity_futures = Math.Min(exit_quantity_futures, futures_nowbalance);

                                    exit_quantity_futures = Math.Min(exit_quantity_futures, C.AsLong(stockFuturesState.DerivState.Quote[0].AskQuantity));
                                    exit_quantity_futures = Math.Min(exit_quantity_futures, (long)(C.AsLong(subState.State.Quote[0].BidQuantity) / sfutures_multiple));

                                    long exit_quantity_stock = exit_quantity_futures * sfutures_multiple;
                                    long tp_cutoff = SubStates[ShortCode].Params.TargetReturn;

                                    if (total_return >= tp_cutoff-10)
                                    {
                                        Console.WriteLine($"StockUpdateQuotes, exit_basis_bp : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                                        Console.WriteLine($"Name:{Name},total_return:{Math.Round(total_return)}Bp, exit_basis_bp:{Math.Round(exit_basis_bp)}BP ,exit_amount:{Math.Round(exit_amount / 10000, 2)}만원");
                                        Console.WriteLine("");

                                    }



                                    if ((total_return > tp_cutoff) & (exit_quantity_futures > 0) )
                                    {
                                        Console.WriteLine($"Name:{Name}, Profit Take Order:{Math.Round(total_return)}BP ,exit_amount:{Math.Round(exit_amount / 10000, 2)}만원");
                                        Console.WriteLine("");

                                        if (SpreadSubStates[ShortCode].ExitFuturesOrderSend)
                                        {

                                        }
                                        else if (C.AsLong(subState.State.Quote[0].BidQuantity) <= sfutures_multiple)
                                        {
                                            //주식수량이 10개가안되는경우
                                        }
                                        else if ((DateTime.Now - SpreadSubStates[ShortCode].OrderRecentTime).Seconds < 2)
                                        { //최근 주문후 최소 2초후 재주문 ,연속 재주문 방지로직

                                        }
                                        else
                                        {
                                            SpreadSubStates[ShortCode].ExitFuturesOrderSend = true;

                                            SpreadSubStates[ShortCode].OrderRecentTime = DateTime.Now;
                                            SpreadSubStates[ShortCode].RecentFuturesQuantity = futures_nowbalance;
                                            SpreadSubStates[ShortCode].RecentStockQuantity = stock_nowbalance;

                                            Console.WriteLine($"NewOrder : {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                                            Console.WriteLine($"Name:{Name}, entry_basis_bp:{Math.Round(entry_basis_bp)}BP ,exit_basis_bp:{Math.Round(exit_basis_bp)}BP");
                                            Console.WriteLine($"Name:{Name}, Fprice:{exit_sfutures_ask},Sprice:{exit_stocks_bid}");
                                            Console.WriteLine("");


                                            stockFuturesState.DerivState.NewOrder(AskBidType.Bid, exit_sfutures_ask_next1, exit_quantity_futures, OrderType.Limit, OrderCondition.Normal);
                                            subState.State.NewOrder(AskBidType.Ask, exit_stocks_bid, exit_quantity_futures * sfutures_multiple, OrderType.Limit, OrderCondition.Normal);


                                            SpreadSubStates[ShortCode].FuturesExitOrderQuantity = exit_quantity_futures;
                                            SpreadSubStates[ShortCode].StockExitOrderQuantity = exit_quantity_futures * sfutures_multiple;

                                        }
                                    }
                                }
                            }
                        }


                        SpreadSubStates[ShortCode].EntryFuturesPrePrice = entry_sfutures_bid;
                        SpreadSubStates[ShortCode].EntryStocksPrePrice = entry_stocks_ask;



                    }

                }
            }
        }

        public void UpdateQuotes(RealTimeDataType dataType, DerivState futuresState)
        {
            if (dataType == RealTimeDataType.Execution & this.filterSpreadUniBefore_Flag)
            {

            }

        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("RunButton_Click");
            if (!InitStrategyParams()) { return; }
            ParamsGroupBox.Enabled = false;


            InitSubStates();
            InitFuturesStates();
            Enable();

            SetPriceSetBef = new Thread(() => filterSpreadUniBefore());
            SetPriceSetBef.Start();

            //Console.WriteLine("spread set start done");
            //Enable();
            //Console.WriteLine("ManageTimer before");
            ManageTimer.Set(3 * 1000);
            ManageTimer.Start(OnTimer);
        }

        private void SetsfUniverseSetBefore()
        {
            Indi_StockChartControl.SetQueryName("sfut_mst");
            Indi_StockChartControl.RequestData();

            while (true)
            {
                if (this.IsMessageReceived_StockChart)
                    break;
            }

            this.IsMessageReceived_StockChart = false;

            var nCount = Indi_StockChartControl.GetMultiRowCount();
            for (short i = 0; i < nCount; i++)
            {

                var shortcode = (string)Indi_StockChartControl.GetMultiData(i, 8);
                StockFuturesUniverseCode.Add(shortcode);

            }
            StockFuturesUniverseCode = StockFuturesUniverseCode.Distinct().ToList();
            if (StockFuturesUniverseCode.Count != 0)
            {
                //Console.WriteLine($"주식선물 종목개수: {StockFuturesUniverseCode.Count}");
                this.SetsfUniverseSetBefore_Flag = true;
            }
        }
        private void InitSubStates()
        {
            while (true)
            {
                if (this.SetsfUniverseSetBefore_Flag)
                    break;
            }
            Console.WriteLine("InitSubStates");
            this.SetsfUniverseSetBefore_Flag = false;

            foreach (var state in Main.States.Values)
            {


                // 주식 외 제외
                if (state.SecurityGroupId != SecurityGroupId.ST) { continue; }
                // 우선주 제외
                if (!state.ShortCode.EndsWith("0")) { continue; }
                // 락 종목 제외
                if (state.PriceAdjustment != PriceAdjustment.Normal
                    && state.PriceAdjustment != PriceAdjustment.ExDividend
                    && state.PriceAdjustment != PriceAdjustment.ExMidDividend) { continue; }
                // 스팩 제외
                if (state.Name.Contains("스팩")) { continue; }
                // 계열사 종목 제외
                if (state.Name.Contains("신한") || state.Name.Contains("제주은행")) { continue; }

                //주식선물이 있는 종목만 만들기
                if (!StockFuturesUniverseCode.Contains(state.ShortCode)) { continue; }

                SubStates[state.ShortCode] = new SubState(state, _StrategyParams);

            }

            //시세요청
            foreach (var subState in SubStates.Values)
            {
                var state = subState.State;

                if (state.MarketType == MarketType.Kospi)
                {
                    if (state.SecurityGroupId == SecurityGroupId.EF || state.SecurityGroupId == SecurityGroupId.EN)
                    {
                        Main.RequestA303S(state.StandardCode);
                        Main.RequestB703S(state.StandardCode);
                    }
                    else
                    {
                        Main.RequestA301S(state.StandardCode);
                        Main.RequestB601S(state.StandardCode);
                    }
                }
                else if (state.MarketType == MarketType.Kosdaq)
                {
                    Main.RequestA301Q(state.StandardCode);
                    Main.RequestB601Q(state.StandardCode);
                }
            }
        }

        private void InitFuturesStates()
        {
            Console.WriteLine("InitFuturesStates");
            foreach (var subState in SubStates.Values)
            {
                //var stockFuturesState = Main.DerivStates.Values.Where(x => x.UnderlyingAssetShortCode == shortCode &&
                //           x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();


                string shortCode = subState.State.ShortCode;

                var stockFuturesState = Main.DerivStates.Values.Where(x => x.UnderlyingAssetShortCode == shortCode &&
                    string.Compare(x.ExpiryDate, DateTime.Now.ToString("yyyyMMdd")) == 1).OrderBy(x => x.ExpiryDate).FirstOrDefault();

                if (stockFuturesState == null) { continue; }

                Main.RequestB604F(stockFuturesState.StandardCode);
                Main.RequestG704F(stockFuturesState.StandardCode);

                var futuresShortCode = stockFuturesState.ShortCode;

                FuturesSubStates[futuresShortCode] = new FuturesSubState(stockFuturesState, stockFuturesState.StandardCode, stockFuturesState.ShortCode, stockFuturesState.Name);

                SpreadSubStates[shortCode] = new SpreadSubState(_StrategyParams);
                SpreadSubStates[shortCode].futures_shortcode = futuresShortCode;
                SpreadSubStates[shortCode].stock_shortcode = shortCode;

            }
        }

        public void filterSpreadUniBefore()
        {
            Console.WriteLine("filterSpreadUniBefore");
            int cnt = 0;
            foreach (var subState in SubStates.Values.ToList())
            {
                cnt++;
                var shortCode = subState.State.ShortCode;
                var Name = subState.State.Name;
                var spreadState = SpreadSubStates[shortCode];
                string yesterday = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
                string shortcode_input = spreadState.futures_shortcode.Substring(0, 5);

                var FuturesStateKey = FuturesSubStates.Values.Where(x => x.DerivState.UnderlyingAssetShortCode == shortCode).FirstOrDefault();
                string futures_shortcode = FuturesSubStates.Where(kvp => kvp.Value.DerivState.UnderlyingAssetShortCode == shortCode).Select(kvp => kvp.Key).ToList().FirstOrDefault().ToString();



                //if (Name != "유한양행" & Name != "한국항공우주" & Name != "LIG넥스원" & Name != "영원무역"
                //    & Name != "한국금융지주" & Name != "롯데에너지머티리얼즈" & Name != "포스코인터내셔널" & Name != "엔씨소프트"
                //    & Name != "신세계" & Name != "코스맥스" & Name != "SKC"
                //    )
                //{
                //    SpreadSubStates.Remove(shortCode);
                //    SubStates.Remove(shortCode);
                //    FuturesSubStates.Remove(futures_shortcode);
                //    continue;
                //}
                //else
                //{
                //    Console.WriteLine($"{cnt},Name:{SubStates[shortCode].State.Name}");
                //    continue;
                //}


                Indi_StockFuturesChartControl.SetQueryName("TR_EFCHART");
                Indi_StockFuturesChartControl.SetSingleData(0, shortcode_input);
                Indi_StockFuturesChartControl.SetSingleData(1, "1");
                Indi_StockFuturesChartControl.SetSingleData(2, "1");
                Indi_StockFuturesChartControl.SetSingleData(3, "00000000");
                Indi_StockFuturesChartControl.SetSingleData(4, "99999999");
                Indi_StockFuturesChartControl.SetSingleData(5, "1500");
                Indi_StockFuturesChartControl.RequestData();

                while (true)
                {
                    if (this.IsMessageReceived_StockFuturesChart)
                        break;
                }

                this.IsMessageReceived_StockFuturesChart = false;

                var nCount = Indi_StockFuturesChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }

                //if (subState.PriceSet.Count() > 0) { subState.PriceSet.Clear(); }

                spreadState.recent_vamount = 0;
                spreadState.up_basis_count = 0;
                spreadState.down_basis_count = 0;

                for (short i = 0; i < nCount; i++)
                {

                    var fclose = C.AsDouble(Indi_StockFuturesChartControl.GetMultiData(i, 5));
                    var sclose = C.AsDouble(Indi_StockFuturesChartControl.GetMultiData(i, 8));
                    var va = C.AsDouble(Indi_StockFuturesChartControl.GetMultiData(i, 10));

                    var basis = 0;
                    if (sclose == 0)
                    {
                        basis = 0;
                    }
                    else
                    {
                        basis = (int)Math.Round(100 * 100 * (fclose - sclose) / sclose);
                    }


                    spreadState.BasisList.Add(basis);
                    spreadState.recent_vamount = spreadState.recent_vamount + va;

                    if (basis > 10)
                    {
                        spreadState.up_basis_count = spreadState.up_basis_count + 1;
                    }
                    else if (basis < -100)
                    {
                        spreadState.down_basis_count = spreadState.down_basis_count + 1;
                    }
                }
                spreadState.recent_vamount = 100 * spreadState.recent_vamount;

                //var FuturesStateKey = FuturesSubStates.Values.Where(x => x.DerivState.UnderlyingAssetShortCode == shortCode).FirstOrDefault();
                //string futures_shortcode =  FuturesSubStates.Where(kvp => kvp.Value.DerivState.UnderlyingAssetShortCode == shortCode).Select(kvp => kvp.Key).ToList().FirstOrDefault().ToString();

                //if ((spreadState.up_basis_count>=1 & spreadState.down_basis_count >= 10) | (spreadState.up_basis_count >= 10 & spreadState.down_basis_count >= 1))

                //포지션 존재하는 종목은 제거하지 않음
                if (subState.State.NormalBalance != 0)
                {

                    Console.WriteLine("");
                    Console.WriteLine($"Name:{Name}, 주식:{subState.State.NormalBalance}개 ,선물:{FuturesSubStates[futures_shortcode].DerivState.NormalBalance} 계약");

                    double basis = 100 * 100 * (FuturesSubStates[futures_shortcode].DerivState.AveragePrice - subState.State.AverageBuyPrice) / subState.State.AverageBuyPrice;
                    Console.WriteLine($"Basis:{Math.Round(basis)}BP , 선물평단:{FuturesSubStates[futures_shortcode].DerivState.AveragePrice} , 주식평단:{subState.State.AverageBuyPrice}");
                    Console.WriteLine("");
                    if (subState.State.NormalBalance != sfutures_multiple * Math.Abs(FuturesSubStates[futures_shortcode].DerivState.NormalBalance))
                    {
                        Console.WriteLine("");
                        Console.WriteLine($"*************{Name}주식,주식선물 델타가 맞지않음*****************");
                        Console.WriteLine("");
                    }

                }

                if ((spreadState.up_basis_count >= 1) & (spreadState.down_basis_count >= 10) & (spreadState.recent_vamount / 10000 / 10000 > 10))
                {
                   
                    Console.WriteLine($"True,{cnt},Name:{SubStates[shortCode].State.Name},up_basis_count: {spreadState.up_basis_count},down_basis_count:{spreadState.down_basis_count},Max_basis:{spreadState.BasisList.Max()},Min_basis:{spreadState.BasisList.Min()},거래대금:{Math.Round(spreadState.recent_vamount / 10000 / 10000),1}억");
                    Console.WriteLine($"avg_basis: { spreadState.BasisList.Average()},직전하루평균:{spreadState.BasisList.Skip(spreadState.BasisList.Count-600).Average()}");
                    Console.WriteLine("");

                    spreadState.entry_universe = true;
                }
                else
                {
                    Console.WriteLine($"False,{cnt},Name:{SubStates[shortCode].State.Name},up_basis_count: {spreadState.up_basis_count},down_basis_count:{spreadState.down_basis_count},Max_basis:{spreadState.BasisList.Max()},Min_basis:{spreadState.BasisList.Min()},거래대금:{Math.Round(spreadState.recent_vamount / 10000 / 10000),1}억");
                    if (subState.State.NormalBalance == 0)
                    {

                        
                        SpreadSubStates.Remove(shortCode);
                        SubStates.Remove(shortCode);
                        FuturesSubStates.Remove(futures_shortcode);
                    }
                }


            }

            Console.WriteLine("");

            foreach (var spreadState in SpreadSubStates.Values.OrderBy(x => x.down_basis_count).ToList()) 
            {   if(spreadState.entry_universe)
                {
                    Console.WriteLine($"Name:{SubStates[spreadState.stock_shortcode].State.Name},up_basis_count: {spreadState.up_basis_count},down_basis_count:{spreadState.down_basis_count},Max_basis:{spreadState.BasisList.Max()},Min_basis:{spreadState.BasisList.Min()},거래대금:{Math.Round(spreadState.recent_vamount / 10000 / 10000),1}억");
                }
               
            }


            this.filterSpreadUniBefore_Flag = true;


            Console.WriteLine("filterSpreadUpdateDone");
            Console.WriteLine("");
        }




        private void OnTimer(object sender, EventArgs e)
        {   //유니버스 set을 완성한이후
            if (this.filterSpreadUniBefore_Flag)
            {
                // 매수주문
                long position_size = 0;
                foreach (var spreadsubState in SpreadSubStates.Values.ToList())
                {

                    string ShortCode = spreadsubState.stock_shortcode;
                    string futures_shortcode = spreadsubState.futures_shortcode;

                    var stockFuturesState = FuturesSubStates[futures_shortcode];
                    var subState = SubStates[ShortCode];

                    long futures_nowbalance = Math.Abs(stockFuturesState.DerivState.NormalBalance);
                    long stock_nowbalance = Math.Abs(subState.State.NormalBalance);
                    string Name = subState.State.Name;

                    if ((DateTime.Now - SpreadSubStates[ShortCode].OrderRecentTime).Seconds < 3) { continue; }
                    else if (futures_nowbalance == 0 & stock_nowbalance == 0) { continue; }
                    else if (subState.State.BestQuote.Ask == 0 | subState.State.BestQuote.Bid == 0) { continue; }
                    else if ((C.AsLong( stockFuturesState.DerivState.Quote[0].BidPrice) == 0) | (C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice) == 0)) { continue; }
                    else if (TradeOffButton.Checked)
                    {
                        continue;
                    }

                    position_size = position_size + futures_nowbalance * sfutures_multiple * C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice);

                    bool IsSellable = subState.State.IsSellable();
                    if (!IsSellable)
                    {
                        Console.WriteLine($"IsSellable이 False 입니다.BalanceAvailableToSell:{subState.State.BalanceAvailableToSell},DelayTime:{(DateTime.Now - subState.State.DelayTime).TotalSeconds}");
                        Console.WriteLine("");
                        continue;
                    }

                    if (position_size > spreadsubState.Params.MaxNotionalAmount)
                    {
                        Position_limit_flag = true;
                    }
                    else
                    {
                        Position_limit_flag = false;
                    }

                    if (Main.Prohibited.Contains(ShortCode)) { continue; }

                    if (SpreadSubStates.ContainsKey(ShortCode))
                    {

                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == subState.State.StandardCode).ToList();

                        if (liveOrders.Count() > 0)
                        {
                            subState.State.CancelAllOrders();
                            Console.WriteLine($"subState CancelAllOrders 완료");
                            Console.WriteLine("");

                        }

                        var DeriveliveOrders = Main.DerivLiveOrders.Where(x => x.ShortCode == futures_shortcode).ToList();

                        if (DeriveliveOrders.Count() > 0)
                        {
                            stockFuturesState.DerivState.CancelAllOrders();
                            Console.WriteLine($"DerivState CancelAllOrders 완료");
                            Console.WriteLine("");

                        }

                        if (SpreadSubStates[ShortCode].EntryFuturesOrderSend)
                        {

                            long entry_sfutures_bid = C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice);
                            long entry_stocks_ask = C.AsLong(subState.State.Quote[0].AskPrice);

                            long entry_sfutures_bidamount = sfutures_multiple * C.AsLong(stockFuturesState.DerivState.Quote[0].BidPrice) * C.AsLong(stockFuturesState.DerivState.Quote[0].BidQuantity);
                            long entry_stocks_askamount = C.AsLong(subState.State.Quote[0].AskPrice) * C.AsLong(subState.State.Quote[0].AskQuantity);

                            double entry_amount = Math.Min(entry_sfutures_bidamount, entry_stocks_askamount);

                            double entry_basis_bp = 100 * 100 * (entry_sfutures_bid - entry_stocks_ask) / entry_stocks_ask;

                            double sfutures_signal_changes = 100 * 100 * (entry_sfutures_bid - SpreadSubStates[ShortCode].EntryFuturesSignalPrice) / SpreadSubStates[ShortCode].EntryFuturesSignalPrice;
                            double stocks_signal_changes = 100 * 100 * (entry_stocks_ask - SpreadSubStates[ShortCode].EntryStocksSignalPrice) / SpreadSubStates[ShortCode].EntryStocksSignalPrice;


                            Console.WriteLine($"DerivStateUpdateQuotes, {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")},Position_limit_flag:{Position_limit_flag}");
                            Console.WriteLine($"Name:{Name}, entry_basis_bp:{Math.Round(entry_basis_bp)}BP ,entry_amount:{Math.Round(entry_amount / 10000, 2)}만원");
                            Console.WriteLine($"sfutures_signal_changes:{Math.Round(sfutures_signal_changes)}BP ,stocks_signal_changes:{Math.Round(stocks_signal_changes)}BP ");
                            Console.WriteLine("");

                            //(주식선물 계약수가 주식보다 많거나 적은 경우 , 주식선물이 추가로 진입된 경우)
                            if (futures_nowbalance * sfutures_multiple != stock_nowbalance)
                            {

                                long expect_futures_quantity = SpreadSubStates[ShortCode].RecentFuturesQuantity + SpreadSubStates[ShortCode].FuturesEntryOrderQuantity;
                                long expect_stocks_quantity = expect_futures_quantity * sfutures_multiple;


                                if (expect_stocks_quantity > stock_nowbalance)
                                {
                                    long remain_stock_qunatity = expect_stocks_quantity - stock_nowbalance;
                                    remain_stock_qunatity = Math.Min(C.AsLong(subState.State.Quote[0].AskQuantity), remain_stock_qunatity);
                                    remain_stock_qunatity = Math.Max(remain_stock_qunatity, 1);

                                    Console.WriteLine($"remain_stock_qunatity!! {remain_stock_qunatity} Stocks,추가 주문완료");
                                    Console.WriteLine("");

                                    subState.State.NewOrder(AskBidType.Bid, entry_stocks_ask, remain_stock_qunatity, OrderType.Limit, OrderCondition.Normal);
                                }//선물이 부족한경우
                                if (expect_futures_quantity > futures_nowbalance)
                                {
                                    long remain_futures_qunatity = expect_futures_quantity - futures_nowbalance;
                                    remain_futures_qunatity = Math.Min(C.AsLong(stockFuturesState.DerivState.Quote[0].BidQuantity), remain_futures_qunatity);
                                    remain_futures_qunatity = Math.Max(remain_futures_qunatity, 1);

                                    Console.WriteLine($"remain_futures_qunatity!! {remain_futures_qunatity} futures,추가 주문완료");
                                    Console.WriteLine("");

                                    stockFuturesState.DerivState.NewOrder(AskBidType.Ask, entry_sfutures_bid, remain_futures_qunatity, OrderType.Limit, OrderCondition.Normal);
                                }


                            }
                            else if ((futures_nowbalance * sfutures_multiple == stock_nowbalance) & (futures_nowbalance > SpreadSubStates[ShortCode].RecentFuturesQuantity))
                            {// Futures가 체결된 이후 주식도 전부 체결된경우만 반영함, Futures가 체결되지않은경우 모두 반영함
                                SpreadSubStates[ShortCode].EntryFuturesOrderSend = false;
                                Console.WriteLine($"Complete!! {Name} Stocks,선물 Entry주문완료");
                                Console.WriteLine("");

                            }
                            else
                            {

                            }
                        }
                        else if (SpreadSubStates[ShortCode].ExitFuturesOrderSend)
                        {

                            long exit_sfutures_ask = C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice);
                            long exit_stocks_bid = C.AsLong(subState.State.Quote[0].BidPrice);

                            long exit_sfutures_askamount = sfutures_multiple * C.AsLong(stockFuturesState.DerivState.Quote[0].AskPrice) * C.AsLong(stockFuturesState.DerivState.Quote[0].AskQuantity);
                            long exit_stocks_bidamount = C.AsLong(subState.State.Quote[0].BidPrice) * C.AsLong(subState.State.Quote[0].BidQuantity);

                            double exit_amount = Math.Min(exit_sfutures_askamount, exit_stocks_bidamount);


                            //(주식선물 계약수가 주식보다 많거나 적은 경우 , 주식선물이 추가로 진입된 경우)
                            if (futures_nowbalance * sfutures_multiple != stock_nowbalance)
                            {

                                long expect_futures_quantity = SpreadSubStates[ShortCode].RecentFuturesQuantity - SpreadSubStates[ShortCode].FuturesExitOrderQuantity;
                                long expect_stocks_quantity = expect_futures_quantity * sfutures_multiple;


                                if (expect_stocks_quantity < stock_nowbalance)
                                {
                                    long remain_stock_qunatity = stock_nowbalance - expect_stocks_quantity;
                                    remain_stock_qunatity = Math.Min(C.AsLong(subState.State.Quote[0].BidQuantity), remain_stock_qunatity);
                                    remain_stock_qunatity = Math.Max(remain_stock_qunatity, 1);

                                    Console.WriteLine($"remain_stock_qunatity!! {remain_stock_qunatity} Stocks,추가 Exit 주문완료");
                                    Console.WriteLine("");

                                    subState.State.NewOrder(AskBidType.Ask, exit_stocks_bid, remain_stock_qunatity, OrderType.Limit, OrderCondition.Normal);
                                }//선물이 부족한경우
                                if (expect_futures_quantity < futures_nowbalance)
                                {
                                    long remain_futures_qunatity = futures_nowbalance - expect_futures_quantity;
                                    remain_futures_qunatity = Math.Min(C.AsLong(stockFuturesState.DerivState.Quote[0].AskQuantity), remain_futures_qunatity);
                                    remain_futures_qunatity = Math.Max(remain_futures_qunatity, 1);

                                    Console.WriteLine($"remain_futures_qunatity!! {remain_futures_qunatity} futures,추가 Exit 주문완료");
                                    Console.WriteLine("");

                                    stockFuturesState.DerivState.NewOrder(AskBidType.Bid, exit_sfutures_ask, remain_futures_qunatity, OrderType.Limit, OrderCondition.Normal);
                                }


                            }
                            else if ((futures_nowbalance * sfutures_multiple == stock_nowbalance) & (futures_nowbalance < SpreadSubStates[ShortCode].RecentFuturesQuantity))
                            {// Futures가 체결된 이후 주식도 전부 체결된경우만 반영함, Futures가 체결되지않은경우 모두 반영함
                                SpreadSubStates[ShortCode].ExitFuturesOrderSend = false;
                                Console.WriteLine($"Complete!! {Name} Stocks,선물 Exit 주문완료");
                                Console.WriteLine("");

                            }
                            else
                            {

                                Console.WriteLine("");
                            }
                        }
                        else if (futures_nowbalance * sfutures_multiple != stock_nowbalance)
                        {//EntryFuturesOrderSend,ExitFuturesOrderSend는 False인데델타가 맞지않은경우

                            long stocks_ask = C.AsLong(subState.State.Quote[0].AskPrice);
                            long stocks_bid = C.AsLong(subState.State.Quote[0].BidPrice);

                            if (futures_nowbalance * sfutures_multiple > stock_nowbalance)
                            {
                                Console.WriteLine($"경고!! futures_nowbalance 수가 stock_nowbalance보다 많습니다");
                                Console.WriteLine("");
                                long remain_stock_qunatity = futures_nowbalance * sfutures_multiple - stock_nowbalance;
                                remain_stock_qunatity = Math.Min(C.AsLong(subState.State.Quote[0].AskQuantity), remain_stock_qunatity);
                                remain_stock_qunatity = Math.Max(remain_stock_qunatity, 1);

                                subState.State.NewOrder(AskBidType.Bid, stocks_ask, remain_stock_qunatity, OrderType.Limit, OrderCondition.Normal);

                                Console.WriteLine($"remain_stock_qunatity!! {remain_stock_qunatity} Stocks,추가 매수 주문완료");
                                Console.WriteLine("");

                            }
                            else if (futures_nowbalance * sfutures_multiple < stock_nowbalance)
                            {
                                Console.WriteLine($"경고!! stock_nowbalance 수가 futures_nowbalance 가 많습니다");
                                Console.WriteLine("");
                                long remain_stock_qunatity = stock_nowbalance - futures_nowbalance * sfutures_multiple;
                                remain_stock_qunatity = Math.Min(C.AsLong(subState.State.Quote[0].BidQuantity), remain_stock_qunatity);
                                remain_stock_qunatity = Math.Max(remain_stock_qunatity, 1);


                                subState.State.NewOrder(AskBidType.Ask, stocks_bid, remain_stock_qunatity, OrderType.Limit, OrderCondition.Normal);

                                Console.WriteLine($"remain_stock_qunatity!! {remain_stock_qunatity} Stocks,추가 매도 주문완료");
                                Console.WriteLine("");
                            }

                        }

                    }
                }
            }
        }



        //private void Save_spreadsubstates()
        //{
        //    // Person 클래스 직렬화하여 C:\Users\234046\Desktop\release\StockFuturesPairRsi 경로에 저장 (관리자 권한 필요)
        //    string filePath = @"C:\Users\234046\Desktop\release\StockFuturesPairStd\SpreadSubStates.dat";
        //    using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //    {
        //        BinaryFormatter binaryFormatter = new BinaryFormatter();
        //        binaryFormatter.Serialize(fileStream, SpreadSubStates);
        //    }
        //    Console.WriteLine("딕셔너리 Spread Sub State Class Update Complete");
        //}

        private bool InitStrategyParams()
        {
            bool isCorrect = _StrategyParams.Update(
                C.AsLong(EntryBasisBox.Text),
                C.AsLong(TargetReturnBox.Text),
                C.AsLong(MaxNotionalAmountBox.Text) * 10000 * 10000,

                 C.AsLong(C.AsDouble(MaxQuantityBalanceBox.Text)),
                C.AsLong(MaxOrderQuantityBox.Text),
                C.AsLong(C.AsDouble(MaxOrderAmountBox.Text)) * 10000
                );

            if (!isCorrect)
            {
                Console.WriteLine($"Check Params");
                return false;
            }
            return true;
        }


        public void Enable() { this.Enabled = true; }

        private class SubState
        {
            public StockState State;
            public StrategyParams Params;
            public TypeConverter C = new TypeConverter();
            public long PreviousDayMarketCap;
            public int Rank;
            public int Pyramiding;

            public bool Enabled;

            public long NextPyramidingPrice;
            //public List<double> PriceSet = new List<double>();


            public DateTime LastBuyDate { get; internal set; } = new DateTime();

            public void Enable() { this.Enabled = true; }
            public bool IsAble() => this.Enabled;
            public void Disable() { this.Enabled = false; }


            public SubState(StockState state, StrategyParams strategyParams)
            {
                this.State = state;
                this.Params = strategyParams;
                this.PreviousDayMarketCap = State.PreviousDayPrice * State.OutstandingShares;

                var bookValue = State.NormalBalance * State.AverageBuyPrice;
            }


            public void UpdatePrice()
            {
                if (this.IsAble())
                {
                    //PriceSet[0] = State.CurrentPrice;
                    //UpdateRSI();
                }
            }

        }

        private class FuturesSubState
        {
            public string StandardCode { get; private set; }
            public string ShortCode { get; private set; }
            public string Name { get; private set; }
            public DerivState DerivState { get; private set; }

            public long NowQuantity = 0;
            public long remainQuantity;

            public FuturesSubState(DerivState deriveState, string standardCode, string shortCode, string name)
            {
                this.DerivState = deriveState;
                this.StandardCode = standardCode;
                this.ShortCode = shortCode;
                this.Name = name;
            }
        }

        [Serializable]
        class SpreadSubState
        {

            public StrategyParams Params;

            public double TotalBookValue = 0;

            public bool HasPendingRequest = false;

            public bool EntryFuturesOrderSend = false;
            public bool EntryStocksOrderSend = false;
            public bool EntryOrderComplete = false;

            public double EntryFuturesSignalPrice;
            public double EntryStocksSignalPrice;
            public double EntryFuturesPrePrice;
            public double EntryStocksPrePrice;



            public bool ExitFuturesOrderSend = false;
            public bool ExitStocksOrderSend = false;
            public bool ExitOrderComplete = false;

            public DateTime OrderRecentTime = DateTime.Now;
            public long RecentFuturesQuantity;
            public long RecentStockQuantity;

            public long FuturesEntryOrderQuantity;
            public long StockEntryOrderQuantity;

            public long FuturesExitOrderQuantity;
            public long StockExitOrderQuantity;


            public List<double> BasisList = new List<double>();
            public double recent_vamount;
            public long up_basis_count;
            public double down_basis_count;

            public string futures_shortcode;
            public string stock_shortcode;


            public bool Enabled = true;
            public bool entry_universe = false;


            public SpreadSubState(StrategyParams strategyParams)
            {
                this.Params = strategyParams;
            }

        }



        [Serializable]
        internal class StrategyParams
        {
            public long EntryBasis { get; private set; }
            public long TargetReturn { get; private set; }

            public long MaxNotionalAmount { get; private set; }
            public long MaxQuantityBalance { get; private set; }
            public long MaxOrderQuantity { get; private set; }
            public long MaxOrderAmount { get; private set; }
            public void StartegyParams()
            {
            }
            private static bool DoubleGreaterThan(double d1, double d2) => (d1 - d2) > Math.Pow(10, -8);
            private static bool DoubleLessThan(double d1, double d2) => (d2 - d1) > Math.Pow(10, -8);

            public bool Update(long entrybasis,
                               long targetreturn,
                               long maxNotionalAmount,
                               long maxQuantityBalance,
                               long maxOrderQuantity,
                               long maxOrderAmount)
            {
                //if (!DoubleGreaterThan(targetRate, 0.0))
                //    return false;

                //if (!DoubleLessThan(losscutRate, 0.0))
                //    return false;

                //if (DoubleGreaterThan(losscutRate, targetRate))
                //    return false;

                //if (maxAmountPerOrder <= 0)
                //    return false;

                this.EntryBasis = entrybasis;
                this.TargetReturn = targetreturn;

                this.MaxNotionalAmount = maxNotionalAmount;
                this.MaxQuantityBalance = maxQuantityBalance;
                this.MaxOrderQuantity = maxOrderQuantity;
                this.MaxOrderAmount = maxOrderAmount;


                return true;
            }
        }


        private void PauseButton_Click(object sender, EventArgs e)
        {
            working_flag = false;
        }

        private void ResumeButton_Click(object sender, EventArgs e)
        {
            working_flag = true;
        }


    }
}