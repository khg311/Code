﻿namespace PnK_indi
{
    partial class IndexFutureVoltyV1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KospiParamsGroup = new System.Windows.Forms.GroupBox();
            this.KospiTradeOffBtn = new System.Windows.Forms.RadioButton();
            this.KospiTradeOnBtn = new System.Windows.Forms.RadioButton();
            this.KospiTradeLabel = new System.Windows.Forms.Label();
            this.KospiMaxAmountPerOrder = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.KospiTradingAmountTextBox = new System.Windows.Forms.TextBox();
            this.TradingContractsLabel = new System.Windows.Forms.Label();
            this.KospiLossCutRateTextBox = new System.Windows.Forms.TextBox();
            this.TargetRateLabel = new System.Windows.Forms.Label();
            this.KospiMultiplierTextBox = new System.Windows.Forms.TextBox();
            this.MultiplierLabel = new System.Windows.Forms.Label();
            this.KospiLengthTextBox = new System.Windows.Forms.TextBox();
            this.LengthLabel = new System.Windows.Forms.Label();
            this.PauseBtn = new System.Windows.Forms.Button();
            this.RunBtn = new System.Windows.Forms.Button();
            this.KosdaqParamsGroup = new System.Windows.Forms.GroupBox();
            this.KosdaqTradeOffBtn = new System.Windows.Forms.RadioButton();
            this.KosdaqTradeOnBtn = new System.Windows.Forms.RadioButton();
            this.KosdaqTradeLabel = new System.Windows.Forms.Label();
            this.KosdaqMaxAmountPerOrder = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.KosdaqTradingAmountTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.KosdaqLossCutRateTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.KosdaqMultiplierTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.KosdaqLengthTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.KospiParamsGroup.SuspendLayout();
            this.KosdaqParamsGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // KospiParamsGroup
            // 
            this.KospiParamsGroup.Controls.Add(this.KospiTradeOffBtn);
            this.KospiParamsGroup.Controls.Add(this.KospiTradeOnBtn);
            this.KospiParamsGroup.Controls.Add(this.KospiTradeLabel);
            this.KospiParamsGroup.Controls.Add(this.KospiMaxAmountPerOrder);
            this.KospiParamsGroup.Controls.Add(this.label1);
            this.KospiParamsGroup.Controls.Add(this.KospiTradingAmountTextBox);
            this.KospiParamsGroup.Controls.Add(this.TradingContractsLabel);
            this.KospiParamsGroup.Controls.Add(this.KospiLossCutRateTextBox);
            this.KospiParamsGroup.Controls.Add(this.TargetRateLabel);
            this.KospiParamsGroup.Controls.Add(this.KospiMultiplierTextBox);
            this.KospiParamsGroup.Controls.Add(this.MultiplierLabel);
            this.KospiParamsGroup.Controls.Add(this.KospiLengthTextBox);
            this.KospiParamsGroup.Controls.Add(this.LengthLabel);
            this.KospiParamsGroup.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KospiParamsGroup.Location = new System.Drawing.Point(12, 12);
            this.KospiParamsGroup.Name = "KospiParamsGroup";
            this.KospiParamsGroup.Size = new System.Drawing.Size(326, 229);
            this.KospiParamsGroup.TabIndex = 107;
            this.KospiParamsGroup.TabStop = false;
            this.KospiParamsGroup.Text = "KOSPI200 Params";
            // 
            // KospiTradeOffBtn
            // 
            this.KospiTradeOffBtn.AutoSize = true;
            this.KospiTradeOffBtn.Location = new System.Drawing.Point(233, 30);
            this.KospiTradeOffBtn.Name = "KospiTradeOffBtn";
            this.KospiTradeOffBtn.Size = new System.Drawing.Size(51, 23);
            this.KospiTradeOffBtn.TabIndex = 108;
            this.KospiTradeOffBtn.Text = "Off";
            this.KospiTradeOffBtn.UseVisualStyleBackColor = true;
            // 
            // KospiTradeOnBtn
            // 
            this.KospiTradeOnBtn.AutoSize = true;
            this.KospiTradeOnBtn.Checked = true;
            this.KospiTradeOnBtn.Location = new System.Drawing.Point(165, 30);
            this.KospiTradeOnBtn.Name = "KospiTradeOnBtn";
            this.KospiTradeOnBtn.Size = new System.Drawing.Size(49, 23);
            this.KospiTradeOnBtn.TabIndex = 107;
            this.KospiTradeOnBtn.TabStop = true;
            this.KospiTradeOnBtn.Text = "On";
            this.KospiTradeOnBtn.UseVisualStyleBackColor = true;
            // 
            // KospiTradeLabel
            // 
            this.KospiTradeLabel.AutoSize = true;
            this.KospiTradeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KospiTradeLabel.Location = new System.Drawing.Point(27, 34);
            this.KospiTradeLabel.Name = "KospiTradeLabel";
            this.KospiTradeLabel.Size = new System.Drawing.Size(39, 14);
            this.KospiTradeLabel.TabIndex = 106;
            this.KospiTradeLabel.Text = "Trade";
            // 
            // KospiMaxAmountPerOrder
            // 
            this.KospiMaxAmountPerOrder.Location = new System.Drawing.Point(195, 188);
            this.KospiMaxAmountPerOrder.Name = "KospiMaxAmountPerOrder";
            this.KospiMaxAmountPerOrder.Size = new System.Drawing.Size(100, 27);
            this.KospiMaxAmountPerOrder.TabIndex = 105;
            this.KospiMaxAmountPerOrder.Text = "25";
            this.KospiMaxAmountPerOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 14);
            this.label1.TabIndex = 104;
            this.label1.Text = "Max Amount Per Order";
            // 
            // KospiTradingAmountTextBox
            // 
            this.KospiTradingAmountTextBox.Location = new System.Drawing.Point(195, 155);
            this.KospiTradingAmountTextBox.Name = "KospiTradingAmountTextBox";
            this.KospiTradingAmountTextBox.Size = new System.Drawing.Size(100, 27);
            this.KospiTradingAmountTextBox.TabIndex = 105;
            this.KospiTradingAmountTextBox.Text = "20";
            this.KospiTradingAmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TradingContractsLabel
            // 
            this.TradingContractsLabel.AutoSize = true;
            this.TradingContractsLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TradingContractsLabel.Location = new System.Drawing.Point(27, 161);
            this.TradingContractsLabel.Name = "TradingContractsLabel";
            this.TradingContractsLabel.Size = new System.Drawing.Size(96, 14);
            this.TradingContractsLabel.TabIndex = 104;
            this.TradingContractsLabel.Text = "Trading Amount";
            // 
            // KospiLossCutRateTextBox
            // 
            this.KospiLossCutRateTextBox.Location = new System.Drawing.Point(195, 123);
            this.KospiLossCutRateTextBox.Name = "KospiLossCutRateTextBox";
            this.KospiLossCutRateTextBox.Size = new System.Drawing.Size(100, 27);
            this.KospiLossCutRateTextBox.TabIndex = 105;
            this.KospiLossCutRateTextBox.Text = "1";
            this.KospiLossCutRateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TargetRateLabel
            // 
            this.TargetRateLabel.AutoSize = true;
            this.TargetRateLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TargetRateLabel.Location = new System.Drawing.Point(27, 130);
            this.TargetRateLabel.Name = "TargetRateLabel";
            this.TargetRateLabel.Size = new System.Drawing.Size(75, 14);
            this.TargetRateLabel.TabIndex = 104;
            this.TargetRateLabel.Text = "LossCut (%)";
            // 
            // KospiMultiplierTextBox
            // 
            this.KospiMultiplierTextBox.Location = new System.Drawing.Point(195, 91);
            this.KospiMultiplierTextBox.Name = "KospiMultiplierTextBox";
            this.KospiMultiplierTextBox.Size = new System.Drawing.Size(100, 27);
            this.KospiMultiplierTextBox.TabIndex = 103;
            this.KospiMultiplierTextBox.Text = "0.8";
            this.KospiMultiplierTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MultiplierLabel
            // 
            this.MultiplierLabel.AutoSize = true;
            this.MultiplierLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultiplierLabel.Location = new System.Drawing.Point(27, 98);
            this.MultiplierLabel.Name = "MultiplierLabel";
            this.MultiplierLabel.Size = new System.Drawing.Size(125, 14);
            this.MultiplierLabel.TabIndex = 102;
            this.MultiplierLabel.Text = "Multiplier (0 < M < 1)";
            // 
            // KospiLengthTextBox
            // 
            this.KospiLengthTextBox.Location = new System.Drawing.Point(195, 59);
            this.KospiLengthTextBox.Name = "KospiLengthTextBox";
            this.KospiLengthTextBox.Size = new System.Drawing.Size(100, 27);
            this.KospiLengthTextBox.TabIndex = 103;
            this.KospiLengthTextBox.Text = "5";
            this.KospiLengthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LengthLabel
            // 
            this.LengthLabel.AutoSize = true;
            this.LengthLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LengthLabel.Location = new System.Drawing.Point(27, 66);
            this.LengthLabel.Name = "LengthLabel";
            this.LengthLabel.Size = new System.Drawing.Size(84, 14);
            this.LengthLabel.TabIndex = 102;
            this.LengthLabel.Text = "Length (days)";
            // 
            // PauseBtn
            // 
            this.PauseBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PauseBtn.Location = new System.Drawing.Point(371, 247);
            this.PauseBtn.Name = "PauseBtn";
            this.PauseBtn.Size = new System.Drawing.Size(328, 49);
            this.PauseBtn.TabIndex = 108;
            this.PauseBtn.Text = "PAUSE";
            this.PauseBtn.UseVisualStyleBackColor = true;
            this.PauseBtn.Click += new System.EventHandler(this.PauseBtn_Click);
            // 
            // RunBtn
            // 
            this.RunBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunBtn.Location = new System.Drawing.Point(12, 247);
            this.RunBtn.Name = "RunBtn";
            this.RunBtn.Size = new System.Drawing.Size(326, 49);
            this.RunBtn.TabIndex = 109;
            this.RunBtn.Text = "RUN";
            this.RunBtn.UseVisualStyleBackColor = true;
            this.RunBtn.Click += new System.EventHandler(this.RunBtn_Click);
            // 
            // KosdaqParamsGroup
            // 
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqTradeOffBtn);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqTradeOnBtn);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqTradeLabel);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqMaxAmountPerOrder);
            this.KosdaqParamsGroup.Controls.Add(this.label6);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqTradingAmountTextBox);
            this.KosdaqParamsGroup.Controls.Add(this.label2);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqLossCutRateTextBox);
            this.KosdaqParamsGroup.Controls.Add(this.label3);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqMultiplierTextBox);
            this.KosdaqParamsGroup.Controls.Add(this.label4);
            this.KosdaqParamsGroup.Controls.Add(this.KosdaqLengthTextBox);
            this.KosdaqParamsGroup.Controls.Add(this.label5);
            this.KosdaqParamsGroup.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KosdaqParamsGroup.Location = new System.Drawing.Point(371, 12);
            this.KosdaqParamsGroup.Name = "KosdaqParamsGroup";
            this.KosdaqParamsGroup.Size = new System.Drawing.Size(326, 229);
            this.KosdaqParamsGroup.TabIndex = 109;
            this.KosdaqParamsGroup.TabStop = false;
            this.KosdaqParamsGroup.Text = "KOSDAQ150 Params";
            // 
            // KosdaqTradeOffBtn
            // 
            this.KosdaqTradeOffBtn.AutoSize = true;
            this.KosdaqTradeOffBtn.Location = new System.Drawing.Point(233, 30);
            this.KosdaqTradeOffBtn.Name = "KosdaqTradeOffBtn";
            this.KosdaqTradeOffBtn.Size = new System.Drawing.Size(51, 23);
            this.KosdaqTradeOffBtn.TabIndex = 108;
            this.KosdaqTradeOffBtn.TabStop = true;
            this.KosdaqTradeOffBtn.Text = "Off";
            this.KosdaqTradeOffBtn.UseVisualStyleBackColor = true;
            // 
            // KosdaqTradeOnBtn
            // 
            this.KosdaqTradeOnBtn.AutoSize = true;
            this.KosdaqTradeOnBtn.Checked = true;
            this.KosdaqTradeOnBtn.Location = new System.Drawing.Point(165, 30);
            this.KosdaqTradeOnBtn.Name = "KosdaqTradeOnBtn";
            this.KosdaqTradeOnBtn.Size = new System.Drawing.Size(49, 23);
            this.KosdaqTradeOnBtn.TabIndex = 107;
            this.KosdaqTradeOnBtn.TabStop = true;
            this.KosdaqTradeOnBtn.Text = "On";
            this.KosdaqTradeOnBtn.UseVisualStyleBackColor = true;
            // 
            // KosdaqTradeLabel
            // 
            this.KosdaqTradeLabel.AutoSize = true;
            this.KosdaqTradeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KosdaqTradeLabel.Location = new System.Drawing.Point(27, 34);
            this.KosdaqTradeLabel.Name = "KosdaqTradeLabel";
            this.KosdaqTradeLabel.Size = new System.Drawing.Size(39, 14);
            this.KosdaqTradeLabel.TabIndex = 106;
            this.KosdaqTradeLabel.Text = "Trade";
            // 
            // KosdaqMaxAmountPerOrder
            // 
            this.KosdaqMaxAmountPerOrder.Location = new System.Drawing.Point(195, 187);
            this.KosdaqMaxAmountPerOrder.Name = "KosdaqMaxAmountPerOrder";
            this.KosdaqMaxAmountPerOrder.Size = new System.Drawing.Size(100, 27);
            this.KosdaqMaxAmountPerOrder.TabIndex = 105;
            this.KosdaqMaxAmountPerOrder.Text = "25";
            this.KosdaqMaxAmountPerOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 14);
            this.label6.TabIndex = 104;
            this.label6.Text = "Max Amount Per Order";
            // 
            // KosdaqTradingAmountTextBox
            // 
            this.KosdaqTradingAmountTextBox.Location = new System.Drawing.Point(195, 155);
            this.KosdaqTradingAmountTextBox.Name = "KosdaqTradingAmountTextBox";
            this.KosdaqTradingAmountTextBox.Size = new System.Drawing.Size(100, 27);
            this.KosdaqTradingAmountTextBox.TabIndex = 105;
            this.KosdaqTradingAmountTextBox.Text = "30";
            this.KosdaqTradingAmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 14);
            this.label2.TabIndex = 104;
            this.label2.Text = "Trading Amount";
            // 
            // KosdaqLossCutRateTextBox
            // 
            this.KosdaqLossCutRateTextBox.Location = new System.Drawing.Point(195, 123);
            this.KosdaqLossCutRateTextBox.Name = "KosdaqLossCutRateTextBox";
            this.KosdaqLossCutRateTextBox.Size = new System.Drawing.Size(100, 27);
            this.KosdaqLossCutRateTextBox.TabIndex = 105;
            this.KosdaqLossCutRateTextBox.Text = "1";
            this.KosdaqLossCutRateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 14);
            this.label3.TabIndex = 104;
            this.label3.Text = "LossCut (%)";
            // 
            // KosdaqMultiplierTextBox
            // 
            this.KosdaqMultiplierTextBox.Location = new System.Drawing.Point(195, 91);
            this.KosdaqMultiplierTextBox.Name = "KosdaqMultiplierTextBox";
            this.KosdaqMultiplierTextBox.Size = new System.Drawing.Size(100, 27);
            this.KosdaqMultiplierTextBox.TabIndex = 103;
            this.KosdaqMultiplierTextBox.Text = "0.7";
            this.KosdaqMultiplierTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 14);
            this.label4.TabIndex = 102;
            this.label4.Text = "Multiplier (0 < M < 1)";
            // 
            // KosdaqLengthTextBox
            // 
            this.KosdaqLengthTextBox.Location = new System.Drawing.Point(195, 59);
            this.KosdaqLengthTextBox.Name = "KosdaqLengthTextBox";
            this.KosdaqLengthTextBox.Size = new System.Drawing.Size(100, 27);
            this.KosdaqLengthTextBox.TabIndex = 103;
            this.KosdaqLengthTextBox.Text = "5";
            this.KosdaqLengthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 14);
            this.label5.TabIndex = 102;
            this.label5.Text = "Length (days)";
            // 
            // IndexFutureVoltyV1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 312);
            this.Controls.Add(this.KosdaqParamsGroup);
            this.Controls.Add(this.PauseBtn);
            this.Controls.Add(this.RunBtn);
            this.Controls.Add(this.KospiParamsGroup);
            this.Name = "IndexFutureVoltyV1";
            this.Text = "IndexFutureVoltyV1";
            this.KospiParamsGroup.ResumeLayout(false);
            this.KospiParamsGroup.PerformLayout();
            this.KosdaqParamsGroup.ResumeLayout(false);
            this.KosdaqParamsGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox KospiParamsGroup;
        private System.Windows.Forms.TextBox KospiTradingAmountTextBox;
        private System.Windows.Forms.Label TradingContractsLabel;
        private System.Windows.Forms.TextBox KospiLossCutRateTextBox;
        private System.Windows.Forms.Label TargetRateLabel;
        private System.Windows.Forms.TextBox KospiMultiplierTextBox;
        private System.Windows.Forms.Label MultiplierLabel;
        private System.Windows.Forms.TextBox KospiLengthTextBox;
        private System.Windows.Forms.Label LengthLabel;
        private System.Windows.Forms.Button PauseBtn;
        private System.Windows.Forms.Button RunBtn;
        private System.Windows.Forms.Label KospiTradeLabel;
        private System.Windows.Forms.RadioButton KospiTradeOffBtn;
        private System.Windows.Forms.RadioButton KospiTradeOnBtn;
        private System.Windows.Forms.GroupBox KosdaqParamsGroup;
        private System.Windows.Forms.RadioButton KosdaqTradeOffBtn;
        private System.Windows.Forms.RadioButton KosdaqTradeOnBtn;
        private System.Windows.Forms.Label KosdaqTradeLabel;
        private System.Windows.Forms.TextBox KosdaqTradingAmountTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox KosdaqLossCutRateTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox KosdaqMultiplierTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox KosdaqLengthTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox KospiMaxAmountPerOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox KosdaqMaxAmountPerOrder;
        private System.Windows.Forms.Label label6;
    }
}