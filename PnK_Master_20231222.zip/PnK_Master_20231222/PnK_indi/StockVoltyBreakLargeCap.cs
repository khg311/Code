﻿using System;
using AxGIExpertControl64Lib;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PnK_indi
{
    public partial class StockVoltyBreakLargeCap : Form
    {
        private readonly MainWindow Main;
        private readonly TypeConverter C = new TypeConverter();
        private Timer Timer = new Timer();

        private Dictionary<string, SubState> SubStates = new Dictionary<string, SubState>();

        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_PrevBalanceControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_MarketCapControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_MarketChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();
        private AxGIExpertControl64Lib.AxGIExpertControl64 indi_StockChartControl = new AxGIExpertControl64Lib.AxGIExpertControl64();

        private DateTime OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 1, 0);
        private DateTime StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 0);
        private DateTime StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 15, 0);
        private DateTime StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 50);
        private DateTime FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
        private DateTime FuturesSinglePriceTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 31, 0);
        private DateTime CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);


        private List<string> Excludings = new List<string>() { };

        private List<string> PrevBalances = new List<string>();

        public bool Enabled;
        public bool isReady = false;
        public bool isLastBalanceUpdated = false;
        public bool SentHedgeOrder { get; private set; }
        public bool NewBuyCondition = false;

        public int MarketOperationCase = 1;
        private bool _isMessageReceived_StockChart = false;
        private bool _isMessageReceived_MarketChart = false;
        private bool isCalcVoltyFinished = false;

        public Thread MarketPriceThread { get; private set; }
        public Thread PriceThread { get; private set; }
        

        private Timer StartTimer = new Timer();
        private Timer BalanceTimer = new Timer();

        private long Notional = 50_000_000;

        private long MarketCapCutOff = 0;
        

        public StockVoltyBreakLargeCap(MainWindow main)
        {
            InitializeComponent();

            this.Main = main;

            indi_PrevBalanceControl.CreateControl();
            indi_PrevBalanceControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceivePreviousBalanceData);

            indi_MarketCapControl.CreateControl();
            indi_MarketCapControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveMarketCapData);

            indi_MarketChartControl.CreateControl();
            indi_MarketChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveMarketChartData);

            indi_StockChartControl.CreateControl();
            indi_StockChartControl.ReceiveData += new AxGIExpertControl64Lib._DGIExpertControl64Events_ReceiveDataEventHandler(this.Indi_ReceiveStockChartData);
        }

        

        private void Indi_ReceiveMarketChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            this._isMessageReceived_MarketChart = true;
        }

        private void Indi_ReceiveStockChartData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {
            this._isMessageReceived_StockChart = true;
        }

        private void Enable()
        {
            Enabled = true;
        }

        public bool IsEnabled() => Enabled;

        public void Disable()
        {
            Enabled = false;
        }

        private void InitMarketOperationCase()
        {
            if (MarketOperationCase == 1)
            {

            }
            else if (MarketOperationCase == 2)
            {
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 0);
                StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 15, 0);
                StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 50);
                FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
                CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);
    }
            else if (MarketOperationCase == 3)
            {
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
                StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 19, 0);
                StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 15, 0);
                StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 19, 50);
                FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
                CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 50, 0);
            }
        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            if (!TradeOnButton.Checked && !TradeOffButton.Checked)
            {
                MessageBox.Show("트레이드 옵션을 선택하세요");
                return;
            }

            if (!Case1Button.Checked && !Case2Button.Checked && !Case3Button.Checked)
            {
                MessageBox.Show($"장 운영 유형을 선택하세요");
                return;
            }

            InitMarketOperationCase();

            ParamsGroupBox.Enabled = false;
            MarketOperationGroupBox.Enabled = false;

            InitSubStates();
            InitParams();

            RequestRealQuotes();

            MarketPriceThread = new Thread(() => GetPreviousKospiPrice());
            MarketPriceThread.Start();

            PriceThread = new Thread(() => UpdateDailyPrices());
            PriceThread.Start();

            StartTimer.Set(2 * 1000);
            StartTimer.Start(CheckCalcVoltyFinished);

            BalanceTimer.Set(5 * 1000);
            BalanceTimer.Start(ManageBalance);
        }

        private void CheckCalcVoltyFinished(object sender, EventArgs e)
        {
            if (this.isCalcVoltyFinished && DateTime.Now > OpeningTime)
            {
                StartTimer.Finish();
                this.Enable();

                Main.LogWriter.Write("Stock Volty Break is Enabled.");
            }
        }


        private void RequestRealQuotes()
        {
            foreach (var subState in SubStates.Values.ToList())
            {
                if (subState.State.MarketType == MarketType.Kospi)
                {
                    if (subState.State.SecurityGroupId == SecurityGroupId.EF || subState.State.SecurityGroupId == SecurityGroupId.EN)
                    {
                        continue;
                    }
                    else
                    {
                        Main.RequestA301S(subState.State.StandardCode);
                        Main.RequestB601S(subState.State.StandardCode);
                    }
                }
                else if (subState.State.MarketType == MarketType.Kosdaq)
                {
                    Main.RequestA301Q(subState.State.StandardCode);
                    Main.RequestB601Q(subState.State.StandardCode);
                }
            }

            var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();


            if (kospiNear != null)
            {
                Main.RequestG701F(kospiNear.ShortCode);
                Main.RequestB601F(kospiNear.ShortCode);
            }
        }

        private void InitSubStates()
        {
            foreach (var state in Main.States.Values)
            {
                // 주식 외 제외
                if (state.SecurityGroupId != SecurityGroupId.ST) { continue; }

                // 우선주 제외
                if (!state.ShortCode.EndsWith("0")) { continue; }

                // 락 종목 제외
                if (state.PriceAdjustment != PriceAdjustment.Normal) { continue; }

                // 스팩 제외
                if (state.Name.Contains("스팩")) { continue; }

                // 계열사 종목 제외
                if (state.Name.Contains("신한")) { continue; }

                // 제외할 종목
                if (Excludings.Contains(state.ShortCode)) { continue; }

                SubStates[state.ShortCode] = new SubState(state, C.AsLong(this.NotionalBox.Value));
            }

            Main.LogWriter.Write($"{SubStates.Count} SubStates are initiated.");
        }

        private void InitParams()
        {
            // Calc Market Cap Ranks
            foreach (var subState in SubStates.Values.ToList())
            {
                var shortCode = subState.State.ShortCode;

                if (subState.MarketCap < this.MarketCapCutOff)
                {
                    if (subState.State.NormalBalance == 0)
                    {
                        SubStates.Remove(shortCode);
                        continue;
                    }
                }
                VoltyData voltyData = new VoltyData(shortCode, 5, 0.75);
                subState.Enable(voltyData);
            }

            Main.LogWriter.Write($"{SubStates.Count()} SubStates are Targeted.");
            Main.LogWriter.Write($"Last MarketCap CutOff is : {SubStates.Values.Min(x => x.MarketCap):N0}");
        }

        private void GetPreviousKospiPrice()
        {
            indi_MarketChartControl.SetQueryName("TR_ICHART");

            indi_MarketChartControl.SetSingleData(0, "2101");
            indi_MarketChartControl.SetSingleData(1, "D");
            indi_MarketChartControl.SetSingleData(2, "1");
            indi_MarketChartControl.SetSingleData(3, "00000000");
            indi_MarketChartControl.SetSingleData(4, "99999999");
            indi_MarketChartControl.SetSingleData(5, "30");
            indi_MarketChartControl.RequestData();

            while (true)
            {
                if (this._isMessageReceived_MarketChart)
                    break;
            }

            this._isMessageReceived_MarketChart = false;

            var nCount = indi_MarketChartControl.GetMultiRowCount();
            if (nCount == 0) 
            {
                Main.LogWriter.Write("Indi Kospi Data Loading Error.");
                return; 
            }

            var closes = new List<double>();

            for (short i = 0; i < nCount; i++)
            {
                var _datetime = indi_MarketChartControl.GetMultiData(i, 0).ToString().Trim();
                var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}";

                // 당일자 데이터는 제외
                if (DateTime.Now.ToString("yyyy-MM-dd") == strDate) { continue; }

                var close = C.AsDouble(indi_MarketChartControl.GetMultiData(i, 5));

                closes.Insert(0, close);

                if (closes.Count >= 20)
                {
                    break;
                }
            }

            var AvgPrice = closes.Average();

            Console.WriteLine($"Close: {closes.Last()} / Avg: {AvgPrice}");

            if (closes.Last() > AvgPrice)
            {
                this.NewBuyCondition = true;
            }
        }

        private void UpdateDailyPrices()
        {
            foreach (var subState in SubStates.Values)
            {
                int updateTimes = 0;

                indi_StockChartControl.SetQueryName("TR_SCHART");
                indi_StockChartControl.SetSingleData(0, subState.State.ShortCode);
                indi_StockChartControl.SetSingleData(1, "D");
                indi_StockChartControl.SetSingleData(2, "1");
                indi_StockChartControl.SetSingleData(3, "00000000");
                indi_StockChartControl.SetSingleData(4, "99999999");
                indi_StockChartControl.SetSingleData(5, "10");
                indi_StockChartControl.RequestData();

                while (true)
                {
                    if (this._isMessageReceived_StockChart)
                        break;
                }

                this._isMessageReceived_StockChart = false;

                var nCount = indi_StockChartControl.GetMultiRowCount();
                if (nCount == 0) { continue; }


                var closes = new List<double>();
                var lows = new List<double>();

                double adj = 1.0d;

                for (short i = 0; i < nCount; i++)
                {
                    var _datetime = indi_StockChartControl.GetMultiData(i, 0).ToString().Trim();
                    var strDate = $"{_datetime.Substring(0, 4)}-{_datetime.Substring(4, 2)}-{_datetime.Substring(6, 2)}";

                    // 당일자 데이터는 제외
                    if (DateTime.Now.ToString("yyyy-MM-dd") == strDate) { continue; }

                    var high = C.AsDouble(indi_StockChartControl.GetMultiData(i, 3)) * adj;
                    var low = C.AsDouble(indi_StockChartControl.GetMultiData(i, 4)) * adj;
                    var close = C.AsDouble(indi_StockChartControl.GetMultiData(i, 5)) * adj;
                    closes.Add(close);
                    lows.Add(low);
                    subState.UpdatePrices(high, low, close);
                    updateTimes++;

                    adj = adj * C.AsDouble(indi_StockChartControl.GetMultiData(i, 6));

                    if (updateTimes > subState._VoltyData.Length + 1) { break; }

                }

                subState.CalcVolty();

                if (subState.State.NormalBalance > 0 && PrevBalances.Contains(subState.State.ShortCode))
                {
                    if (lows[0] < closes[1] * (1 - 0.07))
                    {
                        subState.HasToSell = true;
                        Main.LogWriter.Write($"[  Had To Sell  ] {subState.State.ShortCode} {subState.State.Name} Yesterday 7% Loss Cut pLow < ppClose (1 - 0.07)");
                    }
                    else if (closes[0] < subState.pVoltyLow)
                    {
                        subState.HasToSell = true;
                        Main.LogWriter.Write($"[  Had To Sell  ] {subState.State.ShortCode} {subState.State.Name} pClose={closes[0]:F0} < pvLow={subState.pVoltyLow:F2}");
                    }
                }

                if (subState.VoltyHIgh > 0 && subState.VoltyLow > 0)
                {
                    subState.isReady = true;
                }
            }

            this.isCalcVoltyFinished = true;
        }

        internal void UpdateQuotes(RealTimeDataType dataType, StockState state)
        {
            if (!isCalcVoltyFinished || dataType == RealTimeDataType.Quote || !state.IsEnabled()) { return; }

            if (SubStates.TryGetValue(state.ShortCode, out SubState subState))
            {
                if (!subState.isReady) { return; }

                if (subState.Prev3MinData.Count() == 0)
                {
                    subState.Prev3MinData.Enqueue((state.CurrentPrice, DateTime.Now));
                }
                else if ((DateTime.Now - subState.Prev3MinData.Last().Time).TotalSeconds > 60)
                {
                    subState.Prev3MinData.Enqueue((state.CurrentPrice, DateTime.Now));

                    if (subState.Prev3MinData.Count > 3)
                    {
                        subState.Prev3MinData.Dequeue();
                    }
                }

                // 기존 포지션이 없는 경우
                if (state.NormalBalance == 0 && state.BalanceAvailableToSell == 0 && !state.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask))
                {
                    // 매수 진입조건 판단
                    bool LongEntryCondition = state.CurrentPrice > subState.VoltyHIgh
                                                && state.OpenPrice < subState.VoltyHIgh
                                                && subState.AtrRatio >= 0.03
                                                && LongCheckBox.Checked
                                                && !Main.StockBalances.Any(x => x.FundCode == "9504" && x.ShortCode == state.ShortCode)
                                                && DateTime.Now < StockLastBuyTime;

                    if (IndexConditionCheckBox.Checked)
                        LongEntryCondition = LongEntryCondition && this.NewBuyCondition;

                    if (LongEntryCondition)
                    {
                        if (subState.SentBid || state.LiveOrders.Any(x => x.AskBidType == AskBidType.Bid)) { return; }

                        subState.SentBid = true;
                        subState.HasToSell = false;

                        var orderPrice = state.PriceHelper.RoundPriceUp(C.AsLong(subState.VoltyHIgh * 1.01));
                        var orderQuantity = C.AsLong(subState.TradingAmount / orderPrice) - 1;
                        Main.LogWriter.Write($"[  Break vHigh  ] {state.ShortCode} {state.Name} Now={state.CurrentPrice:F0} > vHigh={subState.VoltyHIgh:F2}");

                        if (TradeOffButton.Checked || !TradeOnButton.Checked) { return; }

                        state.NewOrder(AskBidType.Bid, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                        return;
                    }
                }
                else if (state.NormalBalance > 0)
                {
                    if (!subState.HasToSell && ShortCheckBox.Checked)
                    {
                        bool LongExitCondition = state.CurrentPrice < subState.VoltyLow && DateTime.Now > StockSellTime;

                        bool LossCut = state.CurrentPrice < state.PreviousDayPrice * (1 - 0.07);

                        bool EmergencyCut = state.CurrentPrice < subState.Prev3MinData.First().Price * (1 - 0.05) && state.CurrentPrice < state.PreviousDayPrice;

                        bool YellowBarLossCut = state.CurrentPrice < state.AverageBuyPrice * (1 - 0.2);

                        if (EmergencyCut)
                        {
                            subState.HasToSell = true;
                            Main.LogWriter.Write($"[ Emergency Cut ] {state.ShortCode} {state.Name} Now={state.CurrentPrice:F0} < EmergencyPrice={subState.Prev3MinData.First().Price * (1 - 0.05):F2}");
                        }
                        else if (LossCut)
                        {
                            subState.HasToSell = true;
                            Main.LogWriter.Write($"[  7% Loss Cut  ] {state.ShortCode} {state.Name} Now={state.CurrentPrice:F0} < LossCut={state.PreviousDayPrice * (1 - 0.07):F2}");
                        }
                        else if (LongExitCondition)
                        {
                            subState.HasToSell = true;
                            Main.LogWriter.Write($"[ On Close Exit ]{state.ShortCode} {state.Name} Now={state.CurrentPrice:F0} < vLow={subState.VoltyLow:F2}");
                        }
                        else if (YellowBarLossCut)
                        {
                            subState.HasToSell = true;
                            Main.LogWriter.Write($"[  Yellow  Bar  ]{state.ShortCode} {state.Name} Now={state.CurrentPrice:F0} : -20% touched.");
                        }
                    }
                }
            }
        }

        private void ManageBalance(object sender, EventArgs e)
        {
            if (DateTime.Now < OpeningTime)
            {
                return;
            }

            // ~15:30:00
            if (DateTime.Now < FuturesOrderTime)
            {
                // ~ 15:20:00
                if (DateTime.Now < StockLastSellTime)
                {
                    foreach (var subState in SubStates.Values)
                    {
                        var state = subState.State;

                        // 아직 가격정보 반영되지 않은 종목 제외
                        if (state.CurrentPrice == 0) { continue; }

                        // 잔고 변동 후 3초 경과
                        if (!state.IsSellable()) { continue; }

                        // 매도가능 수량이 있는 경우
                        if (state.BalanceAvailableToSell > 0 || state.NormalBalance > 0)
                        {
                            // 잔고 있는 종목은 매수 제한
                            if (!subState.SentBid)
                            {
                                subState.SentBid = true;
                                continue;
                            }

                            if (subState.HasToSell)
                            {
                                if (state.LiveOrders.Any(x => x.AskBidType == AskBidType.Bid))
                                {
                                    state.CancelOrders(AskBidType.Bid);
                                    continue;
                                }
                                
                                if (!state.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask))
                                {
                                    var orderPrice = Math.Max(state.PriceHelper.GetNextPriceBelowTicks(state.CurrentPrice, 10), state.LowerLimitPrice);
                                    var orderQuantity = state.BalanceAvailableToSell;

                                    var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == state.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                                    if (liveOrders.Count() > 0)
                                    {
                                        var orderedPrice = liveOrders.Max(x => x.Price);
                                        orderPrice = Math.Max(orderPrice, state.PriceHelper.GetNextPriceAbove(orderedPrice));
                                    }

                                    if (TradeOffButton.Checked || !TradeOnButton.Checked) { continue; }

                                    state.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                                    continue;
                                }
                                else
                                {
                                    foreach (var liveOrder in state.LiveOrders)
                                    {
                                        if ((DateTime.Now - liveOrder.OrderTime).TotalSeconds > 10 && liveOrder.Price != state.LowerLimitPrice && !state.IsViActive)
                                        {
                                            state.CancelOrder(liveOrder);
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // 15:20:00 ~15:30:00
                else
                {
                    // 종가매도 로직 추가 15:29:45 ~ 
                    if (DateTime.Now.Minute >= 29 && DateTime.Now.Second >= 45)
                    {
                        foreach (var subState in SubStates.Values)
                        {
                            var state = subState.State;

                            // 잔고 변동 후 3초 경과
                            if (!state.IsSellable()) { continue; }

                            // 매도가능 수량이 있는 경우
                            if (state.BalanceAvailableToSell > 0)
                            {
                                bool LongClearCondition = state.Expected.Price < subState.VoltyLow;
                                
                                if (LongClearCondition)
                                {
                                    if (state.LiveOrders.Any(x => x.AskBidType == AskBidType.Bid))
                                    {
                                        state.CancelOrders(AskBidType.Bid);
                                        continue;
                                    }
                                    else if (!state.LiveOrders.Any(x => x.AskBidType == AskBidType.Ask))
                                    {
                                        var orderPrice = state.PriceHelper.GetNextPriceBelowTicks(state.Expected.Price, 1);

                                        var orderQuantity = state.BalanceAvailableToSell;

                                        var liveOrders = Main.LiveOrders.Where(x => x.StandardCode == state.StandardCode && x.AskBidType == AskBidType.Bid).ToList();

                                        if (liveOrders.Count() > 0)
                                        {
                                            var orderedPrice = liveOrders.Max(x => x.Price);
                                            orderPrice = Math.Max(orderPrice, state.PriceHelper.GetNextPriceAbove(orderedPrice));
                                        }

                                        if (orderPrice <= state.CurrentPrice * (1 - 0.01))
                                        {
                                            orderQuantity = C.AsLong(Math.Min(state.BalanceAvailableToSell, state.Expected.Volume * 0.2));
                                        }

                                        if (TradeOffButton.Checked || !TradeOnButton.Checked) { continue; }

                                        state.NewOrder(AskBidType.Ask, orderPrice, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // 15:30:00 ~ 15:50:00
            else if (DateTime.Now < CloseTime)
            {
                // 15:31:00 ~ 
                if (DateTime.Now > FuturesSinglePriceTime)
                {
                    if (!this.isLastBalanceUpdated)
                    {
                        UpdateBalances();
                        this.isLastBalanceUpdated = true;
                        return;
                    }
                    else
                    {
                        var kospiNear = Main.DerivStates.Values.Where(x => x.ShortCode.StartsWith("101") && x.ExpiryDate != DateTime.Now.ToString("yyyyMMdd")).OrderBy(x => x.ExpiryDate).FirstOrDefault();

                        if (this.SentHedgeOrder) { return; }

                        long stockDelta = 0;

                        foreach (var subState in SubStates.Values)
                        {
                            stockDelta += subState.State.NormalBalance * subState.State.AverageBuyPrice;
                        }

                        long hedgeDelta = Math.Abs(C.AsLong(kospiNear.NormalBalance * kospiNear.AveragePrice * 250_000));

                        var netDelta = stockDelta - hedgeDelta;

                        Main.LogWriter.Write($"Stock Delta: {stockDelta:N0} - Hedge Delta: {hedgeDelta:N0} = Net Delta: {netDelta:N0}");

                        if (netDelta > 0)
                        {
                            this.SentHedgeOrder = true;
                            var orderQuantity = C.AsLong(Math.Abs(Math.Floor(netDelta / kospiNear.CurrentPrice / 250_000)));
                            if (orderQuantity <= 0) { return; }

                            if (TradeOffButton.Checked || !TradeOnButton.Checked) { return; }

                            kospiNear.NewOrder(AskBidType.Ask, kospiNear.CurrentPrice - 0.05 * 20, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                        }
                        else if (netDelta < 0)
                        {
                            this.SentHedgeOrder = true;
                            var orderQuantity = C.AsLong(Math.Abs(Math.Floor(netDelta / kospiNear.CurrentPrice / 250_000)));
                            if (orderQuantity <= 0) { return; }

                            if (TradeOffButton.Checked || !TradeOnButton.Checked) { return; }

                            kospiNear.NewOrder(AskBidType.Bid, kospiNear.CurrentPrice + 0.05 * 20, orderQuantity, OrderType.Limit, OrderCondition.Normal);
                        }
                    }
                }
            }
            // 15:50:00 ~
            else if (DateTime.Now > CloseTime)
            {
                BalanceTimer.Finish();
                Environment.Exit(0);
            }
        }

        private void UpdateBalances()
        {
            Main.CommHelper.RequestQ80001(Main.n_mKey, Main.FundCode, Main.EmployeeId);
        }

        internal void OnConfirm(StockState state)
        {
            //throw new NotImplementedException();
        }

        internal void OnExecution(StockState state)
        {
            //throw new NotImplementedException();
        }

        #region Strategy Controls


        private void ResumeButton_Click(object sender, EventArgs e)
        {
            this.Enable();
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            this.Disable();
        }
        #endregion

        private class SubState
        {
            internal StockState State;

            internal VoltyData _VoltyData;
            internal double VoltyHIgh => _VoltyData.VoltyHigh;
            internal double VoltyLow => _VoltyData.VoltyLow;

            internal double pVoltyHIgh => _VoltyData.prevVoltyHigh;
            internal double pVoltyLow => _VoltyData.prevVoltyLow;

            internal double AtrRatio => _VoltyData.thisATR / State.PreviousDayPrice;

            internal long MarketCap;

            internal int MarketCapRank;

            internal Queue<(long Price, DateTime Time)> Prev3MinData = new Queue<(long Price, DateTime Time)>();

            internal long TradingAmount;

            internal bool Enabled;
            internal bool isReady;

            internal bool SentBid = false;
            internal bool HasToSell = false;
            internal bool HadToSell = false;

            public SubState(StockState state, long notional)
            {
                this.State = state;
                this.MarketCap = this.State.OutstandingShares * this.State.PreviousDayPrice;
                this.TradingAmount = notional;
            }

            public void Enable(VoltyData voltyData)
            {
                this._VoltyData = voltyData;
                this.Enabled = true;
            }

            public void Disable()
            {
                this.Enabled = false;
            }


            public void UpdatePrices(double high, double low, double close)
            {
                this._VoltyData.Update(high, low, close);
            }


            public void CalcVolty()
            {
                this._VoltyData.CalcVolty();
            }

            internal void UpdateTradingAmount(long notional)
            {
                this.TradingAmount = notional;
            }
        }

        internal class VoltyData
        {
            public string ShortCode { get; private set; }
            public Queue<double> HighPrices { get; private set; }
            public Queue<double> LowPrices { get; private set; }
            public Queue<double> ClosePrices { get; private set; }
            public Queue<double> TrueRange { get; private set; }

            public int Length { get; private set; }
            public double thisATR { get; private set; }
            public double prevATR { get; private set; }
            public double Multiplier { get; private set; }
            public double VoltyHigh { get; private set; }
            public double VoltyLow { get; private set; }

            public double prevVoltyHigh { get; private set; }
            public double prevVoltyLow { get; private set; }


            public VoltyData(string shortCode, int length, double multiplier)
            {
                this.ShortCode = shortCode;
                this.Length = length;
                this.Multiplier = multiplier;

                this.HighPrices = new Queue<double>();
                this.LowPrices = new Queue<double>();
                this.ClosePrices = new Queue<double>();
                this.TrueRange = new Queue<double>();
            }

            public void Update(double high, double low, double close)
            {
                this.HighPrices.Enqueue(high);
                this.LowPrices.Enqueue(low);
                this.ClosePrices.Enqueue(close);
            }
            
            public void CalcVolty()
            {
                if (this.HighPrices.Count < this.Length + 1 || this.LowPrices.Count < this.Length + 1 || this.ClosePrices.Count < this.Length + 1)
                {
                    return;
                }

                double cClose = this.ClosePrices.Dequeue();

                double prevClose = 0;

                try
                {
                    for (int i = 0; i < this.Length + 1; i++)
                    {
                        double cHigh = this.HighPrices.Dequeue();
                        double cLow = this.LowPrices.Dequeue();
                        double pClose = this.ClosePrices.Dequeue();
                        if (i == 0)
                        {
                            prevClose = pClose;
                        }

                        this.TrueRange.Enqueue(Math.Max(cHigh, pClose) - Math.Min(cLow, pClose));
                    }

                    this.thisATR = this.TrueRange.ToList().GetRange(0, this.Length).Average();
                    this.prevATR = this.TrueRange.ToList().GetRange(1, this.Length).Average();

                    this.VoltyHigh = cClose + this.thisATR * this.Multiplier;
                    this.VoltyLow = cClose - this.thisATR * this.Multiplier;

                    this.prevVoltyHigh = prevClose + this.prevATR * this.Multiplier;
                    this.prevVoltyLow = prevClose - this.prevATR * this.Multiplier;

                    Console.WriteLine($"Today {this.ShortCode} Volty Values {this.VoltyLow:F1} {this.VoltyHigh:F1} / ATR Ratio {this.thisATR / cClose:F3}");
                    Console.WriteLine($"Prev  {this.ShortCode} Volty Values {this.prevVoltyLow:F1} {this.prevVoltyHigh:F1}");
                }
                catch (System.InvalidOperationException)
                {
                    Console.WriteLine($"{ShortCode} Price Length is too short");
                }
            }
        }

        private void NotionalBox_ValueChanged(object sender, EventArgs e)
        {
            Main.LogWriter.Write($"Trading Amount Changed: {this.Notional:N0} -> {NotionalBox.Value:N0}");

            this.Notional = C.AsLong(NotionalBox.Value);

            if (SubStates.Count() > 0)
            {
                foreach (var subState in SubStates.Values)
                {
                    subState.UpdateTradingAmount(this.Notional);
                }
            }
        }

        private void BalanceButton_Click(object sender, EventArgs e)
        {
            UpdateBalances();
        }

        private void TradeOnButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void StockVoltyBreak_Load(object sender, EventArgs e)
        {
            GetPreviousBalances();
            CalcMarketCapCutOff();
        }


        private void GetPreviousBalances()
        {
            indi_PrevBalanceControl.SetQueryName("SCBA321Q1");
            indi_PrevBalanceControl.SetSingleData(0, DateTime.Now.AddDays(-1).ToString("yyyyMMdd"));
            indi_PrevBalanceControl.SetSingleData(1, Main.FundCode);
            //indi_PrevBalanceControl.SetSingleData(2, "")
            indi_PrevBalanceControl.SetSingleData(3, "1");
            indi_PrevBalanceControl.SetSingleData(4, "0");
            indi_PrevBalanceControl.SetSingleData(5, "3");
            indi_PrevBalanceControl.SetSingleData(6, "744");

            var ret = indi_PrevBalanceControl.RequestData();

            if (ret <= 0)
            {
                Console.WriteLine("Request Error");
            }
        }

        private void Indi_ReceivePreviousBalanceData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {

            var nCnt = indi_PrevBalanceControl.GetMultiRowCount();

            for (short i = 0; i < nCnt; i++)
            {
                var shortCode = indi_PrevBalanceControl.GetMultiData(i, 3).ToString();
                var Name = indi_PrevBalanceControl.GetMultiData(i, 4).ToString();
                var NormalBalance = C.AsLong(indi_PrevBalanceControl.GetMultiData(i, 5).ToString());
                Console.WriteLine($"{shortCode} {Name} {NormalBalance}");

                PrevBalances.Add(shortCode);
            }
        }

        private void CalcMarketCapCutOff()
        {
            indi_MarketCapControl.SetQueryName("TR_RB001");
            indi_MarketCapControl.SetSingleData(0, "0");

            var ret = indi_MarketCapControl.RequestData();

            if (ret <= 0)
            {
                Console.WriteLine("Request Error: [TR_RB001]");
            }
        }


        private void Indi_ReceiveMarketCapData(object sender, _DGIExpertControl64Events_ReceiveDataEvent e)
        {

            Dictionary<string, long> MarketCaps = new Dictionary<string, long>();

            var nCnt = indi_MarketCapControl.GetMultiRowCount();

            for (short i = 0; i < nCnt; i++)
            {
                var shortCode = indi_MarketCapControl.GetMultiData(i, 1).ToString().Trim();
                var securityGroupId = indi_MarketCapControl.GetMultiData(i, 19).ToString();

                if (securityGroupId != "ST" || !shortCode.EndsWith("0"))
                    continue;
                
                var outstandingShares = C.AsLong(indi_MarketCapControl.GetMultiData(i, 18));
                var close = C.AsLong(indi_MarketCapControl.GetMultiData(i, 26));

                MarketCaps[shortCode] = outstandingShares * close;
            }

            var OrderedMarketCaps = MarketCaps.OrderByDescending(x => x.Value);
            var cutoffShortCode = OrderedMarketCaps.ElementAt(200).Key;
            var cutoffMarketCap = OrderedMarketCaps.ElementAt(200).Value;

            this.MarketCapCutOff = cutoffMarketCap;

            Main.LogWriter.Write($"Cutoff: {cutoffShortCode} {cutoffMarketCap:N0}");
        }

        internal void UpdateTimes()
        {
            if (Main.Open9Close15RadioButton.Checked)
            {
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 1, 0);
                StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 0);
                StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 15, 0);
                StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 50);
                FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
                CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);
            }
            else if (Main.Open10Close15RadioButton.Checked)
            {
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 1, 0);
                StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 0);
                StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 15, 0);
                StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 19, 50);
                FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0);
                CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 50, 0);
            }
            else if (Main.Open10Close16RadioButton.Checked)
            {
                OpeningTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 1, 0);
                StockLastBuyTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 19, 0);
                StockSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 15, 0);
                StockLastSellTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 19, 50);
                FuturesOrderTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 30, 0);
                CloseTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 50, 0);
            }
        }
    }
}
