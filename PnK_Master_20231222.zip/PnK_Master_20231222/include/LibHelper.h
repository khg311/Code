#pragma once

#include "CommonFilePath.h"

class ILibHelper
{
public:
	ILibHelper(void)
	{
		m_hLibModule		= NULL;
		m_bInitialized		= FALSE;
	}

	~ILibHelper(void)
	{
		if( m_hLibModule ) FreeLibrary(m_hLibModule);
	}

	inline	int				Initialize();
	inline	void			UnInitialize();

protected:
	inline	int				LoadLibHelper();

protected:
	HMODULE					m_hLibModule;
	BOOL					m_bInitialized;
	CString					m_strLibName;
};

int	ILibHelper::Initialize()
{
	if( m_bInitialized ) return TRUE;

	int nRet = LoadLibHelper();

	if( nRet < 0 ) return nRet;

	m_bInitialized = TRUE;

	return nRet;
}

void ILibHelper::UnInitialize()
{
	if( !m_bInitialized ) return;
	
	if( m_hLibModule ) FreeLibrary(m_hLibModule);

	m_hLibModule	= NULL;
	m_bInitialized	= FALSE;
}

int	ILibHelper::LoadLibHelper()
{
	m_hLibModule = ::LoadLibrary(CCommonFilePath::GetModuleFullPath(m_strLibName));

	if( NULL == m_hLibModule )
	{	// ������ ���丮�� ������ Current���� �ѹ� ��_
		m_hLibModule = ::LoadLibrary(m_strLibName);
	}

	if( NULL == m_hLibModule ) return -1;

	return	1;
}