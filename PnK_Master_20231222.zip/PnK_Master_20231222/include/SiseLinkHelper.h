#pragma once

#include "LibHelper.h"

typedef void				(*FP_EXIT_OK)				();
typedef BOOL				(*FP_SET_SISEHWND)			(HWND);
typedef HWND				(*FP_GET_SISEHWND)			();

typedef void				(*FP_RUN_SISE)				(LPCTSTR, BOOL);
typedef	void				(*FP_CONNECT_SISE)			(LPCTSTR);
typedef void				(*FP_EXIT_SISE)				();

typedef void				(*FP_REGIST)				(void*);
typedef void				(*FP_RELEASE)				(void*);
typedef void				(*FP_RELEASEALL)			(void*);

typedef void				(*FP_REGIST_CAPTION)		(HWND, LPCTSTR);
typedef void				(*FP_RELEASE_CAPTION)		(HWND);

class ISiseLinkHelper  : public ILibHelper 
{
public:
	ISiseLinkHelper()
	{
		m_strLibName		= _T("SiseLinkLib.dll");
		m_fpExitOK			= NULL;
		m_fpSetSiseHwnd		= NULL;
		m_fpGetSiseHwnd		= NULL;
		m_fpRunSise			= NULL;
		m_fpConnectSise		= NULL;
		m_fpExitSise		= NULL;
		m_fpRegist			= NULL;
		m_fpRelease			= NULL;
		m_fpReleaseAll		= NULL;
		m_fpRegistCaption	= NULL;
		m_fpReleaseCaption	= NULL;
	}
	virtual ~ISiseLinkHelper()
	{
	}

public:
	inline	void			ExitOK();
	inline	BOOL			SetSiseHwnd(HWND);
	inline	HWND			GetSiseHwnd();
	inline	void			RunSise(LPCTSTR, BOOL);
	inline	void			ConnectSise(LPCTSTR);
	inline	void			ExitSise();
	inline	void			Regist(void*);
	inline	void			Release(void*);
	inline	void			ReleaseAll(void*);
	inline	void			RegistCaption(HWND, LPCTSTR);
	inline	void			ReleaseCaption(HWND);

protected:
	FP_EXIT_OK				m_fpExitOK;
	FP_SET_SISEHWND			m_fpSetSiseHwnd;
	FP_GET_SISEHWND			m_fpGetSiseHwnd;
	FP_RUN_SISE				m_fpRunSise;
	FP_CONNECT_SISE			m_fpConnectSise;
	FP_EXIT_SISE			m_fpExitSise;
	FP_REGIST				m_fpRegist;
	FP_RELEASE				m_fpRelease;
	FP_RELEASEALL			m_fpReleaseAll;
	FP_REGIST_CAPTION		m_fpRegistCaption;
	FP_RELEASE_CAPTION		m_fpReleaseCaption;
};

void ISiseLinkHelper::ExitOK()
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpExitOK )	
		m_fpExitOK = (FP_EXIT_OK)GetProcAddress(m_hLibModule, "ExitOK");

	if( NULL == m_fpExitOK )	return;

	return m_fpExitOK();
}

BOOL ISiseLinkHelper::SetSiseHwnd(HWND hWnd)
{
	if( NULL == m_hLibModule )	return FALSE;

	if( NULL == m_fpSetSiseHwnd )	
		m_fpSetSiseHwnd = (FP_SET_SISEHWND)GetProcAddress(m_hLibModule, "SetSiseHwnd");

	if( NULL == m_fpSetSiseHwnd )	return FALSE;

	return m_fpSetSiseHwnd(hWnd);
}

HWND ISiseLinkHelper::GetSiseHwnd()
{
	if( NULL == m_hLibModule )	return NULL;

	if( NULL == m_fpGetSiseHwnd )	
		m_fpGetSiseHwnd = (FP_GET_SISEHWND)GetProcAddress(m_hLibModule, "GetSiseHwnd");

	if( NULL == m_fpGetSiseHwnd )	return NULL;

	return m_fpGetSiseHwnd();
}

void ISiseLinkHelper::RunSise(LPCTSTR lpszEXE, BOOL IsReCreate)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpRunSise )	
		m_fpRunSise = (FP_RUN_SISE)GetProcAddress(m_hLibModule, "RunSise");

	if( NULL == m_fpRunSise )	return;

	m_fpRunSise(lpszEXE, IsReCreate);
}

void ISiseLinkHelper::ConnectSise(LPCTSTR lpszSvrIp)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpConnectSise )	
		m_fpConnectSise = (FP_CONNECT_SISE)GetProcAddress(m_hLibModule, "ConnectSise");

	if( NULL == m_fpConnectSise )	return;

	m_fpConnectSise(lpszSvrIp);
}

void ISiseLinkHelper::ExitSise()
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpExitSise )	
		m_fpExitSise = (FP_EXIT_SISE)GetProcAddress(m_hLibModule, "ExitSise");

	if( NULL == m_fpExitSise )	return;

	m_fpExitSise();
}

void ISiseLinkHelper::Regist(void *pArg)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpRegist )	
		m_fpRegist = (FP_REGIST)GetProcAddress(m_hLibModule, "Regist");

	if( NULL == m_fpRegist )	return;

	m_fpRegist(pArg);
}

void ISiseLinkHelper::Release(void *pArg)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpRelease )	
		m_fpRelease = (FP_RELEASE)GetProcAddress(m_hLibModule, "Release");

	if( NULL == m_fpRelease )	return;

	m_fpRelease(pArg);
}

void ISiseLinkHelper::ReleaseAll(void *pArg)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpReleaseAll )	
		m_fpReleaseAll = (FP_RELEASEALL)GetProcAddress(m_hLibModule, "ReleaseAll");

	if( NULL == m_fpReleaseAll )	return;

	m_fpReleaseAll(pArg);
}

void ISiseLinkHelper::RegistCaption(HWND hWnd, LPCTSTR lpszCaption)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpRegistCaption )	
		m_fpRegistCaption = (FP_REGIST_CAPTION)GetProcAddress(m_hLibModule, "RegistCaption");

	if( NULL == m_fpRegistCaption )	return;

	m_fpRegistCaption(hWnd, lpszCaption);
}

void ISiseLinkHelper::ReleaseCaption(HWND hWnd)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpReleaseCaption )	
		m_fpReleaseCaption = (FP_RELEASE_CAPTION)GetProcAddress(m_hLibModule, "ReleaseCaption");

	if( NULL == m_fpReleaseCaption )	return;

	m_fpReleaseCaption(hWnd);
}