#pragma once

#include "LibHelper.h"

#ifndef COMMLIB_FILENAME
#define COMMLIB_FILENAME		_T("CommLib.dll")
#endif

typedef BOOL				(*FP_INIT_COMM)			(HWND, LPCTSTR);
typedef BOOL				(*FP_INIT_COMMLOGIN)	(HWND, LPCTSTR);
typedef BOOL				(*FP_RELEASE_COMM)		();
typedef int					(*FP_ADD_HWND)			(HWND, LPCTSTR);
typedef void				(*FP_DEL_HWND)			(int);
typedef void				(*FP_SET_LOCAL_IP)		(LPCTSTR);
typedef LPCTSTR				(*FP_GET_LOCAL_IP)		();
typedef int					(*FP_REQUEST_DATA)		(int, LPCTSTR, LPCTSTR, int, LPCTSTR, LPCTSTR);
typedef int					(*FP_REGIST_ACCOUNT)	(LPCTSTR, int);
typedef int					(*FP_REGIST_REAL)		(LPCTSTR, void*);
typedef int					(*FP_RELEASE_REAL)		(int);
typedef int					(*FP_REQUEST_VERSION)	(int, LPCTSTR, LPCTSTR, int);
typedef int					(*FP_SEND_KOSPIFO_ORDER)(int, LPCTSTR, int);
typedef int					(*FP_SEND_STOCK_ORDER)  (int, LPCTSTR, int);
typedef void				(*FP_WRITE_LOG)			(LPCTSTR);
typedef void				(*FP_RUN_FTPSENDER)		(LPCTSTR);
typedef void				(*FP_SET_LOGINID)		(LPCTSTR);

class ICommHelper : public ILibHelper
{
public:
	ICommHelper(void)
	{
		m_strLibName			= COMMLIB_FILENAME;
		m_fpInitComm			= nullptr;
		m_fpInitCommLogin		= nullptr;
		m_fpReleaseComm			= nullptr;
		m_fpAddHwnd				= nullptr;
		m_fpDelHwnd				= nullptr;
		m_fpSetLocalIP			= nullptr;
		m_fpGetLocalIP			= nullptr;
		m_fpRequestData			= nullptr;
		m_fpRegistAccount		= nullptr;
		m_fpRegistReal			= nullptr;
		m_fpReleaseReal			= nullptr;
		m_fpRequestVersion		= nullptr;
		m_fpSendKospiFOOrder	= nullptr;
		m_fpWriteLog			= nullptr;
		m_fpRunFTPSender		= nullptr;
		m_fpSetLoginId			= nullptr;
		m_fpSendStockOrder		= nullptr;
	}

	~ICommHelper(void)
	{
	}

	inline	BOOL			InitComm(HWND, LPCTSTR);
	inline	BOOL			InitCommLogin(HWND, LPCTSTR);
	inline	void			ReleaseComm();
	inline	int				AddHwnd(HWND, LPCTSTR);
	inline	void			DelHwnd(int);
	inline	void			SetLocalIP(LPCTSTR);
	inline	LPCTSTR			GetLocalIP();
	inline	int				RequestData(int, LPCTSTR, LPCTSTR, int, LPCTSTR = _T(" "), LPCTSTR = _T("  "));
	inline	int				RegistAccount(LPCTSTR, int);
	inline	int				RegistReal(LPCTSTR, LPVOID);
	inline	int				ReleaseReal(int);
	inline	int				RequestVersion(int, LPCTSTR, LPCTSTR, int);
	inline	int				SendKospiFOOrder(int, LPCTSTR, int);
	inline	int				SendStockOrder(int, LPCTSTR, int);
	inline	void			WriteLog(LPCTSTR);
	inline	void			RunFTPSender(LPCTSTR);
	inline	void			SetLoginId(LPCTSTR);

protected:
	FP_INIT_COMM			m_fpInitComm;
	FP_INIT_COMMLOGIN		m_fpInitCommLogin;
	FP_RELEASE_COMM			m_fpReleaseComm;
	FP_ADD_HWND				m_fpAddHwnd;
	FP_DEL_HWND				m_fpDelHwnd;
	FP_SET_LOCAL_IP			m_fpSetLocalIP;
	FP_GET_LOCAL_IP			m_fpGetLocalIP;
	FP_REQUEST_DATA			m_fpRequestData;
	FP_REGIST_ACCOUNT		m_fpRegistAccount;
	FP_REGIST_REAL			m_fpRegistReal;
	FP_RELEASE_REAL			m_fpReleaseReal;
	FP_REQUEST_VERSION		m_fpRequestVersion;
	FP_SEND_KOSPIFO_ORDER	m_fpSendKospiFOOrder;
	FP_WRITE_LOG			m_fpWriteLog;
	FP_RUN_FTPSENDER		m_fpRunFTPSender;
	FP_SET_LOGINID			m_fpSetLoginId;
	FP_SEND_STOCK_ORDER		m_fpSendStockOrder;
};


BOOL ICommHelper::InitComm(HWND hParent, LPCTSTR lpszSvrIp)
{
	if( NULL == m_hLibModule )	return FALSE;

	if( NULL == m_fpInitComm )
		m_fpInitComm = (FP_INIT_COMM)GetProcAddress(m_hLibModule, "InitComm");

	if( NULL == m_fpInitComm )	return FALSE;

	return m_fpInitComm(hParent, lpszSvrIp);
}

BOOL ICommHelper::InitCommLogin(HWND hParent, LPCTSTR lpszSvrIp)
{
	if( NULL == m_hLibModule )	return FALSE;

	if( NULL == m_fpInitCommLogin )
		m_fpInitCommLogin = (FP_INIT_COMMLOGIN)GetProcAddress(m_hLibModule, "InitCommLogin");

	if( NULL == m_fpInitCommLogin )	return FALSE;

	return m_fpInitCommLogin(hParent, lpszSvrIp);
}

void ICommHelper::ReleaseComm()
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpReleaseComm )
		m_fpReleaseComm = (FP_RELEASE_COMM)GetProcAddress(m_hLibModule, "ReleaseComm");

	if( NULL == m_fpReleaseComm )	return;

	m_fpReleaseComm();
}

int ICommHelper::AddHwnd(HWND hWnd, LPCTSTR lpszCaption)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpAddHwnd )
		m_fpAddHwnd = (FP_ADD_HWND)GetProcAddress(m_hLibModule, "AddHwnd");

	if( NULL == m_fpAddHwnd )	return -1;

	return m_fpAddHwnd(hWnd, lpszCaption);
}

void ICommHelper::DelHwnd(int nCommKey)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpDelHwnd )
		m_fpDelHwnd = (FP_DEL_HWND)GetProcAddress(m_hLibModule, "DelHwnd");

	if( NULL == m_fpDelHwnd )	return;

	m_fpDelHwnd(nCommKey);
}

void ICommHelper::SetLocalIP(LPCTSTR lpszLocalIP)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpSetLocalIP )
		m_fpSetLocalIP = (FP_SET_LOCAL_IP)GetProcAddress(m_hLibModule, "SetLocalIP");

	if( NULL == m_fpSetLocalIP )	return;

	m_fpSetLocalIP(lpszLocalIP);
}

LPCTSTR ICommHelper::GetLocalIP()
{
	if( NULL == m_hLibModule )	return _T("");

	if( NULL == m_fpGetLocalIP )
		m_fpGetLocalIP = (FP_GET_LOCAL_IP)GetProcAddress(m_hLibModule, "GetLocalIP");

	if( NULL == m_fpGetLocalIP )	return _T("");

	return m_fpGetLocalIP();
}

int ICommHelper::RequestData(int nCommKey, LPCTSTR lpszTR, LPCTSTR lpszInput, int nLen, LPCTSTR lpszSvr, LPCTSTR lpszDist)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpRequestData )
		m_fpRequestData = (FP_REQUEST_DATA)GetProcAddress(m_hLibModule, "RequestData");

	if( NULL == m_fpRequestData )	return -1;

	return m_fpRequestData(nCommKey, lpszTR, lpszInput, nLen, lpszSvr, lpszDist);
}

int ICommHelper::RegistAccount(LPCTSTR lpszInput, int nLen)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpRegistAccount )
		m_fpRegistAccount = (FP_REGIST_ACCOUNT)GetProcAddress(m_hLibModule, "RegistAccount");

	if( NULL == m_fpRegistAccount )	return -1;

	return m_fpRegistAccount(lpszInput, nLen);
}

int ICommHelper::RegistReal(LPCTSTR lpszKey, LPVOID lpArg)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpRegistReal )
		m_fpRegistReal = (FP_REGIST_REAL)GetProcAddress(m_hLibModule, "RegistReal");

	if( NULL == m_fpRegistReal )	return -1;

	return m_fpRegistReal(lpszKey, lpArg);
}

int ICommHelper::ReleaseReal(int nRealKey)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpReleaseReal )
		m_fpReleaseReal = (FP_RELEASE_REAL)GetProcAddress(m_hLibModule, "ReleaseReal");

	if( NULL == m_fpReleaseReal )	return -1;

	return m_fpReleaseReal(nRealKey);
}

int ICommHelper::RequestVersion(int nCommKey, LPCTSTR lpszTR, LPCTSTR lpszInput, int nLen)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpRequestVersion )
		m_fpRequestVersion = (FP_REQUEST_VERSION)GetProcAddress(m_hLibModule, "RequestVersion");

	if( NULL == m_fpRequestVersion )	return -1;

	return m_fpRequestVersion(nCommKey, lpszTR, lpszInput, nLen);
}

int ICommHelper::SendKospiFOOrder(int nCommKey, LPCTSTR lpszOrder, int nLen)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpSendKospiFOOrder )
		m_fpSendKospiFOOrder = (FP_SEND_KOSPIFO_ORDER)GetProcAddress(m_hLibModule, "SendKospiFOOrder");

	if( NULL == m_fpSendKospiFOOrder )	return -1;

	return m_fpSendKospiFOOrder(nCommKey, lpszOrder, nLen);
}

int ICommHelper::SendStockOrder(int nCommKey, LPCTSTR lpszOrder, int nLen)
{
	if( NULL == m_hLibModule )	return -1;

	if( NULL == m_fpSendStockOrder )
		m_fpSendStockOrder = (FP_SEND_STOCK_ORDER)GetProcAddress(m_hLibModule, "SendStockOrder");

	if( NULL == m_fpSendStockOrder )	return -1;

	return m_fpSendStockOrder(nCommKey, lpszOrder, nLen);
}

void ICommHelper::WriteLog(LPCTSTR lpszLog)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpWriteLog )
		m_fpWriteLog = (FP_WRITE_LOG)GetProcAddress(m_hLibModule, "WriteLog");

	if( NULL == m_fpWriteLog )	return;

	m_fpWriteLog(lpszLog);
}

void ICommHelper::RunFTPSender(LPCTSTR lpszPath)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpRunFTPSender )
		m_fpRunFTPSender = (FP_RUN_FTPSENDER)GetProcAddress(m_hLibModule, "RunFTPSender");

	if( NULL == m_fpRunFTPSender )	return;

	m_fpRunFTPSender(lpszPath);
}

void ICommHelper::SetLoginId(LPCTSTR lpszLoginId)
{
	if( NULL == m_hLibModule )	return;

	if( NULL == m_fpSetLoginId )
		m_fpSetLoginId = (FP_SET_LOGINID)GetProcAddress(m_hLibModule, "SetLoginId");

	if( NULL == m_fpSetLoginId )	return;

	m_fpSetLoginId(lpszLoginId);
}
