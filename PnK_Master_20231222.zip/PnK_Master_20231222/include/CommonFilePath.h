#pragma once

class CCommonFilePath
{
public:
	CCommonFilePath();
	static LPCTSTR			GetInstallFullPath(const LPCTSTR);
	static LPCTSTR			GetInstallPath(const LPCTSTR);
	static LPCTSTR			GetInstallPath()								{	init(); return s_szDownloadPath;	}
	static LPCTSTR			GetModuleFullPath(const LPCTSTR);
	static LPCTSTR			GetModulePath(const LPCTSTR);
	static LPCTSTR			GetModulePath()									{	init(); return s_szRunPath;			}
protected:
	static void				init();
	static BOOL				RegReadPath(LPCTSTR, LPCTSTR, LPCTSTR, LPTSTR, DWORD);
	static void				RemoveMultipleBackSlash(LPTSTR);
public:
protected:
	static TCHAR			s_szRunPath[MAX_PATH];
	static TCHAR			s_szDownloadPath[MAX_PATH];
	static TCHAR			s_szDownloadFullPath[MAX_PATH];
	static TCHAR			s_szFilePath[MAX_PATH];
	static TCHAR			s_szFileFullPath[MAX_PATH];
};