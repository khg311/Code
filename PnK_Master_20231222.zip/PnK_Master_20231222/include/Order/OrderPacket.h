#pragma once

#include "krxorder.h"

// TOPS ���
struct ORDER_PACKET_HEADER
{
	ORDER_PACKET_HEADER()
	{
		memset(this, ' ', sizeof(ORDER_PACKET_HEADER));
		memcpy(tr_code, _T("DATA"), sizeof(tr_code));
		memset(seq_no, '0', sizeof(seq_no));
	}
	TCHAR tr_code[4];
	TCHAR ack_gubun[1];
	TCHAR seq_no[9];
	TCHAR emp_no[6];
	TCHAR fund_no[4];
	TCHAR mkt_l_cls[1];
	TCHAR com_gb[1];
	TCHAR res_code[4];
	TCHAR org_ord_prc[11];
	TCHAR mysvr_gb[1];
	TCHAR mkt_kind[1];
	TCHAR mkt_offset[1];
	TCHAR filler[16];
};

// ȸ����
struct ORDER_HOIWON
{
	TCHAR fep_org[9];
	TCHAR market_flag[1];
	TCHAR channel_flag[2];
	TCHAR system_flag[2];
	TCHAR comm_key[2];
	TCHAR ord_sb[3];
	TCHAR auto_ord_yn[1];
	TCHAR filler1[9];
	TCHAR emp_no[6];
	TCHAR filler2[5];
	TCHAR filler3[20];
};

// �ֹ�
struct ORDER_PACKET
{
	ORDER_PACKET()
	{
		memset(&(this->KrxOrder), 0x20, sizeof(KRX_ORDER));
	}
	ORDER_PACKET_HEADER header;
	KRX_ORDER KrxOrder;
};

// ü��
struct CH01_PACKET
{
	ORDER_PACKET_HEADER header;
	KRX_CH01 KrxCh01;
};

// �ű�/����/��� Ȯ��
struct HO01_PACKET
{
	ORDER_PACKET_HEADER header;
	KRX_HO01 KrxHo01;
};