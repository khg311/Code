#pragma once

#include "krxorder.h"

// TOPS ���
struct STOCKORDER_PACKET_HEADER
{
	STOCKORDER_PACKET_HEADER()
	{
		memset(this, ' ', sizeof(STOCKORDER_PACKET_HEADER));
		memcpy(tr_code, _T("TATA"), sizeof(tr_code));
		memset(seq_no, '0', sizeof(seq_no));
	}

	TCHAR tr_code[4];
	TCHAR ack_gubun[1];
	TCHAR seq_no[9];
	TCHAR emp_no[6];
	TCHAR fund_no[4];
	TCHAR mkt_l_cls[1];
	TCHAR com_gb[1];
	TCHAR res_code[5];
	TCHAR mysvr_gb[1];
	TCHAR isu_cd[8];
	TCHAR secu_grpid[2];
	TCHAR ord_gb[1];
	TCHAR loan_cls[1];
	TCHAR tord_no[10];
	TCHAR org_tord_no[10];
	TCHAR shtsl_cls[1];
	TCHAR shtsl_flg[1];
	TCHAR org_ord_prc[7];
	TCHAR filler[2];
};

// ȸ����
struct STOCKORDER_HOIWON
{
	TCHAR fep_org[9];
	TCHAR market_flag[1];
	TCHAR channel_flag[2];
	TCHAR system_flag[2];
	TCHAR filler1[6];
	TCHAR ord_no[9];
	TCHAR emp_no[6];
	TCHAR mkt_cls[1];
	TCHAR comm_key[1];
	TCHAR ord_sb[2];
	TCHAR loan_cls[1];
//	TCHAR filler3[20];	// filler3 -> <ord_gb, ... org_ord_no>, 17/09/01
	TCHAR ord_gb[1];
	TCHAR shtsl_cls[1];
	TCHAR filler2[9];
	TCHAR org_ord_no[9];
};

// �ֹ�
struct STOCKORDER_PACKET
{
	STOCKORDER_PACKET()
	{
		memset(&(this->KrxOrder), 0x20, sizeof(KRX_ORDER));
	}
	STOCKORDER_PACKET_HEADER header;
	KRX_ORDER KrxOrder;
};

// ü��
struct SCH01_PACKET
{
	STOCKORDER_PACKET_HEADER header;
	KRX_CH01 KrxCh01;
};

// �ű�/����/��� Ȯ��
struct SHO01_PACKET
{
	STOCKORDER_PACKET_HEADER header;
	KRX_HO01 KrxHo01;
};